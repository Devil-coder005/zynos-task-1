/**
 * LABGUARD AI Service Architecture
 * Connects frontend views to backend Gemini API & SOC intelligence endpoints.
 */

export interface AiActionResult {
  success: boolean;
  action: string;
  analysis: string;
  source: 'gemini' | 'fallback';
  timestamp: string;
  error?: string;
}

export interface ChatResponse {
  success: boolean;
  reply: string;
  source: 'gemini' | 'fallback';
  timestamp: string;
  error?: string;
}

export const aiService = {
  // 1. Analyze Nmap scan results
  async analyzeNmapResults(nmapEvidence: any): Promise<AiActionResult> {
    return this.callAiAction('analyzeNmapResults', nmapEvidence);
  },

  // 2. Interpret Linux listening services and Lynis audit results
  async analyzeLynisReport(lynisEvidence: any): Promise<AiActionResult> {
    return this.callAiAction('analyzeLynisReport', lynisEvidence);
  },

  // 3. Review SSH configuration
  async analyzeSSHConfiguration(sshEvidence: any): Promise<AiActionResult> {
    return this.callAiAction('analyzeSSHConfiguration', sshEvidence);
  },

  // 4. Review firewall rules
  async analyzeFirewallRules(firewallEvidence: any): Promise<AiActionResult> {
    return this.callAiAction('analyzeFirewallRules', firewallEvidence);
  },

  // 5. Analyze TLS and certificate verification results
  async analyzeTLSResults(tlsEvidence: any): Promise<AiActionResult> {
    return this.callAiAction('analyzeTLSResults', tlsEvidence);
  },

  // 6. Interpret auditd events
  async analyzeAuditLogs(auditEvidence: any): Promise<AiActionResult> {
    return this.callAiAction('analyzeAuditLogs', auditEvidence);
  },

  // 7. Generate risk assessments
  async generateRiskRegister(evidenceContext: any): Promise<AiActionResult> {
    return this.callAiAction('generateRiskRegister', evidenceContext);
  },

  // 8. Compare before-and-after security posture
  async compareSecurityPosture(comparisonData: any): Promise<AiActionResult> {
    return this.callAiAction('compareSecurityPosture', comparisonData);
  },

  // 9. Explain failed security tests
  async explainTestFailure(failedTestData: any): Promise<AiActionResult> {
    return this.callAiAction('explainTestFailure', failedTestData);
  },

  // 10. Generate professional project reports
  async generateFinalReport(assessmentState: any): Promise<AiActionResult> {
    return this.callAiAction('generateFinalReport', assessmentState);
  },

  // Generic AI Action caller
  async callAiAction(action: string, evidence?: any, customPrompt?: string): Promise<AiActionResult> {
    try {
      const response = await fetch('/api/ai/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, evidence, customPrompt }),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (err: any) {
      console.error(`AI Action ${action} failed:`, err);
      return {
        success: false,
        action,
        analysis: 'Failed to communicate with AI server. Please verify dev server is running.',
        source: 'fallback',
        timestamp: new Date().toISOString(),
        error: err?.message,
      };
    }
  },

  // Interactive Chat
  async sendChatMessage(
    message: string,
    history: Array<{ role: string; text: string }>,
    attachedEvidence?: { id: string; title: string; content: string }
  ): Promise<ChatResponse> {
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, history, attachedEvidence }),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (err: any) {
      console.error('Chat request failed:', err);
      return {
        success: false,
        reply: 'Unable to connect to AI Assistant. Check network or server connection.',
        source: 'fallback',
        timestamp: new Date().toISOString(),
        error: err?.message,
      };
    }
  },
};
