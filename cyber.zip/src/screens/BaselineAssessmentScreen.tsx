import React, { useState } from 'react';
import {
  Terminal,
  Sparkles,
  ShieldAlert,
  Server,
  Layers,
  Search,
  Copy,
  Check,
  AlertTriangle,
  Flame,
  Radio,
  FileText,
} from 'lucide-react';
import { PortScanItem, EvidenceRecord } from '../types/labguard';
import { aiService } from '../services/ai-service';

interface BaselineAssessmentScreenProps {
  ports: PortScanItem[];
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
  evidenceList: EvidenceRecord[];
}

export const BaselineAssessmentScreen: React.FC<BaselineAssessmentScreenProps> = ({
  ports,
  onTriggerAiAnalysis,
  evidenceList,
}) => {
  const [activeTab, setActiveTab] = useState<'nmap' | 'ss' | 'lynis' | 'services'>('nmap');
  const [copied, setCopied] = useState(false);

  const nmapEvidence = evidenceList.find((e) => e.id === 'EVD-NMAP-001')?.content || '';
  const lynisEvidence = evidenceList.find((e) => e.id === 'EVD-LYNIS-002')?.content || '';

  const ssEvidence = `Netid State  Recv-Q Send-Q Local Address:Port  Peer Address:PortProcess
tcp   LISTEN 0      128          0.0.0.0:21          0.0.0.0:*    users:(("vsftpd",pid=812,fd=3))
tcp   LISTEN 0      128          0.0.0.0:22          0.0.0.0:*    users:(("sshd",pid=944,fd=3))
tcp   LISTEN 0      128          0.0.0.0:23          0.0.0.0:*    users:(("in.telnetd",pid=1020,fd=0))
tcp   LISTEN 0      511          0.0.0.0:80          0.0.0.0:*    users:(("nginx",pid=1140,fd=6))
tcp   LISTEN 0      128          0.0.0.0:111         0.0.0.0:*    users:(("rpcbind",pid=604,fd=4))
tcp   LISTEN 0      70         127.0.0.1:3306        0.0.0.0:*    users:(("mysqld",pid=1290,fd=31))`;

  const handleCopyCurrent = () => {
    let content = '';
    if (activeTab === 'nmap') content = nmapEvidence;
    else if (activeTab === 'ss') content = ssEvidence;
    else if (activeTab === 'lynis') content = lynisEvidence;
    else content = JSON.stringify(ports, null, 2);

    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunAiAnalysis = () => {
    onTriggerAiAnalysis('analyzeNmapResults', {
      nmapOutput: nmapEvidence,
      ssOutput: ssEvidence,
      lynisBaseline: lynisEvidence,
      ports,
    });
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title & AI Baseline Analysis Trigger */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Baseline Security Assessment</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#f59e0b]/15 text-[#f59e0b] border border-[#f59e0b]/30 font-bold">
              PRE-HARDENING TELEMETRY
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Raw port telemetry, listening daemon sockets, and Lynis baseline score (54/100)
          </p>
        </div>

        <button
          onClick={handleRunAiAnalysis}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>Run AI Baseline Analysis</span>
        </button>
      </div>

      {/* Discovered Listening Ports Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs text-white font-bold">
            <Server className="w-4 h-4 text-[#00e8f8]" />
            <span>Discovered Listening Services (Port Assessment)</span>
          </div>
          <span className="text-xs font-mono text-[#94a3b8]">Target: 192.168.56.10</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Port / Proto</th>
                <th className="py-3 px-4">Service</th>
                <th className="py-3 px-4">Detected Daemon Version</th>
                <th className="py-3 px-4">Exposure Level</th>
                <th className="py-3 px-4">Baseline State</th>
                <th className="py-3 px-4">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {ports.map((p) => (
                <tr key={p.port} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-white">
                    {p.port}/{p.protocol}
                  </td>
                  <td className="py-3 px-4 text-[#00e8f8]">{p.service}</td>
                  <td className="py-3 px-4 text-[#bac9cb]">{p.version}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                        p.riskLevel === 'CRITICAL'
                          ? 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
                          : p.riskLevel === 'HIGH'
                          ? 'bg-[#f87171]/15 text-[#f87171] border-[#f87171]/30'
                          : p.riskLevel === 'MEDIUM'
                          ? 'bg-[#f59e0b]/15 text-[#f59e0b] border-[#f59e0b]/30'
                          : 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                      }`}
                    >
                      {p.riskLevel}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold ${
                        p.statusBefore === 'open' ? 'text-[#ef4444]' : 'text-[#10b981]'
                      }`}
                    >
                      {p.statusBefore.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#849495] text-[11px]">{p.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Terminal Inspection Box with Tabs */}
      <div className="rounded-xl bg-[#090e1c] border border-[#3b82f6]/30 overflow-hidden font-mono text-xs shadow-xl">
        {/* Terminal Header Tabs */}
        <div className="px-4 py-2 bg-[#0e1321] border-b border-[#3b82f6]/20 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-[#ef4444]" />
            <span className="w-3 h-3 rounded-full bg-[#f59e0b]" />
            <span className="w-3 h-3 rounded-full bg-[#10b981]" />
            <span className="ml-2 text-xs text-[#849495]">root@kali-assessor:~# telemetry-inspector</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center rounded-md bg-[#131c31] p-0.5 border border-[#3b82f6]/20">
              <button
                onClick={() => setActiveTab('nmap')}
                className={`px-3 py-1 rounded text-[11px] ${
                  activeTab === 'nmap' ? 'bg-[#00e8f8]/20 text-[#00e8f8] font-bold' : 'text-[#849495]'
                }`}
              >
                nmap -sV -sC
              </button>
              <button
                onClick={() => setActiveTab('ss')}
                className={`px-3 py-1 rounded text-[11px] ${
                  activeTab === 'ss' ? 'bg-[#00e8f8]/20 text-[#00e8f8] font-bold' : 'text-[#849495]'
                }`}
              >
                ss -tulpn
              </button>
              <button
                onClick={() => setActiveTab('lynis')}
                className={`px-3 py-1 rounded text-[11px] ${
                  activeTab === 'lynis' ? 'bg-[#00e8f8]/20 text-[#00e8f8] font-bold' : 'text-[#849495]'
                }`}
              >
                lynis-audit (54)
              </button>
            </div>

            <button
              onClick={handleCopyCurrent}
              className="p-1.5 rounded hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white"
              title="Copy Output"
            >
              {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Terminal Content Display */}
        <div className="p-5 text-[#dee2f6] overflow-x-auto leading-relaxed select-text min-h-[220px]">
          {activeTab === 'nmap' && <pre className="text-xs font-mono">{nmapEvidence}</pre>}
          {activeTab === 'ss' && <pre className="text-xs font-mono">{ssEvidence}</pre>}
          {activeTab === 'lynis' && <pre className="text-xs font-mono">{lynisEvidence}</pre>}
        </div>
      </div>
    </div>
  );
};
