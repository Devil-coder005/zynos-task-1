import React, { useState } from 'react';
import {
  Cpu,
  Sparkles,
  Lock,
  Flame,
  Shield,
  Radio,
  RefreshCw,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Check,
  Terminal,
} from 'lucide-react';
import { HardeningControl } from '../types/labguard';

interface LinuxHardeningScreenProps {
  controls: HardeningControl[];
  onToggleControl: (id: string) => void;
  onTriggerAiRecommendation: (controlCategory?: string) => void;
}

export const LinuxHardeningScreen: React.FC<LinuxHardeningScreenProps> = ({
  controls,
  onToggleControl,
  onTriggerAiRecommendation,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    control: HardeningControl | null;
    actionType: 'apply' | 'rollback';
  }>({
    isOpen: false,
    control: null,
    actionType: 'apply',
  });

  const categories = ['ALL', 'SSH', 'UFW', 'AppArmor', 'auditd', 'Updates', 'Services'];

  const filteredControls =
    selectedCategory === 'ALL'
      ? controls
      : controls.filter((c) => c.category === selectedCategory);

  const appliedCount = controls.filter((c) => c.isApplied).length;

  const handleOpenConfirm = (control: HardeningControl, actionType: 'apply' | 'rollback') => {
    setConfirmModal({
      isOpen: true,
      control,
      actionType,
    });
  };

  const handleConfirmAction = () => {
    if (confirmModal.control) {
      onToggleControl(confirmModal.control.id);
    }
    setConfirmModal({ isOpen: false, control: null, actionType: 'apply' });
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Linux Hardening Controls</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30 font-bold">
              {appliedCount}/{controls.length} CONTROLS ENFORCED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            CIS Benchmark hardening implementation with dry-run verification and guaranteed recovery path
          </p>
        </div>

        <button
          onClick={() => onTriggerAiRecommendation(selectedCategory)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>AI Hardening Recommendations</span>
        </button>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              selectedCategory === cat
                ? 'bg-[#00e8f8] text-[#00363b] font-bold shadow-[0_0_12px_rgba(0,232,248,0.25)]'
                : 'bg-[#131c31] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Hardening Controls Grid */}
      <div className="space-y-4">
        {filteredControls.map((ctrl) => (
          <div
            key={ctrl.id}
            className={`p-6 rounded-xl bg-[#131c31] border transition-all ${
              ctrl.isApplied
                ? 'border-[#10b981]/40 shadow-[0_0_15px_rgba(16,185,129,0.08)]'
                : 'border-[#3b82f6]/25'
            }`}
          >
            {/* Control Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#3b82f6]/15">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs font-bold text-[#00e8f8]">{ctrl.id}</span>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#1a1f2e] text-[#dee2f6] border border-[#3b82f6]/20">
                  {ctrl.category}
                </span>
                <span
                  className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                    ctrl.severity === 'CRITICAL'
                      ? 'bg-[#ef4444]/15 text-[#ef4444] border border-[#ef4444]/30'
                      : ctrl.severity === 'HIGH'
                      ? 'bg-[#f87171]/15 text-[#f87171] border border-[#f87171]/30'
                      : 'bg-[#f59e0b]/15 text-[#f59e0b] border border-[#f59e0b]/30'
                  }`}
                >
                  {ctrl.severity}
                </span>
                <h3 className="font-mono text-sm font-bold text-white">{ctrl.title}</h3>
              </div>

              <div className="flex items-center gap-2">
                {ctrl.isApplied ? (
                  <button
                    onClick={() => handleOpenConfirm(ctrl, 'rollback')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#1a1f2e] hover:bg-[#ef4444]/20 text-[#849495] hover:text-[#ef4444] border border-[#3b82f6]/20 font-mono text-xs transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Rollback</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleOpenConfirm(ctrl, 'apply')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-colors shadow-sm cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply Hardening</span>
                  </button>
                )}

                <div
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-mono text-xs font-bold ${
                    ctrl.isApplied
                      ? 'bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30'
                      : 'bg-[#ef4444]/15 text-[#ef4444] border border-[#ef4444]/30'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{ctrl.isApplied ? 'ENFORCED' : 'PENDING'}</span>
                </div>
              </div>
            </div>

            {/* Current vs Recommended Diff Display */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4 font-mono text-xs">
              <div className="p-3 rounded-lg bg-[#0e1321] border border-[#3b82f6]/20 space-y-1">
                <span className="text-[11px] text-[#849495] uppercase font-bold">Current Configuration:</span>
                <pre className="text-[#dee2f6] whitespace-pre-wrap">{ctrl.currentConfig}</pre>
              </div>

              <div className="p-3 rounded-lg bg-[#090e1c] border border-[#10b981]/30 space-y-1">
                <span className="text-[11px] text-[#10b981] uppercase font-bold">
                  Recommended Hardened State:
                </span>
                <pre className="text-[#10b981] whitespace-pre-wrap">{ctrl.recommendedConfig}</pre>
              </div>
            </div>

            {/* Security Explanation & Risks */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-[#dee2f6] pt-1">
              <div>
                <span className="text-[#00e8f8] font-mono font-bold block mb-1">
                  Security Rationale:
                </span>
                <p className="text-[#bac9cb] leading-relaxed">{ctrl.securityRationale}</p>
              </div>

              <div>
                <span className="text-[#f59e0b] font-mono font-bold block mb-1">
                  Risk If Not Implemented:
                </span>
                <p className="text-[#bac9cb] leading-relaxed">{ctrl.riskIfNotImplemented}</p>
              </div>
            </div>

            {/* Verification Procedure & Recovery Path */}
            <div className="mt-4 pt-3 border-t border-[#3b82f6]/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center gap-2 text-[#94a3b8] truncate">
                <Terminal className="w-3.5 h-3.5 text-[#00e8f8] shrink-0" />
                <span>Verify:</span>
                <code className="text-[#dee2f6] bg-[#0e1321] px-2 py-0.5 rounded border border-[#3b82f6]/20 truncate">
                  {ctrl.verificationProcedure}
                </code>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-[#849495] shrink-0">
                <span>Recovery:</span>
                <span className="text-[#dee2f6]">Snapshot rollback script available</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Confirmation Modal for Safety / Rollback Requirement */}
      {confirmModal.isOpen && confirmModal.control && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-[#131c31] border border-[#00e8f8]/40 rounded-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#f59e0b]/15 border border-[#f59e0b]/30">
                <AlertTriangle className="w-5 h-5 text-[#f59e0b]" />
              </div>
              <div>
                <h3 className="font-mono text-sm font-bold text-white">
                  Confirm Hardening Modification
                </h3>
                <p className="text-xs text-[#94a3b8]">
                  {confirmModal.actionType === 'apply'
                    ? 'Deploying CIS configuration to Linux daemon'
                    : 'Reverting hardening control to baseline state'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs space-y-2">
              <div className="text-white font-bold">{confirmModal.control.title}</div>
              <div className="text-[#94a3b8]">Command to execute on target:</div>
              <code className="text-[#00e8f8] block p-2 bg-[#0e1321] rounded break-all">
                {confirmModal.actionType === 'apply'
                  ? confirmModal.control.verificationProcedure
                  : confirmModal.control.rollbackCommand}
              </code>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmModal({ isOpen: false, control: null, actionType: 'apply' })}
                className="px-4 py-2 rounded-md bg-[#1a1f2e] text-[#bac9cb] hover:text-white font-mono text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmAction}
                className="px-4 py-2 rounded-md bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs"
              >
                Confirm & Proceed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
