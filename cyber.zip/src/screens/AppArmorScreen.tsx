import React, { useState } from 'react';
import {
  Shield,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  Terminal,
  Layers,
  Radio,
  FileCode,
  CheckCircle,
} from 'lucide-react';

interface AppArmorScreenProps {
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
}

export const AppArmorScreen: React.FC<AppArmorScreenProps> = ({ onTriggerAiAnalysis }) => {
  const [profiles] = useState([
    {
      name: '/usr/sbin/nginx',
      mode: 'ENFORCE',
      rules: 'read: /etc/nginx/**, /var/www/** | write: /var/log/nginx/**',
      violations: 0,
      status: 'CONFINED',
    },
    {
      name: '/usr/sbin/tcpdump',
      mode: 'ENFORCE',
      rules: 'cap_net_raw, cap_net_admin, /var/log/tcpdump/**',
      violations: 0,
      status: 'CONFINED',
    },
    {
      name: '/usr/bin/man',
      mode: 'ENFORCE',
      rules: 'confined documentation viewer',
      violations: 0,
      status: 'CONFINED',
    },
    {
      name: '/usr/sbin/mysqld',
      mode: 'ENFORCE',
      rules: 'read/write: /var/lib/mysql/**, cap_sys_resource',
      violations: 0,
      status: 'CONFINED',
    },
  ]);

  const auditLogSnippet = `type=AVC msg=audit(1762495620.401:310): apparmor="DENIED" operation="open" profile="/usr/sbin/nginx" name="/etc/shadow" pid=1142 comm="nginx" requested_mask="r" denied_mask="r" fsuid=33 ouid=0
type=AVC msg=audit(1762495632.112:311): apparmor="DENIED" operation="exec" profile="/usr/sbin/nginx" name="/bin/sh" pid=1142 comm="nginx" requested_mask="x" denied_mask="x" fsuid=33 ouid=0`;

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">AppArmor Mandatory Access Control</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              18 PROFILES ENFORCED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Kernel security module restricting program capabilities and file access boundaries
          </p>
        </div>

        <button
          onClick={() => onTriggerAiAnalysis('analyzeAuditLogs', { apparmorLog: auditLogSnippet, profiles })}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>Analyze AppArmor Profiles with AI</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#10b981]/40 space-y-1">
          <div className="text-xs font-mono text-[#94a3b8]">Enforce Mode Profiles</div>
          <div className="text-2xl font-bold font-mono text-[#10b981]">18 Active</div>
          <p className="text-[11px] text-[#bac9cb]">Kernel blocks unauthorized operations immediately</p>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-1">
          <div className="text-xs font-mono text-[#94a3b8]">Complain Mode Profiles</div>
          <div className="text-2xl font-bold font-mono text-[#00e8f8]">0 (None)</div>
          <p className="text-[11px] text-[#bac9cb]">All target daemons strictly enforced</p>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-1">
          <div className="text-xs font-mono text-[#94a3b8]">Active Confined Processes</div>
          <div className="text-2xl font-bold font-mono text-white">4 Daemons</div>
          <p className="text-[11px] text-[#bac9cb]">nginx, mysqld, tcpdump, systemd-resolved</p>
        </div>
      </div>

      {/* Profiles Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs text-white font-bold">
            <ShieldCheck className="w-4 h-4 text-[#00e8f8]" />
            <span>AppArmor Profile Status (sudo aa-status)</span>
          </div>
          <span className="text-xs font-mono text-[#10b981]">Module: apparmor.enabled=1</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Binary / Daemon Profile</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4">Permitted Resource Capabilities</th>
                <th className="py-3 px-4">Confinement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {profiles.map((p) => (
                <tr key={p.name} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-white">{p.name}</td>
                  <td className="py-3 px-4">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30">
                      {p.mode}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#bac9cb]">{p.rules}</td>
                  <td className="py-3 px-4 text-[#00e8f8]">{p.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AVC Denial Log Simulation */}
      <div className="rounded-xl bg-[#090e1c] border border-[#3b82f6]/30 overflow-hidden font-mono text-xs shadow-xl">
        <div className="px-4 py-2 bg-[#0e1321] border-b border-[#3b82f6]/20 flex items-center justify-between text-white font-bold">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#00e8f8]" />
            <span>Kernel AVC Violation Log (Exploit Confinement Demonstration)</span>
          </div>
          <span className="text-[10px] text-[#ef4444] font-bold">2 BLOCKED ATTEMPTS</span>
        </div>
        <pre className="p-4 text-[#dee2f6] leading-relaxed select-text overflow-x-auto">
          {auditLogSnippet}
        </pre>
      </div>
    </div>
  );
};
