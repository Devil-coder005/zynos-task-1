import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Server,
  Bot,
  RotateCcw,
  Download,
  Upload,
  CheckCircle,
  Shield,
  Key,
} from 'lucide-react';

interface SettingsScreenProps {
  onResetData: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ onResetData }) => {
  const [targetIp, setTargetIp] = useState('192.168.56.10');
  const [subnet, setSubnet] = useState('192.168.56.0/24');
  const [sshPort, setSshPort] = useState('22');
  const [modelName, setModelName] = useState('gemini-3.8-flash');
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="p-8 space-y-8 max-w-4xl mx-auto">
      {/* Title */}
      <div className="pb-4 border-b border-[#3b82f6]/20">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold font-mono text-white">Platform Settings & AI Configuration</h1>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30 font-bold">
            SYSTEM PARAMETERS
          </span>
        </div>
        <p className="text-xs text-[#94a3b8] mt-1">
          Target host bindings, AI engine credentials, and benchmark policy profiles
        </p>
      </div>

      {saved && (
        <div className="p-4 rounded-xl bg-[#10b981]/15 border border-[#10b981]/30 font-mono text-xs text-[#10b981] flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>Platform settings successfully saved and synced with server.</span>
        </div>
      )}

      {/* Target Host Settings Form */}
      <form onSubmit={handleSave} className="space-y-6">
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 space-y-4">
          <div className="flex items-center gap-2 font-mono text-xs text-white font-bold pb-2 border-b border-[#3b82f6]/15">
            <Server className="w-4 h-4 text-[#00e8f8]" />
            <span>Target Server & Subnet Configuration</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
            <div>
              <label className="text-[#94a3b8] block mb-1">Target VM IPv4 Address:</label>
              <input
                type="text"
                value={targetIp}
                onChange={(e) => setTargetIp(e.target.value)}
                className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-2 text-white outline-none focus:border-[#00e8f8]"
              />
            </div>

            <div>
              <label className="text-[#94a3b8] block mb-1">Isolated Host-Only Subnet:</label>
              <input
                type="text"
                value={subnet}
                onChange={(e) => setSubnet(e.target.value)}
                className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-2 text-white outline-none focus:border-[#00e8f8]"
              />
            </div>

            <div>
              <label className="text-[#94a3b8] block mb-1">SSH Administration Port:</label>
              <input
                type="text"
                value={sshPort}
                onChange={(e) => setSshPort(e.target.value)}
                className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-2 text-white outline-none focus:border-[#00e8f8]"
              />
            </div>

            <div>
              <label className="text-[#94a3b8] block mb-1">Benchmark Profile:</label>
              <select className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-2 text-white outline-none focus:border-[#00e8f8]">
                <option>CIS Ubuntu Linux 22.04 LTS Server - Level 1</option>
                <option>CIS Ubuntu Linux 22.04 LTS Server - Level 2</option>
                <option>NIST SP 800-123 Linux Hardening Standard</option>
              </select>
            </div>
          </div>
        </div>

        {/* AI Integration Settings */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#00e8f8]/30 space-y-4">
          <div className="flex items-center justify-between font-mono text-xs pb-2 border-b border-[#3b82f6]/15">
            <div className="flex items-center gap-2 text-white font-bold">
              <Bot className="w-4 h-4 text-[#00e8f8]" />
              <span>Google Gemini AI Engine Architecture</span>
            </div>
            <span className="text-[10px] text-[#10b981] bg-[#10b981]/15 px-2 py-0.5 rounded border border-[#10b981]/30 font-bold">
              SERVER-SIDE PROXY READY
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
            <div>
              <label className="text-[#94a3b8] block mb-1">Selected Gemini Model:</label>
              <input
                type="text"
                disabled
                value={modelName}
                className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-2 text-[#00e8f8] font-bold outline-none cursor-not-allowed opacity-80"
              />
              <span className="text-[10px] text-[#849495] mt-1 block">
                Using @google/genai SDK with User-Agent &apos;aistudio-build&apos;
              </span>
            </div>

            <div>
              <label className="text-[#94a3b8] block mb-1">API Key Management:</label>
              <div className="p-2 rounded bg-[#0e1321] border border-[#3b82f6]/20 text-[#dee2f6] text-[11px] leading-relaxed">
                Managed via AI Studio Secrets Panel. Never exposed to browser bundles.
              </div>
            </div>
          </div>
        </div>

        {/* Save button & Demo Data Controls */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onResetData}
            className="flex items-center gap-1.5 px-3 py-2 rounded-md bg-[#131c31] hover:bg-[#ef4444]/20 text-[#849495] hover:text-[#ef4444] border border-[#3b82f6]/20 font-mono text-xs transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Demo Data to Initial Baseline</span>
          </button>

          <button
            type="submit"
            className="px-6 py-2 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_15px_rgba(0,232,248,0.25)] cursor-pointer"
          >
            Save Configuration
          </button>
        </div>
      </form>
    </div>
  );
};
