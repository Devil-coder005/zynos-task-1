import React, { useState } from 'react';
import {
  Lock,
  Sparkles,
  ShieldCheck,
  Terminal,
  Key,
  CheckCircle,
  AlertTriangle,
  Copy,
  Check,
  Radio,
} from 'lucide-react';
import { EvidenceRecord } from '../types/labguard';

interface SshSecurityScreenProps {
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
  evidenceList: EvidenceRecord[];
}

export const SshSecurityScreen: React.FC<SshSecurityScreenProps> = ({
  onTriggerAiAnalysis,
  evidenceList,
}) => {
  const [copied, setCopied] = useState(false);
  const sshEvidence = evidenceList.find((e) => e.id === 'EVD-SSH-002')?.content || '';

  const directives = [
    {
      name: 'PermitRootLogin',
      baseline: 'yes',
      hardened: 'no',
      status: 'VERIFIED',
      rationale: 'Blocks automated brute-force attempts on root account directly.',
    },
    {
      name: 'PasswordAuthentication',
      baseline: 'yes',
      hardened: 'no',
      status: 'VERIFIED',
      rationale: 'Enforces cryptographically strong Ed25519 public keys; eliminates password attacks.',
    },
    {
      name: 'PubkeyAuthentication',
      baseline: 'yes',
      hardened: 'yes',
      status: 'VERIFIED',
      rationale: 'Asymmetric cryptographic authentication via authorized_keys.',
    },
    {
      name: 'MaxAuthTries',
      baseline: '6',
      hardened: '3',
      status: 'VERIFIED',
      rationale: 'Disconnects sessions after 3 failures; triggers Fail2ban drop rule.',
    },
    {
      name: 'X11Forwarding',
      baseline: 'yes',
      hardened: 'no',
      status: 'VERIFIED',
      rationale: 'Eliminates malicious X11 graphic display hijacking vulnerabilities.',
    },
    {
      name: 'ClientAliveInterval',
      baseline: '0 (disabled)',
      hardened: '300 (5 min)',
      status: 'VERIFIED',
      rationale: 'Automatically terminates idle unattended SSH terminal sessions.',
    },
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(sshEvidence);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">SSH Daemon Security & Key Management</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              PORT 22 HARDENED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Asymmetric public key enforcement, root login prohibition, and cipher suite auditing
          </p>
        </div>

        <button
          onClick={() => onTriggerAiAnalysis('analyzeSSHConfiguration', sshEvidence)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>Audit SSH with LABGUARD AI</span>
        </button>
      </div>

      {/* KPI Directives Comparison Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs text-white font-bold">
            <Lock className="w-4 h-4 text-[#00e8f8]" />
            <span>Target /etc/ssh/sshd_config Directive Audit</span>
          </div>
          <span className="text-xs font-mono text-[#10b981]">Syntax check: sshd -t (VALID)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">sshd Directive</th>
                <th className="py-3 px-4">Baseline (Default)</th>
                <th className="py-3 px-4">Hardened Setting</th>
                <th className="py-3 px-4">Verification</th>
                <th className="py-3 px-4">Security Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {directives.map((d) => (
                <tr key={d.name} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-white">{d.name}</td>
                  <td className="py-3 px-4 text-[#ef4444] font-semibold">{d.baseline}</td>
                  <td className="py-3 px-4 text-[#10b981] font-bold">{d.hardened}</td>
                  <td className="py-3 px-4">
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
                      {d.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#bac9cb] text-[11px]">{d.rationale}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Raw sshd_config viewer & Fail2ban box */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Raw Config Block */}
        <div className="lg:col-span-2 rounded-xl bg-[#090e1c] border border-[#3b82f6]/30 overflow-hidden font-mono text-xs shadow-xl">
          <div className="px-4 py-2 bg-[#0e1321] border-b border-[#3b82f6]/20 flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold">
              <Terminal className="w-4 h-4 text-[#00e8f8]" />
              <span>/etc/ssh/sshd_config (Active Configuration)</span>
            </div>
            <button
              onClick={handleCopy}
              className="p-1 rounded hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white"
              title="Copy"
            >
              {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          <pre className="p-4 text-[#dee2f6] overflow-x-auto leading-relaxed select-text">
            {sshEvidence}
          </pre>
        </div>

        {/* Fail2ban Integration Card */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold font-mono text-xs">
              <Radio className="w-4 h-4 text-[#00e8f8]" />
              <span>Fail2ban SSH Jail</span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              ACTIVE
            </span>
          </div>

          <div className="p-3 rounded bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Jail Name:</span>
              <span className="text-white font-bold">sshd</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Max Retry:</span>
              <span className="text-[#00e8f8]">3 attempts</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Ban Time:</span>
              <span className="text-[#00e8f8]">3600s (1 hour)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Total Banned IPs:</span>
              <span className="text-[#10b981] font-bold">0 (Clean Subnet)</span>
            </div>
          </div>

          <p className="text-xs text-[#bac9cb] leading-relaxed">
            Fail2ban monitors <code className="text-[#00e8f8]">/var/log/auth.log</code> and dynamically inserts iptables/UFW drop rules when brute-force behavior is detected.
          </p>
        </div>
      </div>
    </div>
  );
};
