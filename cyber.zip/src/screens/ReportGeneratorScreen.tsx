import React, { useState } from 'react';
import {
  FileText,
  Sparkles,
  Download,
  Printer,
  Eye,
  CheckCircle,
  Copy,
  Check,
  ShieldCheck,
  Terminal,
  Layers,
} from 'lucide-react';
import { PortScanItem, RiskItem, SecurityTest, HardeningControl } from '../types/labguard';
import { aiService } from '../services/ai-service';

interface ReportGeneratorScreenProps {
  lynisScore: { baseline: number; current: number };
  risks: RiskItem[];
  ports: PortScanItem[];
  controls: HardeningControl[];
  tests: SecurityTest[];
}

export const ReportGeneratorScreen: React.FC<ReportGeneratorScreenProps> = ({
  lynisScore,
  risks,
  ports,
  controls,
  tests,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const delta = lynisScore.current - lynisScore.baseline;

  // Professional comprehensive 5-page Academic Project Report Markdown
  const [reportMarkdown, setReportMarkdown] = useState<string>(`# LABGUARD: LINUX SECURITY ASSESSMENT AND HARDENING REPORT
**Target System:** \`ubuntu-target-vm (192.168.56.10)\`  
**Assessor:** Cybersecurity Operations Command / Student Lead Auditor  
**Date of Assessment:** November 07, 2026  
**Assessment Standard:** Center for Internet Security (CIS) Ubuntu Linux 22.04 LTS Benchmark v1.0.0  
**Overall Lynis Posture Improvement:** **54/100 &rarr; 78/100 (+${delta} Points)**  

---

## 1. EXECUTIVE SUMMARY
LABGUARD performed an end-to-end security assessment and hardening cycle on an isolated Ubuntu 22.04 LTS server. The baseline audit revealed severe attack surface exposures, including cleartext Telnet (port 23), anonymous FTP (port 21), permissive SSH authentication, and unconfined web server execution.

Through targeted hardening controls, host-based firewall enforcement (UFW default deny), AppArmor mandatory access control, cryptographic TLS 1.2/1.3 modernization, and kernel-level auditd syscall monitoring, the target server was transitioned into an enterprise-grade hardened posture. The system achieved a **${delta}-point improvement** in the Lynis hardening index (from 54 to 78), surpassing the minimum academic requirement of +10 points. All 12 automated verification tests passed without error.

---

## 2. SCOPE AND RULES OF ENGAGEMENT
The engagement was strictly confined to the isolated VirtualBox host-only network (\`192.168.56.0/24\`).
- **Target of Evaluation (TOE):** \`192.168.56.10\` (Ubuntu 22.04 LTS Server)
- **Assessor Platform:** \`192.168.56.20\` (Kali Linux)
- **Constraints:** Denial of Service (DoS) and traffic egress beyond the virtual switch were strictly prohibited. All activities followed signed Rules of Engagement (RoE).

---

## 3. LAB NETWORK ARCHITECTURE
\`\`\`text
+-------------------------------------------------------------+
| Physical Host Workstation (Windows 11 / macOS Enterprise)   |
| VirtualBox Hypervisor 7.0 - Host-Only Adapter (vboxnet0)    |
| Isolated Subnet: 192.168.56.0/24                            |
+------------------------------+------------------------------+
                               |
            +------------------+------------------+
            |                                     |
    +-------v--------+                   +--------v-------+
    | Assessor VM    |                   | Target VM      |
    | 192.168.56.20  |  SYN Scans &      | 192.168.56.10  |
    | Kali Linux     |==================>| Ubuntu 22.04   |
    | Auditor Engine |  OpenSSL / Tests  | Jammy Hardened |
    +----------------+                   +----------------+
\`\`\`

---

## 4. BASELINE DISCOVERY FINDINGS
Baseline reconnaissance performed from \`192.168.56.20\` using \`nmap -sV -sC -p-\` identified seven open ports:
1. **Port 21/tcp:** vsftpd 3.0.3 (Insecure cleartext file transfer)
2. **Port 22/tcp:** OpenSSH 8.9p1 (Permitted direct password & root login)
3. **Port 23/tcp:** Linux telnetd (Severe cleartext credential exposure)
4. **Port 80/tcp:** nginx 1.18.0 (Unencrypted HTTP; missing HTTPS redirect)
5. **Port 111/tcp:** rpcbind 2-4 (Unnecessary legacy daemon)
6. **Port 443/tcp:** Closed prior to remediation
7. **Port 3306/tcp:** MySQL 8.0.35 (Bound to 0.0.0.0 instead of loopback)

**Baseline Lynis Hardening Index:** **54/100** (18 Warnings, 42 Suggestions).

---

## 5. RISK ASSESSMENT & REGISTER
| Risk ID | Finding | Likelihood | Impact | Severity | Mitigation Summary | Residual |
|---|---|---|---|---|---|---|
| **RSK-01** | Plaintext Telnet exposed on port 23 | 5 | 5 | **CRITICAL** | Masked socket, purged telnetd package | VERY LOW |
| **RSK-02** | SSH root and password login permitted | 5 | 4 | **CRITICAL** | PermitRootLogin no, Ed25519 key-only | LOW |
| **RSK-03** | vsftpd active with anonymous read | 4 | 4 | **HIGH** | Decommissioned vsftpd; centralized to SFTP | VERY LOW |
| **RSK-04** | HTTP port 80 missing HTTPS redirect | 4 | 3 | **MEDIUM** | Enforced 301 return redirect in nginx | VERY LOW |
| **RSK-05** | Host firewall (UFW) inactive | 4 | 5 | **CRITICAL** | Enforced default deny inbound, rate limit port 22 | LOW |
| **RSK-06** | Legacy TLS 1.0/1.1 accepted | 3 | 4 | **HIGH** | Enforced TLSv1.2 & TLSv1.3 only | VERY LOW |
| **RSK-07** | Lack of kernel auditd file watches | 3 | 4 | **MEDIUM** | Installed CIS audit rules on /etc/shadow | LOW |
| **RSK-08** | Core dumps permitted (fs.suid_dumpable) | 2 | 4 | **MEDIUM** | Enforced fs.suid_dumpable = 0 in sysctl | LOW |

---

## 6. HARDENING IMPLEMENTATION METHODOLOGY

### 6.1 OpenSSH Hardening (\`/etc/ssh/sshd_config\`)
\`\`\`bash
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
ClientAliveInterval 300
ClientAliveCountMax 2
X11Forwarding no
KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com
\`\`\`

### 6.2 Host Firewall (UFW) Enforcement
\`\`\`bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw limit 22/tcp comment 'SSH Rate-Limited'
sudo ufw allow 443/tcp comment 'HTTPS Secure Portal'
sudo ufw allow 80/tcp comment 'HTTP 301 Redirect Only'
sudo ufw enable
\`\`\`

### 6.3 Mandatory Access Control (AppArmor)
Confined internet-facing web daemon \`nginx\` and packet analyzer \`tcpdump\` in Enforce mode. All unauthorized syscall attempts to read \`/etc/shadow\` were intercepted and blocked by the kernel.

### 6.4 Linux Audit Daemon (\`auditd\`)
Installed \`/etc/audit/rules.d/99-labguard.rules\` with immutable execution (\`-e 2\`) tracking modifications to \`/etc/passwd\`, \`/etc/shadow\`, and \`/etc/sudoers\`.

### 6.5 Modern TLS & Cryptography
Deployed X.509 certificate generated via internal Lab CA with matching Subject Alternative Names (\`DNS:labguard.internal\`, \`IP:192.168.56.10\`). Enforced TLSv1.2 and TLSv1.3 protocols, rejecting TLS 1.0 and 1.1 handshakes. Configured HTTP Strict Transport Security (\`Strict-Transport-Security: max-age=31536000; includeSubDomains\`).

---

## 7. RETESTING & VERIFICATION RESULTS
All 12 security verification test suites were executed post-hardening:
- **SSH Password Reject:** PASSED (\`Permission denied (publickey)\`)
- **SSH Key Login:** PASSED (\`student\` authorized login)
- **Firewall Inbound Drop (Port 23):** PASSED (Connection timed out / Filtered)
- **Firewall Inbound Allow (Port 443):** PASSED (Connection succeeded)
- **TLS 1.0 Rejection:** PASSED (Handshake failure)
- **TLS 1.3 Handshake:** PASSED (\`TLS_AES_256_GCM_SHA384\` established)
- **HSTS Enforcement:** PASSED (\`max-age=31536000\` present)
- **auditd Sensitive File Alert:** PASSED (\`key="identity"\` logged)
- **AppArmor Enforce Mode:** PASSED (18 profiles in enforce mode)
- **Reproducibility on Second VM:** PASSED (Ansible playbook 0 failures)

---

## 8. LYNIS SCORE COMPARISON
- **Initial Lynis Hardening Index:** **54**
- **Final Lynis Hardening Index:** **78**
- **Improvement Delta:** **+${delta} Points** (Academic standard: $\ge$ 10 points)
- **CIS Ubuntu Benchmark Compliance:** Converged

---

## 9. CONCLUSION & RECOMMENDATIONS
The LABGUARD platform successfully transitioned the Ubuntu Linux server from an exposed, vulnerable configuration into a hardened, defensible enterprise node. Key residual operational controls include scheduled certificate renewal and periodic review of immutable audit logs.`);

  const handleGenerateAIReport = async () => {
    setIsGenerating(true);
    try {
      const res = await aiService.generateFinalReport({
        lynisScore,
        risks,
        ports,
        controls,
        tests,
      });
      if (res && res.analysis) {
        setReportMarkdown(res.analysis);
      }
    } catch (e) {
      console.error('Failed to generate report with AI:', e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(reportMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadMarkdown = () => {
    const blob = new Blob([reportMarkdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LABGUARD_Academic_Security_Report_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-8 space-y-8 max-w-5xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">AI Project Security Report Generator</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30 font-bold">
              5-PAGE ACADEMIC SPECIFICATION
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Formal, evidence-based assessment deliverable ready for academic evaluation and enterprise sign-off
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20 font-mono text-xs transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            onClick={handleDownloadMarkdown}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download .md</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print / PDF</span>
          </button>

          <button
            onClick={handleGenerateAIReport}
            disabled={isGenerating}
            className="flex items-center gap-2 px-4 py-1.5 rounded-md bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_15px_rgba(0,232,248,0.25)] cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#00363b]" />
            <span>{isGenerating ? 'Regenerating...' : 'Regenerate with AI'}</span>
          </button>
        </div>
      </div>

      {/* Report Container (Styled for high-readability academic review) */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/30 p-8 shadow-2xl space-y-6">
        <div className="pb-4 border-b border-[#3b82f6]/20 flex items-center justify-between text-xs font-mono text-[#94a3b8]">
          <span className="flex items-center gap-2 text-white font-bold">
            <FileText className="w-4 h-4 text-[#00e8f8]" />
            Official Security Audit Deliverable
          </span>
          <span>Standards: CIS Ubuntu 22.04 LTS | NIST SP 800-123</span>
        </div>

        {/* Report Content Body */}
        <div className="prose prose-invert max-w-none text-xs font-mono leading-relaxed text-[#dee2f6] whitespace-pre-wrap select-text space-y-4">
          {reportMarkdown}
        </div>
      </div>
    </div>
  );
};
