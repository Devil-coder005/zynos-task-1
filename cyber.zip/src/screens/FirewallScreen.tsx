import React, { useState } from 'react';
import {
  Flame,
  Sparkles,
  ShieldAlert,
  ShieldCheck,
  Plus,
  Terminal,
  Activity,
  Check,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { EvidenceRecord } from '../types/labguard';

interface FirewallScreenProps {
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
  evidenceList: EvidenceRecord[];
}

export const FirewallScreen: React.FC<FirewallScreenProps> = ({
  onTriggerAiAnalysis,
  evidenceList,
}) => {
  const [rules, setRules] = useState([
    {
      id: 1,
      to: '22/tcp',
      action: 'LIMIT IN',
      from: 'Anywhere',
      protocol: 'TCP',
      comment: 'SSH Rate-Limited (Max 6 conn / 30s)',
      hits: 42,
    },
    {
      id: 2,
      to: '443/tcp',
      action: 'ALLOW IN',
      from: 'Anywhere',
      protocol: 'TCP',
      comment: 'HTTPS Secure Portal',
      hits: 312,
    },
    {
      id: 3,
      to: '80/tcp',
      action: 'ALLOW IN',
      from: 'Anywhere',
      protocol: 'TCP',
      comment: 'HTTP 301 Permanent Redirect to HTTPS',
      hits: 89,
    },
    {
      id: 4,
      to: 'Anywhere',
      action: 'DENY IN',
      from: 'Anywhere',
      protocol: 'ALL',
      comment: 'Default Inbound Policy',
      hits: 1420,
    },
  ]);

  const [newPort, setNewPort] = useState('');
  const [newAction, setNewAction] = useState('ALLOW IN');
  const [newComment, setNewComment] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const ufwEvidence = evidenceList.find((e) => e.id === 'EVD-FW-005')?.content || '';

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPort) return;

    const newRule = {
      id: Date.now(),
      to: newPort.includes('/') ? newPort : `${newPort}/tcp`,
      action: newAction,
      from: 'Anywhere',
      protocol: 'TCP',
      comment: newComment || 'Custom rule',
      hits: 0,
    };

    setRules([newRule, ...rules]);
    setNewPort('');
    setNewComment('');
    setShowAddForm(false);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Firewall Management (UFW)</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              STATUS: ACTIVE
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Host-based packet filtering, stateful connection tracking, and rate limiting
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors"
          >
            <Plus className="w-4 h-4 text-[#00e8f8]" />
            <span>Add Rule</span>
          </button>

          <button
            onClick={() => onTriggerAiAnalysis('analyzeFirewallRules', { rules, ufwEvidence })}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#00363b]" />
            <span>Audit Firewall with AI</span>
          </button>
        </div>
      </div>

      {/* Policies Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#ef4444]/40 space-y-1">
          <div className="text-xs font-mono text-[#94a3b8]">Inbound Policy:</div>
          <div className="text-lg font-bold font-mono text-[#ef4444]">DEFAULT DENY</div>
          <p className="text-[11px] text-[#bac9cb]">Drops all unapproved incoming TCP/UDP connections</p>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#10b981]/40 space-y-1">
          <div className="text-xs font-mono text-[#94a3b8]">Outbound Policy:</div>
          <div className="text-lg font-bold font-mono text-[#10b981]">ALLOW (OUTGOING)</div>
          <p className="text-[11px] text-[#bac9cb]">Permits established sessions and outbound updates</p>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#00e8f8]/40 space-y-1">
          <div className="text-xs font-mono text-[#94a3b8]">SSH Rate Limiting:</div>
          <div className="text-lg font-bold font-mono text-[#00e8f8]">LIMIT 22/TCP ACTIVE</div>
          <p className="text-[11px] text-[#bac9cb]">Throttles automated credential cracking scans</p>
        </div>
      </div>

      {/* Add Rule Quick Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddRule}
          className="p-4 rounded-xl bg-[#131c31] border border-[#00e8f8]/40 flex flex-wrap items-center gap-3 font-mono text-xs animate-in fade-in"
        >
          <div className="flex items-center gap-2">
            <span className="text-[#94a3b8]">Port:</span>
            <input
              type="text"
              placeholder="e.g. 8080/tcp"
              value={newPort}
              onChange={(e) => setNewPort(e.target.value)}
              className="bg-[#0e1321] border border-[#3b82f6]/30 rounded px-2.5 py-1 text-white text-xs outline-none focus:border-[#00e8f8]"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[#94a3b8]">Action:</span>
            <select
              value={newAction}
              onChange={(e) => setNewAction(e.target.value)}
              className="bg-[#0e1321] border border-[#3b82f6]/30 rounded px-2.5 py-1 text-white text-xs outline-none focus:border-[#00e8f8]"
            >
              <option value="ALLOW IN">ALLOW IN</option>
              <option value="DENY IN">DENY IN</option>
              <option value="LIMIT IN">LIMIT IN</option>
            </select>
          </div>

          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <span className="text-[#94a3b8]">Comment:</span>
            <input
              type="text"
              placeholder="Reason for rule..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-2.5 py-1 text-white text-xs outline-none focus:border-[#00e8f8]"
            />
          </div>

          <button
            type="submit"
            className="px-4 py-1 rounded bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-bold text-xs cursor-pointer"
          >
            Insert Rule
          </button>
        </form>
      )}

      {/* Active Rules Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs text-white font-bold">
            <Flame className="w-4 h-4 text-[#00e8f8]" />
            <span>Active UFW Firewall Table (Netfilter Filter Chain)</span>
          </div>
          <span className="text-xs font-mono text-[#94a3b8]">Command: sudo ufw status numbered</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">#</th>
                <th className="py-3 px-4">Destination (To)</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Source (From)</th>
                <th className="py-3 px-4">Comment / Description</th>
                <th className="py-3 px-4">Packet Hits</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {rules.map((r, i) => (
                <tr key={r.id} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 text-[#849495]">[{i + 1}]</td>
                  <td className="py-3 px-4 font-bold text-white">{r.to}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                        r.action.includes('ALLOW')
                          ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                          : r.action.includes('LIMIT')
                          ? 'bg-[#00e8f8]/15 text-[#00e8f8] border-[#00e8f8]/30'
                          : 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
                      }`}
                    >
                      {r.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#38bdf8]">{r.from}</td>
                  <td className="py-3 px-4 text-[#bac9cb]">{r.comment}</td>
                  <td className="py-3 px-4 text-[#00e8f8] font-mono">{r.hits.toLocaleString()} pkts</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
