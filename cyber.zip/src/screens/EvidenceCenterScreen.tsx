import React, { useState, useRef } from 'react';
import {
  FileCode,
  Sparkles,
  Upload,
  Download,
  Eye,
  CheckCircle,
  Copy,
  Check,
  X,
  Hash,
  Filter,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { EvidenceRecord } from '../types/labguard';
import { sanitizeFilename, validateEvidencePayload } from '../utils/security-rules';

interface EvidenceCenterScreenProps {
  evidenceList: EvidenceRecord[];
  onAddEvidence: (record: EvidenceRecord) => void;
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
}

export const EvidenceCenterScreen: React.FC<EvidenceCenterScreenProps> = ({
  evidenceList,
  onAddEvidence,
  onTriggerAiAnalysis,
}) => {
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [previewItem, setPreviewItem] = useState<EvidenceRecord | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // New evidence form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<EvidenceRecord['category']>('Nmap');
  const [newType, setNewType] = useState<EvidenceRecord['type']>('Uploaded');
  const [newContent, setNewContent] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const types = ['ALL', 'Uploaded', 'Automatically Collected', 'Generated Template', 'Verified Result'];

  const filteredEvidence =
    selectedType === 'ALL'
      ? evidenceList
      : evidenceList.filter((e) => e.type === selectedType);

  // Calculate real SHA-256 hash using web crypto
  const computeSha256 = async (text: string): Promise<string> => {
    try {
      const msgBuffer = new TextEncoder().encode(text);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    } catch {
      // Fallback pseudo-hash if crypto unavailable
      return Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!newTitle) {
      setNewTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setNewContent(content || '');
    };
    reader.readAsText(file);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploadError(null);

    const validation = validateEvidencePayload(newContent, 1024);
    if (!validation.isValid) {
      setUploadError(validation.error || 'Invalid evidence payload.');
      return;
    }

    const cleanFilename = sanitizeFilename(`${newTitle.toLowerCase().replace(/\s+/g, '_')}.txt`);
    const sha256Hash = await computeSha256(newContent);

    const newRecord: EvidenceRecord = {
      id: `EVD-USER-${Date.now().toString().slice(-4)}`,
      title: newTitle,
      category: newCategory,
      type: newType,
      filename: cleanFilename,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      sha256: sha256Hash,
      content: newContent,
      notes: newNotes || 'Uploaded via Security Evidence Console',
    };

    onAddEvidence(newRecord);
    setNewTitle('');
    setNewContent('');
    setNewNotes('');
    setUploadError(null);
    setShowUploadModal(false);
  };

  const handleCopyPreview = () => {
    if (previewItem) {
      navigator.clipboard.writeText(previewItem.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadItem = (item: EvidenceRecord) => {
    const blob = new Blob([item.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = item.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Evidence Management Center</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              {evidenceList.length} ARTIFACTS ARCHIVED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            SHA-256 cryptographically indexed test artifacts, terminal captures, and audit evidence
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4 text-[#00e8f8]" />
            <span>Upload Evidence</span>
          </button>

          <button
            onClick={() => onTriggerAiAnalysis('analyzeNmapResults', evidenceList)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#00363b]" />
            <span>AI Evidence Integrity Audit</span>
          </button>
        </div>
      </div>

      {/* Origin Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-xs font-mono text-[#94a3b8] uppercase font-bold shrink-0">Filter Origin:</span>
        {types.map((t) => (
          <button
            key={t}
            onClick={() => setSelectedType(t)}
            className={`px-3 py-1.5 rounded-md font-mono text-xs transition-all cursor-pointer ${
              selectedType === t
                ? 'bg-[#00e8f8] text-[#00363b] font-bold shadow-[0_0_12px_rgba(0,232,248,0.25)]'
                : 'bg-[#131c31] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Evidence Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden font-mono text-xs shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Evidence ID</th>
                <th className="py-3 px-4">Title & Description</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Collection Origin</th>
                <th className="py-3 px-4">SHA-256 Checksum</th>
                <th className="py-3 px-4">Timestamp (UTC)</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {filteredEvidence.map((e) => (
                <tr key={e.id} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-[#00e8f8]">{e.id}</td>
                  <td className="py-3 px-4">
                    <span className="text-white font-bold block">{e.title}</span>
                    <span className="text-[#849495] text-[11px]">{e.notes}</span>
                  </td>
                  <td className="py-3 px-4 text-[#38bdf8]">{e.category}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                        e.type === 'Verified Result'
                          ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                          : e.type === 'Automatically Collected'
                          ? 'bg-[#00e8f8]/15 text-[#00e8f8] border-[#00e8f8]/30'
                          : e.type === 'Uploaded'
                          ? 'bg-[#ffecc7]/15 text-[#ffcb3a] border-[#ffcb3a]/30'
                          : 'bg-[#1a1f2e] text-[#bac9cb] border-[#3b82f6]/20'
                      }`}
                    >
                      {e.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#849495] text-[10px] font-mono">
                    <span title={e.sha256} className="cursor-help">
                      {e.sha256.slice(0, 16)}...
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#94a3b8] text-[11px]">{e.timestamp}</td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setPreviewItem(e)}
                        className="p-1.5 rounded hover:bg-[#0e1321] text-[#00e8f8] transition-colors cursor-pointer"
                        title="View Content"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDownloadItem(e)}
                        className="p-1.5 rounded hover:bg-[#0e1321] text-[#bac9cb] hover:text-white transition-colors cursor-pointer"
                        title="Download Raw File"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-3xl max-h-[85vh] bg-[#131c31] border border-[#00e8f8]/40 rounded-xl shadow-2xl flex flex-col overflow-hidden">
            <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
              <div>
                <h3 className="font-mono text-sm font-bold text-white flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-[#00e8f8]" />
                  <span>{previewItem.title}</span>
                </h3>
                <span className="text-[10px] font-mono text-[#849495] select-all">
                  SHA-256: {previewItem.sha256}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyPreview}
                  className="p-1.5 rounded hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white cursor-pointer"
                  title="Copy Content"
                >
                  {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setPreviewItem(null)}
                  className="p-1.5 rounded hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <pre className="p-6 overflow-y-auto text-xs font-mono text-[#dee2f6] leading-relaxed whitespace-pre-wrap select-text bg-[#090e1c] flex-1">
              {previewItem.content}
            </pre>
          </div>
        </div>
      )}

      {/* Upload Evidence Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <form
            onSubmit={handleUploadSubmit}
            className="w-full max-w-xl bg-[#131c31] border border-[#00e8f8]/40 rounded-xl p-6 shadow-2xl space-y-4 font-mono text-xs"
          >
            <div className="flex items-center justify-between border-b border-[#3b82f6]/20 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-[#00e8f8]" />
                <span>Upload Assessment Evidence Artifact</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="text-[#849495] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {uploadError && (
              <div className="p-3 rounded bg-[#ef4444]/15 border border-[#ef4444]/40 text-[#ef4444] flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="text-[#94a3b8] block mb-1">Evidence Title:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Post-Hardening Nmap Verification"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                />
              </div>

              {/* Native File Upload Helper */}
              <div className="p-3 rounded-lg bg-[#0e1321] border border-dashed border-[#3b82f6]/40 flex items-center justify-between">
                <div className="flex items-center gap-2 text-[#94a3b8]">
                  <FileText className="w-4 h-4 text-[#00e8f8]" />
                  <span>Choose local file (.txt, .log, .nmap, .conf, .md):</span>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.log,.conf,.nmap,.md,.json,.csv"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1 rounded bg-[#131c31] hover:bg-[#1a1f2e] text-[#00e8f8] border border-[#00e8f8]/30 cursor-pointer"
                >
                  Browse File
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#94a3b8] block mb-1">Category:</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                  >
                    <option value="Nmap">Nmap</option>
                    <option value="Lynis">Lynis</option>
                    <option value="SSH">SSH</option>
                    <option value="Firewall">Firewall</option>
                    <option value="TLS">TLS</option>
                    <option value="auditd">auditd</option>
                    <option value="Screenshot">Screenshot</option>
                    <option value="Automation">Automation</option>
                  </select>
                </div>

                <div>
                  <label className="text-[#94a3b8] block mb-1">Collection Origin:</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                  >
                    <option value="Uploaded">Uploaded</option>
                    <option value="Automatically Collected">Automatically Collected</option>
                    <option value="Generated Template">Generated Template</option>
                    <option value="Verified Result">Verified Result</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[#94a3b8] block mb-1">Evidence Text / Terminal Output:</label>
                <textarea
                  rows={6}
                  required
                  placeholder="Paste raw log output or scan results here (or browse a file above)..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded p-3 text-white outline-none focus:border-[#00e8f8] resize-none"
                />
              </div>

              <div>
                <label className="text-[#94a3b8] block mb-1">Evaluator Notes:</label>
                <input
                  type="text"
                  placeholder="Scope or verification context..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="px-4 py-2 rounded bg-[#1a1f2e] text-[#bac9cb] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-bold cursor-pointer"
              >
                Archive Artifact
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
