import React from 'react';
import {
  Sparkles,
  Bot,
  ShieldCheck,
  ShieldAlert,
  Flame,
  Terminal,
  ArrowUpRight,
  ArrowRight,
  TrendingUp,
  Lock,
  Radio,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  Play,
  Layers,
} from 'lucide-react';
import { RiskItem, PortScanItem, HardeningControl, ScreenId } from '../types/labguard';

interface OverviewScreenProps {
  onAnalyzeServer: () => void;
  onOpenAssistantWithPrompt: (prompt: string) => void;
  onNavigate: (screen: ScreenId) => void;
  lynisScore: { baseline: number; current: number };
  risks: RiskItem[];
  ports: PortScanItem[];
  controls: HardeningControl[];
  testsPassedCount: number;
  totalTestsCount: number;
}

export const OverviewScreen: React.FC<OverviewScreenProps> = ({
  onAnalyzeServer,
  onOpenAssistantWithPrompt,
  onNavigate,
  lynisScore,
  risks,
  ports,
  controls,
  testsPassedCount,
  totalTestsCount,
}) => {
  const openRisks = risks.filter((r) => r.treatmentStatus !== 'Mitigated');
  const criticalIssues = risks.slice(0, 3);
  const openPortsCount = ports.filter((p) => p.state === 'open').length;
  const appliedControlsCount = controls.filter((c) => c.isApplied).length;

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Top Hero Banner: AI Posture & Primary Call to Action */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-[#131c31] via-[#161b2a] to-[#0e1321] border border-[#3b82f6]/30 p-6 shadow-[0_0_30px_rgba(0,232,248,0.08)]">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-b from-[#00e8f8]/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30 font-bold">
                OPERATIONS COMMAND ACTIVE
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
                EVIDENCE-VERIFIED
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold font-mono tracking-tight text-white">
              Linux Security Assessment & Hardening Console
            </h1>
            <p className="text-sm text-[#bac9cb] max-w-2xl leading-relaxed">
              Automated vulnerability discovery, baseline telemetry correlation, host firewall enforcement,
              and continuous CIS compliance verification for <span className="text-[#00e8f8] font-mono">ubuntu-target-vm (192.168.56.10)</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => onOpenAssistantWithPrompt('Perform an executive security summary of my Linux server.')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1a1f2e] hover:bg-[#252a39] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/30 text-xs font-mono font-medium transition-all shadow-sm"
            >
              <Bot className="w-4 h-4 text-[#00e8f8]" />
              <span>Ask LABGUARD AI</span>
            </button>

            <button
              onClick={onAnalyzeServer}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#00363b]" />
              <span>Analyze My Server</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Telemetry Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {/* Lynis Baseline Score */}
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Baseline Lynis</span>
            <TrendingUp className="w-4 h-4 text-[#849495]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">{lynisScore.baseline}/100</div>
            <div className="text-[11px] font-mono text-[#f59e0b] mt-0.5">Pre-Hardening</div>
          </div>
        </div>

        {/* Lynis Hardened Target Score */}
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#00e8f8]/30 shadow-[0_0_15px_rgba(0,232,248,0.1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Current Lynis</span>
            <ShieldCheck className="w-4 h-4 text-[#10b981]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-[#00e8f8]">{lynisScore.current}/100</div>
            <div className="text-[11px] font-mono text-[#10b981] font-semibold mt-0.5">
              +{lynisScore.current - lynisScore.baseline} pts (Goal &ge;10)
            </div>
          </div>
        </div>

        {/* Exposed Ports */}
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Exposed Ports</span>
            <Terminal className="w-4 h-4 text-[#38bdf8]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">{openPortsCount} / 7</div>
            <div className="text-[11px] font-mono text-[#10b981] mt-0.5">Reduced to 22 & 443</div>
          </div>
        </div>

        {/* Tests Passed */}
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Tests Passed</span>
            <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">
              {testsPassedCount}/{totalTestsCount}
            </div>
            <div className="text-[11px] font-mono text-[#10b981] mt-0.5">100% Verified</div>
          </div>
        </div>

        {/* Hardening Controls */}
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Hardening</span>
            <Lock className="w-4 h-4 text-[#00e8f8]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">
              {appliedControlsCount}/{controls.length}
            </div>
            <div className="text-[11px] font-mono text-[#00e8f8] mt-0.5">Controls Active</div>
          </div>
        </div>

        {/* Active Open Risks */}
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Resolved Risks</span>
            <ShieldAlert className="w-4 h-4 text-[#10b981]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-[#10b981]">
              {risks.length - openRisks.length}/{risks.length}
            </div>
            <div className="text-[11px] font-mono text-[#bac9cb] mt-0.5">Residual: Low</div>
          </div>
        </div>
      </div>

      {/* Prominent AI Insights Panel */}
      <div className="rounded-xl bg-[#131c31] border border-[#00e8f8]/40 p-6 shadow-[0_0_25px_rgba(0,232,248,0.1)] space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#00e8f8]/15 border border-[#00e8f8]/30">
              <Sparkles className="w-5 h-5 text-[#00e8f8] animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold font-mono text-white">
                LABGUARD AI Real-Time Insights & Security Assessment
              </h2>
              <p className="text-xs text-[#94a3b8]">
                &quot;Your Linux server has three high-priority security concerns evaluated in baseline telemetry.&quot;
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigate('assistant')}
            className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-[#00e8f8] hover:underline"
          >
            <span>Open Security Assistant</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3 Prominent Risk Cards with Severity, Explanation, Recommendation & View Evidence */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {criticalIssues.map((issue) => (
            <div
              key={issue.id}
              className="p-4 rounded-lg bg-[#0e1321] border border-[#3b82f6]/25 hover:border-[#00e8f8]/50 transition-all space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] text-[#00e8f8] font-bold">{issue.id}</span>
                  <span
                    className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                      issue.severity === 'CRITICAL'
                        ? 'bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/40'
                        : issue.severity === 'HIGH'
                        ? 'bg-[#f87171]/20 text-[#f87171] border border-[#f87171]/40'
                        : 'bg-[#f59e0b]/20 text-[#f59e0b] border border-[#f59e0b]/40'
                    }`}
                  >
                    {issue.severity}
                  </span>
                </div>

                <h3 className="font-mono text-xs font-bold text-white line-clamp-1">{issue.finding}</h3>
                <p className="text-xs text-[#bac9cb] leading-relaxed line-clamp-3">
                  Affected service: <code className="text-[#00e8f8]">{issue.affectedService}</code>. Likelihood: {issue.likelihood}/5, Impact: {issue.impact}/5.
                </p>
              </div>

              <div className="pt-2 border-t border-[#3b82f6]/15 space-y-2 text-xs">
                <div className="text-[11px] text-[#10b981] font-mono">
                  <span className="text-[#94a3b8]">Remediation:</span> {issue.mitigation}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => onNavigate('evidence')}
                    className="flex items-center gap-1 text-[11px] font-mono text-[#38bdf8] hover:text-[#00e8f8] transition-colors"
                  >
                    <FileCode className="w-3.5 h-3.5" />
                    <span>View Evidence</span>
                  </button>

                  <button
                    onClick={() => onOpenAssistantWithPrompt(`Explain risk ${issue.id} (${issue.finding}) and explain how to verify the fix.`)}
                    className="flex items-center gap-1 text-[11px] font-mono text-[#00e8f8] hover:underline"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>Ask AI</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Grid: Quick Actions & Live Threat Scans */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rapid Assessment & Workflow Shortcuts */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold font-mono text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#00e8f8]" />
              Core Assessment Workflows
            </h3>
            <span className="text-xs font-mono text-[#94a3b8]">Interactive modules</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => onNavigate('baseline')}
              className="p-3.5 rounded-lg bg-[#0e1321] hover:bg-[#1a1f2e] border border-[#3b82f6]/20 text-left transition-all group"
            >
              <div className="flex items-center justify-between text-xs font-mono font-bold text-white group-hover:text-[#00e8f8]">
                <span>1. Baseline Assessment</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#849495] group-hover:text-[#00e8f8]" />
              </div>
              <p className="text-[11px] text-[#94a3b8] mt-1">
                Inspect Nmap scans, listening ports (`ss`), and initial Lynis 54 audit.
              </p>
            </button>

            <button
              onClick={() => onNavigate('hardening')}
              className="p-3.5 rounded-lg bg-[#0e1321] hover:bg-[#1a1f2e] border border-[#3b82f6]/20 text-left transition-all group"
            >
              <div className="flex items-center justify-between text-xs font-mono font-bold text-white group-hover:text-[#00e8f8]">
                <span>2. Linux Hardening Engine</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#849495] group-hover:text-[#00e8f8]" />
              </div>
              <p className="text-[11px] text-[#94a3b8] mt-1">
                Apply SSH, UFW, AppArmor, auditd controls with rollback safety.
              </p>
            </button>

            <button
              onClick={() => onNavigate('testing')}
              className="p-3.5 rounded-lg bg-[#0e1321] hover:bg-[#1a1f2e] border border-[#3b82f6]/20 text-left transition-all group"
            >
              <div className="flex items-center justify-between text-xs font-mono font-bold text-white group-hover:text-[#00e8f8]">
                <span>3. Security Verification</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#849495] group-hover:text-[#00e8f8]" />
              </div>
              <p className="text-[11px] text-[#94a3b8] mt-1">
                Run automated tests for SSH, Firewall, TLS 1.2/1.3, auditd.
              </p>
            </button>

            <button
              onClick={() => onNavigate('report')}
              className="p-3.5 rounded-lg bg-[#0e1321] hover:bg-[#1a1f2e] border border-[#3b82f6]/20 text-left transition-all group"
            >
              <div className="flex items-center justify-between text-xs font-mono font-bold text-white group-hover:text-[#00e8f8]">
                <span>4. AI Report Generator</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#849495] group-hover:text-[#00e8f8]" />
              </div>
              <p className="text-[11px] text-[#94a3b8] mt-1">
                Export 5-page academic security audit report in Markdown & PDF.
              </p>
            </button>
          </div>
        </div>

        {/* Target Exposure & Subnet Topology Summary */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold font-mono text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#00e8f8]" />
              Target Network & Subnet Topology
            </h3>
            <button
              onClick={() => onNavigate('lab')}
              className="text-xs font-mono text-[#00e8f8] hover:underline"
            >
              View Full Topology &rarr;
            </button>
          </div>

          <div className="p-4 rounded-lg bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Target VM:</span>
              <span className="text-white font-bold">ubuntu-target-vm (192.168.56.10)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Assessor VM:</span>
              <span className="text-[#38bdf8]">kali-assessor-vm (192.168.56.20)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Subnet Isolation:</span>
              <span className="text-[#10b981] font-semibold">VirtualBox Host-Only (192.168.56.0/24)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Scope Enforcement:</span>
              <span className="text-[#10b981]">Host Machine & External Traffic Filtered</span>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-[#3b82f6]/15">
              <span className="text-[#94a3b8]">Post-Hardening Exposed:</span>
              <span className="text-[#00e8f8] font-bold">Port 22/tcp (SSH), Port 443/tcp (HTTPS)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
