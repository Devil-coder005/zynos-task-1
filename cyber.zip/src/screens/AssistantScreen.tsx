import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Paperclip,
  Copy,
  Check,
  Download,
  Sparkles,
  Terminal,
  ShieldCheck,
  FileCode,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { ChatMessage, EvidenceRecord } from '../types/labguard';
import { aiService } from '../services/ai-service';

interface AssistantScreenProps {
  initialPrompt?: string;
  evidenceList: EvidenceRecord[];
}

export const AssistantScreen: React.FC<AssistantScreenProps> = ({
  initialPrompt,
  evidenceList,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-0',
      role: 'assistant',
      text: `Hello! I am **LABGUARD AI**, your dedicated Linux security assessment and hardening assistant.

I have direct access to your verified server telemetry and collected lab evidence:
- **Target Host:** \`192.168.56.10\` (Ubuntu 22.04 LTS)
- **Baseline Nmap Scan:** \`7\` listening ports identified (Telnet, FTP, SSH, HTTP, rpcbind, HTTPS, MySQL)
- **Lynis Hardening Index:** Baseline \`54/100\` &rarr; Hardened \`78/100\` (+24 pts)
- **Host Firewall (UFW):** Default Deny Incoming policy active

Ask me to analyze your scan results, explain Lynis warnings, audit SSH configurations, or test failures. You can also attach any evidence artifact to your query.`,
      timestamp: new Date().toLocaleTimeString(),
      source: 'system',
    },
  ]);

  const [input, setInput] = useState(initialPrompt || '');
  const [isSending, setIsSending] = useState(false);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isSending]);

  useEffect(() => {
    if (initialPrompt) {
      setInput(initialPrompt);
    }
  }, [initialPrompt]);

  const suggestedPrompts = [
    'Analyze my Nmap results.',
    'Explain my Lynis warnings.',
    'Find SSH security problems.',
    'Review my firewall configuration.',
    'Analyze my TLS certificate.',
    'Explain my auditd logs.',
    'Generate a security risk register.',
    'Compare before and after hardening.',
    'Why did my security test fail?',
    'How can I improve my Lynis score?',
  ];

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isSending) return;

    const attached = evidenceList.find((e) => e.id === selectedEvidenceId);

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text,
      timestamp: new Date().toLocaleTimeString(),
      evidenceAttached: attached
        ? { id: attached.id, title: attached.title }
        : undefined,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsSending(true);

    try {
      const historyContext = messages.map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const res = await aiService.sendChatMessage(
        text,
        historyContext,
        attached
          ? {
              id: attached.id,
              title: attached.title,
              content: attached.content,
            }
          : undefined
      );

      const assistantMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString(),
        source: res.source,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Error generating response. Please check server status.',
          timestamp: new Date().toLocaleTimeString(),
          source: 'fallback',
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportChat = () => {
    const chatMarkdown = messages
      .map(
        (m) =>
          `### ${m.role === 'user' ? 'User' : 'LABGUARD AI'} (${m.timestamp})\n${
            m.evidenceAttached ? `*Attached Evidence: ${m.evidenceAttached.title}*\n\n` : ''
          }${m.text}\n\n---`
      )
      .join('\n\n');

    const blob = new Blob([chatMarkdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LABGUARD_AI_Chat_Export_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'msg-init',
        role: 'assistant',
        text: 'Conversation reset. Ready to analyze server evidence.',
        timestamp: new Date().toLocaleTimeString(),
        source: 'system',
      },
    ]);
  };

  return (
    <div className="h-[calc(100vh-3.5rem)] flex flex-col max-w-6xl mx-auto p-6 space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#3b82f6]/20 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-[#00e8f8]/15 border border-[#00e8f8]/30">
            <Bot className="w-5 h-5 text-[#00e8f8]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold font-mono text-white">AI Security Assistant</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-semibold">
                EVIDENCE-AWARE
              </span>
            </div>
            <p className="text-xs text-[#94a3b8]">
              Context-driven Linux hardening advisor. Distinguishes verified server findings from assumptions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={clearChat}
            className="p-2 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20 transition-colors"
            title="Clear Chat History"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportChat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export Analysis</span>
          </button>
        </div>
      </div>

      {/* Suggested Prompt Chips */}
      <div className="overflow-x-auto pb-1 flex items-center gap-2 shrink-0 scrollbar-none">
        <span className="text-[11px] font-mono text-[#94a3b8] uppercase font-semibold shrink-0">
          Suggested:
        </span>
        {suggestedPrompts.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSend(prompt)}
            className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-[#131c31] hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-[#00e8f8] border border-[#3b82f6]/20 hover:border-[#00e8f8]/40 whitespace-nowrap transition-all"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 font-mono text-xs">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1`}
            >
              <div className="flex items-center gap-2 text-[10px] text-[#849495] px-1">
                <span>{isUser ? 'Security Analyst' : 'LABGUARD AI'}</span>
                <span>&bull;</span>
                <span>{msg.timestamp}</span>
                {msg.source && (
                  <span className="text-[#00e8f8] text-[9px] uppercase font-semibold">
                    [{msg.source}]
                  </span>
                )}
              </div>

              <div
                className={`max-w-3xl rounded-xl p-4 text-xs leading-relaxed border select-text ${
                  isUser
                    ? 'bg-[#00e8f8]/15 text-[#dee2f6] border-[#00e8f8]/30'
                    : 'bg-[#131c31] text-[#dee2f6] border-[#3b82f6]/25 shadow-[0_0_15px_rgba(0,0,0,0.3)]'
                }`}
              >
                {msg.evidenceAttached && (
                  <div className="mb-2 pb-2 border-b border-[#3b82f6]/20 flex items-center gap-2 text-[#00e8f8] text-[11px]">
                    <FileCode className="w-3.5 h-3.5" />
                    <span>Attached: {msg.evidenceAttached.title}</span>
                  </div>
                )}

                <div className="whitespace-pre-wrap font-mono text-xs">{msg.text}</div>

                {!isUser && (
                  <div className="mt-3 pt-2 border-t border-[#3b82f6]/15 flex items-center justify-between text-[10px] text-[#849495]">
                    <span className="flex items-center gap-1 text-[#10b981]">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Strict CIS Ubuntu 22.04 Rule Verification
                    </span>
                    <button
                      onClick={() => handleCopy(msg.id, msg.text)}
                      className="flex items-center gap-1 hover:text-[#00e8f8] transition-colors"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-[#10b981]" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isSending && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-[#131c31] border border-[#00e8f8]/30 max-w-sm text-xs font-mono text-[#00e8f8]">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>Analyzing server telemetry with Gemini 3.8 Flash...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box & Evidence Attachment Dropdown */}
      <div className="p-3 rounded-xl bg-[#131c31] border border-[#3b82f6]/30 space-y-2 shrink-0">
        {/* Attachment selection bar */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <Paperclip className="w-3.5 h-3.5 text-[#00e8f8]" />
          <span className="text-[#94a3b8]">Attach Evidence Context:</span>
          <select
            value={selectedEvidenceId}
            onChange={(e) => setSelectedEvidenceId(e.target.value)}
            className="bg-[#0e1321] border border-[#3b82f6]/30 text-white text-xs rounded px-2 py-1 outline-none focus:border-[#00e8f8]"
          >
            <option value="">None (Current Server Context)</option>
            {evidenceList.map((e) => (
              <option key={e.id} value={e.id}>
                {e.title} ({e.category})
              </option>
            ))}
          </select>
        </div>

        {/* Text Input Row */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Ask LABGUARD AI (e.g., 'Why is Telnet risky?' or 'Review my sshd_config')..."
            className="flex-1 bg-[#090e1c] border border-[#3b82f6]/25 rounded-lg px-4 py-2.5 text-xs font-mono text-white placeholder-[#849495] outline-none focus:border-[#00e8f8] focus:shadow-[0_0_12px_rgba(0,232,248,0.2)]"
          />

          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isSending}
            className="px-4 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs disabled:opacity-50 transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
