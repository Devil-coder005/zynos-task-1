import React, { useState } from 'react';
import {
  AlertOctagon,
  Sparkles,
  Download,
  Filter,
  ShieldCheck,
  CheckCircle,
  Clock,
  Layers,
  Plus,
  Trash2,
  X,
} from 'lucide-react';
import { RiskItem } from '../types/labguard';
import { calculateRiskScore } from '../utils/security-rules';

interface RiskAssessmentScreenProps {
  risks: RiskItem[];
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
  onUpdateTreatmentStatus: (id: string, status: 'Mitigated' | 'In Progress' | 'Accepted' | 'Open') => void;
  onAddRisk?: (risk: RiskItem) => void;
  onDeleteRisk?: (id: string) => void;
}

export const RiskAssessmentScreen: React.FC<RiskAssessmentScreenProps> = ({
  risks,
  onTriggerAiAnalysis,
  onUpdateTreatmentStatus,
  onAddRisk,
  onDeleteRisk,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form state
  const [finding, setFinding] = useState('');
  const [affectedService, setAffectedService] = useState('OpenSSH');
  const [likelihood, setLikelihood] = useState<number>(3);
  const [impact, setImpact] = useState<number>(4);
  const [mitigation, setMitigation] = useState('');

  const filteredRisks =
    filterStatus === 'ALL'
      ? risks
      : risks.filter((r) => r.treatmentStatus === filterStatus);

  const criticalCount = risks.filter((r) => r.severity === 'CRITICAL').length;
  const highCount = risks.filter((r) => r.severity === 'HIGH').length;
  const mediumCount = risks.filter((r) => r.severity === 'MEDIUM').length;
  const mitigatedCount = risks.filter((r) => r.treatmentStatus === 'Mitigated').length;

  const handleExportMarkdown = () => {
    const md = `# LABGUARD Security Risk Register\nGenerated: ${new Date().toISOString()}\nTarget: ubuntu-target-vm (192.168.56.10)\n\n| Risk ID | Finding | Affected Service | Likelihood | Impact | Severity | Mitigation | Status | Residual |\n|---|---|---|---|---|---|---|---|---|\n${risks
      .map(
        (r) =>
          `| ${r.id} | ${r.finding} | ${r.affectedService} | ${r.likelihood} | ${r.impact} | ${r.severity} | ${r.mitigation} | ${r.treatmentStatus} | ${r.residualRisk} |`
      )
      .join('\n')}`;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Risk_Register_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCreateRisk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!finding.trim()) return;

    const evaluation = calculateRiskScore(likelihood, impact);
    const newRisk: RiskItem = {
      id: `RSK-${String(risks.length + 1).padStart(3, '0')}`,
      finding: finding.trim(),
      affectedService,
      likelihood,
      impact,
      severity: evaluation.level as any,
      mitigation: mitigation.trim() || 'Remediation plan to be established.',
      treatmentStatus: 'Open',
      residualRisk: 'LOW',
      evidenceRef: 'EVD-USER-ASSESSMENT',
      isConfirmed: true,
    };

    if (onAddRisk) {
      onAddRisk(newRisk);
    }
    setFinding('');
    setMitigation('');
    setShowAddModal(false);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">AI Security Risk Register & Matrix</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              {mitigatedCount}/{risks.length} RISKS MITIGATED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Likelihood &times; Impact risk matrix, evidence-backed vulnerability register, and treatment workflows
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onAddRisk && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4 text-[#00e8f8]" />
              <span>Add Risk Finding</span>
            </button>
          )}

          <button
            onClick={handleExportMarkdown}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Register (.md)</span>
          </button>

          <button
            onClick={() => onTriggerAiAnalysis('generateRiskRegister', risks)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#00363b]" />
            <span>Generate Risk Register with AI</span>
          </button>
        </div>
      </div>

      {/* 5x5 Heatmap Matrix & Severity Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive 5x5 Heatmap Matrix */}
        <div className="lg:col-span-2 p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 space-y-4 shadow-xl">
          <div className="flex items-center justify-between font-mono text-xs">
            <span className="font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#00e8f8]" />
              5 &times; 5 Risk Matrix (Likelihood vs Impact)
            </span>
            <span className="text-[#94a3b8]">Evaluated: {risks.length} Verified Findings</span>
          </div>

          <div className="grid grid-cols-6 gap-1 font-mono text-center text-xs pt-2">
            {/* Header row */}
            <div className="text-[10px] text-[#849495] font-bold py-1">L \ I</div>
            <div className="text-[10px] text-[#849495] font-bold py-1">1 (Negl)</div>
            <div className="text-[10px] text-[#849495] font-bold py-1">2 (Low)</div>
            <div className="text-[10px] text-[#849495] font-bold py-1">3 (Med)</div>
            <div className="text-[10px] text-[#849495] font-bold py-1">4 (High)</div>
            <div className="text-[10px] text-[#849495] font-bold py-1">5 (Crit)</div>

            {/* Matrix rows: Likelihood 5 down to 1 */}
            {[5, 4, 3, 2, 1].map((lh) => (
              <React.Fragment key={lh}>
                <div className="text-[10px] text-[#849495] font-bold flex items-center justify-center">
                  L{lh}
                </div>
                {[1, 2, 3, 4, 5].map((imp) => {
                  const score = lh * imp;
                  const matchingRisks = risks.filter(
                    (r) => r.likelihood === lh && r.impact === imp
                  );
                  let cellBg = 'bg-[#10b981]/15 border-[#10b981]/25 text-[#10b981]';
                  if (score >= 20) cellBg = 'bg-[#ef4444]/25 border-[#ef4444]/40 text-[#ef4444]';
                  else if (score >= 12) cellBg = 'bg-[#f87171]/20 border-[#f87171]/35 text-[#f87171]';
                  else if (score >= 6) cellBg = 'bg-[#f59e0b]/20 border-[#f59e0b]/35 text-[#f59e0b]';

                  return (
                    <div
                      key={imp}
                      className={`p-2 rounded border flex flex-col items-center justify-center min-h-[46px] transition-transform hover:scale-105 ${cellBg}`}
                    >
                      <span className="text-[10px] font-bold">{score}</span>
                      {matchingRisks.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-0.5 justify-center">
                          {matchingRisks.map((mr) => (
                            <span
                              key={mr.id}
                              className="text-[9px] bg-black/60 px-1 rounded text-white font-bold"
                              title={`${mr.id}: ${mr.finding}`}
                            >
                              {mr.id}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-[#94a3b8] pt-2 border-t border-[#3b82f6]/15">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-[#ef4444]" /> Critical (20-25)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-[#f87171]" /> High (12-19)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-[#f59e0b]" /> Medium (6-11)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-[#10b981]" /> Low (1-5)
            </span>
          </div>
        </div>

        {/* Severity Metrics Card */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 space-y-4 flex flex-col justify-between shadow-xl">
          <div className="space-y-4">
            <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
              Severity Distribution
            </h3>

            <div className="space-y-3 font-mono">
              <div className="flex items-center justify-between p-3 rounded-lg bg-[#ef4444]/10 border border-[#ef4444]/25">
                <span className="text-xs text-[#ef4444] font-bold">Critical Severity</span>
                <span className="text-sm font-bold text-white">{criticalCount}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-[#f87171]/10 border border-[#f87171]/25">
                <span className="text-xs text-[#f87171] font-bold">High Severity</span>
                <span className="text-sm font-bold text-white">{highCount}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-[#f59e0b]/10 border border-[#f59e0b]/25">
                <span className="text-xs text-[#f59e0b] font-bold">Medium Severity</span>
                <span className="text-sm font-bold text-white">{mediumCount}</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-[#090e1c] border border-[#10b981]/25 font-mono text-xs space-y-2">
            <div className="flex items-center justify-between text-[#10b981] font-bold">
              <span>Remediation Efficacy</span>
              <span>{Math.round((mitigatedCount / risks.length) * 100)}%</span>
            </div>
            <div className="w-full bg-[#131c31] h-2 rounded-full overflow-hidden">
              <div
                className="bg-[#10b981] h-full transition-all duration-500"
                style={{ width: `${(mitigatedCount / risks.length) * 100}%` }}
              />
            </div>
            <p className="text-[10px] text-[#94a3b8]">
              {mitigatedCount} of {risks.length} vulnerabilities remediated with verified security controls.
            </p>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Risk Register Table */}
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none font-mono text-xs">
            <span className="text-[#94a3b8] uppercase font-bold shrink-0">Filter Status:</span>
            {['ALL', 'Open', 'In Progress', 'Mitigated', 'Accepted'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  filterStatus === st
                    ? 'bg-[#00e8f8] text-[#00363b] font-bold shadow-[0_0_12px_rgba(0,232,248,0.25)]'
                    : 'bg-[#131c31] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <span className="text-xs font-mono text-[#94a3b8]">
            Showing {filteredRisks.length} of {risks.length} findings
          </span>
        </div>

        {/* Register Table */}
        <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
                <tr>
                  <th className="py-3 px-4">Risk ID</th>
                  <th className="py-3 px-4">Finding & Vulnerability</th>
                  <th className="py-3 px-4">Affected Service</th>
                  <th className="py-3 px-4">L &times; I</th>
                  <th className="py-3 px-4">Severity</th>
                  <th className="py-3 px-4">Recommended Mitigation</th>
                  <th className="py-3 px-4">Treatment Status</th>
                  <th className="py-3 px-4">Residual</th>
                  {onDeleteRisk && <th className="py-3 px-4 text-right">Action</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
                {filteredRisks.map((r) => (
                  <tr key={r.id} className="hover:bg-[#1a1f2e]/60 transition-colors">
                    <td className="py-3 px-4 font-bold text-[#00e8f8]">{r.id}</td>
                    <td className="py-3 px-4 text-white font-semibold max-w-[220px]">{r.finding}</td>
                    <td className="py-3 px-4 text-[#38bdf8]">{r.affectedService}</td>
                    <td className="py-3 px-4">
                      {r.likelihood} &times; {r.impact} = {r.likelihood * r.impact}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                          r.severity === 'CRITICAL'
                            ? 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
                            : r.severity === 'HIGH'
                            ? 'bg-[#f87171]/15 text-[#f87171] border-[#f87171]/30'
                            : 'bg-[#f59e0b]/15 text-[#f59e0b] border-[#f59e0b]/30'
                        }`}
                      >
                        {r.severity}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-[#bac9cb] text-[11px] max-w-[240px]">{r.mitigation}</td>
                    <td className="py-3 px-4">
                      <select
                        value={r.treatmentStatus}
                        onChange={(e) =>
                          onUpdateTreatmentStatus(r.id, e.target.value as any)
                        }
                        className="bg-[#0e1321] border border-[#3b82f6]/30 text-xs rounded px-2 py-1 outline-none text-[#00e8f8] cursor-pointer"
                      >
                        <option value="Mitigated">Mitigated</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Open">Open</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30">
                        {r.residualRisk}
                      </span>
                    </td>
                    {onDeleteRisk && (
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onDeleteRisk(r.id)}
                          className="p-1.5 rounded hover:bg-[#ef4444]/15 text-[#849495] hover:text-[#ef4444] transition-colors cursor-pointer"
                          title="Delete Risk Entry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Risk Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <form
            onSubmit={handleCreateRisk}
            className="w-full max-w-lg bg-[#131c31] border border-[#00e8f8]/40 rounded-xl p-6 shadow-2xl space-y-4 font-mono text-xs"
          >
            <div className="flex items-center justify-between border-b border-[#3b82f6]/20 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#00e8f8]" />
                <span>Add Vulnerability Finding to Risk Register</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-[#849495] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[#94a3b8] block mb-1">Finding / Vulnerability Summary:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Weak SSH key exchange algorithm enabled"
                  value={finding}
                  onChange={(e) => setFinding(e.target.value)}
                  className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                />
              </div>

              <div>
                <label className="text-[#94a3b8] block mb-1">Affected Service / Component:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. OpenSSH, Nginx, UFW, Kernel"
                  value={affectedService}
                  onChange={(e) => setAffectedService(e.target.value)}
                  className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[#94a3b8] block mb-1">Likelihood (1 to 5):</label>
                  <select
                    value={likelihood}
                    onChange={(e) => setLikelihood(Number(e.target.value))}
                    className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                  >
                    <option value={1}>1 - Rare / Improbable</option>
                    <option value={2}>2 - Unlikely</option>
                    <option value={3}>3 - Possible</option>
                    <option value={4}>4 - Likely</option>
                    <option value={5}>5 - Almost Certain / Active Exposure</option>
                  </select>
                </div>

                <div>
                  <label className="text-[#94a3b8] block mb-1">Impact (1 to 5):</label>
                  <select
                    value={impact}
                    onChange={(e) => setImpact(Number(e.target.value))}
                    className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded px-3 py-1.5 text-white outline-none focus:border-[#00e8f8]"
                  >
                    <option value={1}>1 - Negligible</option>
                    <option value={2}>2 - Minor</option>
                    <option value={3}>3 - Moderate</option>
                    <option value={4}>4 - Major</option>
                    <option value={5}>5 - Catastrophic / Root Compromise</option>
                  </select>
                </div>
              </div>

              <div className="p-3 rounded bg-[#090e1c] border border-[#3b82f6]/20 flex items-center justify-between">
                <span className="text-[#94a3b8]">Calculated Score & Severity:</span>
                <span className="font-bold text-[#00e8f8]">
                  {likelihood} &times; {impact} = {likelihood * impact} (
                  {calculateRiskScore(likelihood, impact).level})
                </span>
              </div>

              <div>
                <label className="text-[#94a3b8] block mb-1">Recommended Mitigation:</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Specific Linux hardening control or config directive..."
                  value={mitigation}
                  onChange={(e) => setMitigation(e.target.value)}
                  className="w-full bg-[#0e1321] border border-[#3b82f6]/30 rounded p-3 text-white outline-none focus:border-[#00e8f8] resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded bg-[#1a1f2e] text-[#bac9cb] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-bold cursor-pointer"
              >
                Append to Register
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
