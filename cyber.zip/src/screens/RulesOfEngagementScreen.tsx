import React, { useState } from 'react';
import {
  FileCheck2,
  ShieldAlert,
  CheckCircle,
  AlertTriangle,
  Lock,
  Calendar,
  UserCheck,
  Download,
} from 'lucide-react';

export const RulesOfEngagementScreen: React.FC = () => {
  const [isSigned, setIsSigned] = useState(true);

  return (
    <div className="p-8 space-y-8 max-w-5xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Rules of Engagement (RoE)</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              AUTHORIZED & SIGNED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Formal security assessment scope, testing boundaries, and operational constraints
          </p>
        </div>

        <button
          onClick={() => {
            const roeText = `# LABGUARD RULES OF ENGAGEMENT (ROE)\nTarget: 192.168.56.10\nAuditor: Assessor VM (192.168.56.20)\nStatus: Formally Signed Off\nConstraints: Strictly Isolated Virtual Subnet.`;
            const blob = new Blob([roeText], { type: 'text/markdown' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Rules_of_Engagement_LABGUARD.md';
            a.click();
            URL.revokeObjectURL(url);
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export RoE Document</span>
        </button>
      </div>

      {/* Scope Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Target In Scope</div>
          <div className="text-lg font-bold font-mono text-[#00e8f8]">192.168.56.10</div>
          <p className="text-[11px] text-[#bac9cb]">Ubuntu 22.04 LTS Target Virtual Machine</p>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Auditor Source IP</div>
          <div className="text-lg font-bold font-mono text-[#38bdf8]">192.168.56.20</div>
          <p className="text-[11px] text-[#bac9cb]">Assessor VM (Kali Linux 2026.1)</p>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#10b981]/30 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Boundary Confinement</div>
          <div className="text-lg font-bold font-mono text-[#10b981]">192.168.56.0/24</div>
          <p className="text-[11px] text-[#bac9cb]">Host-Only virtual switch without external NAT</p>
        </div>
      </div>

      {/* Allowed vs Prohibited Activities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Permitted Activities */}
        <div className="p-5 rounded-xl bg-[#131c31] border border-[#10b981]/30 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold font-mono text-[#10b981]">
            <CheckCircle className="w-4 h-4" />
            <span>Permitted Assessment Activities</span>
          </div>

          <ul className="space-y-2.5 font-mono text-xs text-[#dee2f6]">
            <li className="flex items-start gap-2">
              <span className="text-[#10b981] font-bold">&bull;</span>
              <span>TCP SYN & Service Version Scans via Nmap (<code className="text-[#00e8f8]">nmap -sV -sC -p-</code>)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#10b981] font-bold">&bull;</span>
              <span>Non-destructive SSH key & password login compliance checks</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#10b981] font-bold">&bull;</span>
              <span>TLS handshake and cipher suite enumeration via OpenSSL s_client</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#10b981] font-bold">&bull;</span>
              <span>Lynis system security auditing & CIS benchmark validation</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#10b981] font-bold">&bull;</span>
              <span>Kernel syscall monitoring test events generated through auditd</span>
            </li>
          </ul>
        </div>

        {/* Prohibited Activities */}
        <div className="p-5 rounded-xl bg-[#131c31] border border-[#ef4444]/30 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold font-mono text-[#ef4444]">
            <AlertTriangle className="w-4 h-4" />
            <span>Strictly Prohibited Actions</span>
          </div>

          <ul className="space-y-2.5 font-mono text-xs text-[#dee2f6]">
            <li className="flex items-start gap-2">
              <span className="text-[#ef4444] font-bold">&bull;</span>
              <span>Denial of Service (DoS/DDoS) and SYN-flood bandwidth saturation</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#ef4444] font-bold">&bull;</span>
              <span>Probing any IP outside the 192.168.56.0/24 subnet (e.g. physical LAN or host OS)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#ef4444] font-bold">&bull;</span>
              <span>Permanent destruction of files without verified backup snapshot</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#ef4444] font-bold">&bull;</span>
              <span>Deploying persistent unmanaged malware or external reverse shells</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Sign-off & Lead Auditor Status */}
      <div className="p-6 rounded-xl bg-[#0e1321] border border-[#3b82f6]/20 font-mono text-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#3b82f6]/15">
          <div className="flex items-center gap-2 text-white font-bold">
            <UserCheck className="w-4 h-4 text-[#00e8f8]" />
            <span>Formal Authorization & Sign-off</span>
          </div>
          <span className="text-[#10b981] font-bold">DOCUMENT STATUS: EXECUTED</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-[#bac9cb]">
          <div>
            <span className="text-[#849495] block text-[11px]">Primary Assessor:</span>
            <span className="text-white font-bold">Cybersecurity Lead Auditor</span>
          </div>
          <div>
            <span className="text-[#849495] block text-[11px]">Authorized Lab Supervisor:</span>
            <span className="text-white font-bold">Academic Project Evaluator</span>
          </div>
          <div>
            <span className="text-[#849495] block text-[11px]">Execution Window:</span>
            <span className="text-[#00e8f8]">Academic Lab Term (2026-Q4)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
