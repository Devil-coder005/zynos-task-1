import React, { useState } from 'react';
import {
  Scale,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Terminal,
  ShieldCheck,
  Filter,
} from 'lucide-react';
import { ChecklistRequirement } from '../types/labguard';
import { calculateReadinessProgress } from '../utils/security-rules';

interface SubmissionReadinessScreenProps {
  checklist: ChecklistRequirement[];
  onToggleStatus: (id: string, status: 'completed' | 'failed' | 'untested') => void;
}

export const SubmissionReadinessScreen: React.FC<SubmissionReadinessScreenProps> = ({
  checklist,
  onToggleStatus,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  const stats = calculateReadinessProgress(checklist);

  const categories = [
    'ALL',
    'Scope & Authorization',
    'Baseline Discovery',
    'Access Control',
    'Network Defense',
    'Attack Surface',
    'Patch Management',
    'Kernel Security',
    'Monitoring & Forensics',
    'Cryptography & TLS',
    'Risk Management',
    'Verification & Retest',
    'Reproducibility',
    'Academic Deliverables',
  ];

  const filteredItems =
    filterCategory === 'ALL'
      ? checklist
      : checklist.filter((item) => item.category === filterCategory);

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Academic Submission Readiness Checklist</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              22/22 REQUIREMENTS TRACKED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Formal project evaluation criteria covering discovery, remediation, verification, and academic deliverables
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-[#94a3b8]">Project Status:</span>
          <span className="text-[#10b981] font-bold px-2 py-1 rounded bg-[#10b981]/15 border border-[#10b981]/30">
            {stats.isReady ? 'SUBMISSION READY (100%)' : `${stats.percentage}% COMPLETE`}
          </span>
        </div>
      </div>

      {/* Progress & Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#131c31] border border-[#00e8f8]/30 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Overall Readiness</div>
          <div className="text-3xl font-bold font-mono text-[#00e8f8]">{stats.percentage}%</div>
          <div className="w-full bg-[#090e1c] h-2 rounded-full overflow-hidden border border-[#3b82f6]/20">
            <div
              className="bg-gradient-to-r from-[#00e8f8] to-[#10b981] h-full rounded-full transition-all duration-500"
              style={{ width: `${stats.percentage}%` }}
            />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#10b981]/30 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Completed Requirements</div>
          <div className="text-3xl font-bold font-mono text-[#10b981]">
            {stats.completed} / {stats.total}
          </div>
          <span className="text-[11px] font-mono text-[#10b981]">&check; All verified with evidence</span>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#ef4444]/30 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Failed Requirements</div>
          <div className="text-3xl font-bold font-mono text-[#ef4444]">{stats.failed}</div>
          <span className="text-[11px] font-mono text-[#849495]">0 Blocker defects</span>
        </div>

        <div className="p-4 rounded-xl bg-[#131c31] border border-[#3b82f6]/20 space-y-2">
          <div className="text-xs font-mono text-[#94a3b8]">Untested Criteria</div>
          <div className="text-3xl font-bold font-mono text-white">{stats.untested}</div>
          <span className="text-[11px] font-mono text-[#849495]">0 Untested components</span>
        </div>
      </div>

      {/* Categories Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-xs font-mono text-[#94a3b8] uppercase font-bold shrink-0">Filter Domain:</span>
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilterCategory(c)}
            className={`px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              filterCategory === c
                ? 'bg-[#00e8f8] text-[#00363b] font-bold shadow-[0_0_12px_rgba(0,232,248,0.25)]'
                : 'bg-[#131c31] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Checklist Items Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden font-mono text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Req #</th>
                <th className="py-3 px-4">Requirement Title & Standard</th>
                <th className="py-3 px-4">Domain</th>
                <th className="py-3 px-4">Verification Procedure</th>
                <th className="py-3 px-4">Evidence Ref</th>
                <th className="py-3 px-4 text-right">Status State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {filteredItems.map((item) => (
                <tr key={item.id} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-[#00e8f8]">{item.id}</td>
                  <td className="py-3 px-4">
                    <span className="text-white font-bold block">{item.title}</span>
                    <span className="text-[#849495] text-[11px]">{item.description}</span>
                  </td>
                  <td className="py-3 px-4 text-[#38bdf8]">{item.category}</td>
                  <td className="py-3 px-4 text-[#bac9cb]">
                    {item.verificationCmd ? (
                      <code className="text-[#dee2f6] bg-[#090e1c] px-2 py-0.5 rounded border border-[#3b82f6]/20">
                        {item.verificationCmd}
                      </code>
                    ) : (
                      'Document Review'
                    )}
                  </td>
                  <td className="py-3 px-4 text-[#00e8f8]">{item.evidenceId || 'N/A'}</td>
                  <td className="py-3 px-4 text-right">
                    <select
                      value={item.status}
                      onChange={(e) =>
                        onToggleStatus(item.id, e.target.value as any)
                      }
                      className={`text-xs rounded px-2 py-1 font-bold outline-none border ${
                        item.status === 'completed'
                          ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                          : item.status === 'failed'
                          ? 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
                          : 'bg-[#1a1f2e] text-[#bac9cb] border-[#3b82f6]/20'
                      }`}
                    >
                      <option value="completed">COMPLETED</option>
                      <option value="failed">FAILED</option>
                      <option value="untested">UNTESTED</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
