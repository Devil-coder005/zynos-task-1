import React, { useState } from 'react';
import {
  PlaySquare,
  Sparkles,
  Terminal,
  Play,
  RotateCcw,
  CheckCircle2,
  Copy,
  Check,
  FileCode,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

export const AutomationCenterScreen: React.FC = () => {
  const [activePlaybook, setActivePlaybook] = useState<'bash' | 'ansible'>('bash');
  const [isRunning, setIsRunning] = useState(false);
  const [runLogs, setRunLogs] = useState<string[]>([]);
  const [isDryRun, setIsDryRun] = useState(true);
  const [copied, setCopied] = useState(false);

  const bashScript = `#!/usr/bin/env bash
# ==============================================================================
# LABGUARD AUTOMATED LINUX HARDENING & VERIFICATION ENGINE
# Target OS: Ubuntu 22.04 LTS (Jammy Jellyfish)
# Standard: CIS Ubuntu Linux Benchmark v1.0.0
# ==============================================================================
set -euo pipefail

echo "[+] Starting LABGUARD Automated Hardening Sequence..."

# 1. SSH Daemon Hardening
echo "[+] Step 1/6: Hardening /etc/ssh/sshd_config..."
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
sudo sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\\?MaxAuthTries.*/MaxAuthTries 3/' /etc/ssh/sshd_config
sudo sshd -t && sudo systemctl restart ssh

# 2. Host Firewall (UFW) Configuration
echo "[+] Step 2/6: Enforcing UFW default deny & rate limits..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw limit 22/tcp comment 'SSH Rate-Limited'
sudo ufw allow 443/tcp comment 'HTTPS Secure Portal'
sudo ufw allow 80/tcp comment 'HTTP 301 Redirect'
sudo ufw --force enable

# 3. Decommission Legacy & Insecure Daemons
echo "[+] Step 3/6: Decommissioning Telnet and FTP..."
sudo systemctl stop telnet.socket inetd vsftpd 2>/dev/null || true
sudo systemctl disable telnet.socket inetd vsftpd 2>/dev/null || true
sudo apt-get purge -y telnetd vsftpd 2>/dev/null || true

# 4. AppArmor Profile Enforcement
echo "[+] Step 4/6: Enforcing AppArmor confinement..."
sudo aa-enforce /usr/sbin/nginx /usr/sbin/tcpdump

# 5. Kernel Audit Rules
echo "[+] Step 5/6: Loading auditd CIS ruleset..."
sudo cp /configs/99-labguard.rules /etc/audit/rules.d/
sudo augenrules --load

# 6. Unattended Upgrades
echo "[+] Step 6/6: Activating automated security patches..."
sudo apt-get install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades

echo "[+] Hardening Complete. Target Lynis Index Target: >= 78"`;

  const ansiblePlaybook = `---
- name: LABGUARD CIS Linux Hardening Playbook
  hosts: target_vms
  become: yes
  vars:
    sshd_permit_root_login: "no"
    sshd_password_auth: "no"
    sshd_max_auth_tries: 3

  tasks:
    - name: Ensure SSH root login is prohibited
      lineinfile:
        path: /etc/ssh/sshd_config
        regexp: '^#?PermitRootLogin'
        line: 'PermitRootLogin {{ sshd_permit_root_login }}'
      notify: Restart SSH

    - name: Enforce UFW default deny incoming
      ufw:
        direction: incoming
        policy: deny
        state: enabled

    - name: Rate limit SSH on port 22
      ufw:
        rule: limit
        port: '22'
        proto: tcp

    - name: Purge insecure packages (telnetd, vsftpd)
      apt:
        name: "{{ item }}"
        state: absent
        purge: yes
      loop:
        - telnetd
        - vsftpd

  handlers:
    - name: Restart SSH
      service:
        name: ssh
        state: restarted`;

  const handleExecute = () => {
    setIsRunning(true);
    setRunLogs([]);

    const steps = [
      '[INIT] Initializing LABGUARD Automation Runner v2.4...',
      '[TARGET] Connecting to 192.168.56.10 via Ed25519 public key...',
      isDryRun ? '[DRY-RUN] Simulating tasks without modifying disk state...' : '[LIVE] Enforcing configuration...',
      '[TASK 1/5] Validating /etc/ssh/sshd_config syntax... [OK]',
      '[TASK 2/5] Inspecting UFW Netfilter ruleset... [OK]',
      '[TASK 3/5] Verifying telnet.socket and vsftpd masking... [OK]',
      '[TASK 4/5] Checking AppArmor confinement for /usr/sbin/nginx... [OK]',
      '[TASK 5/5] Testing auditd kernel watch rules on /etc/shadow... [OK]',
      '[RESULT] Playbook executed with 0 failures, 0 unreachable nodes.',
      '[LYNIS] Target hardening benchmark convergence: Verified at 78/100.',
    ];

    steps.forEach((step, idx) => {
      setTimeout(() => {
        setRunLogs((prev) => [...prev, step]);
        if (idx === steps.length - 1) {
          setIsRunning(false);
        }
      }, (idx + 1) * 350);
    });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(activePlaybook === 'bash' ? bashScript : ansiblePlaybook);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Automation & Reproducibility Center</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              IDEMPOTENT SCRIPTS
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Executable Bash & Ansible hardening playbooks for automated deployment and second VM verification
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs font-mono text-[#bac9cb] cursor-pointer">
            <input
              type="checkbox"
              checked={isDryRun}
              onChange={(e) => setIsDryRun(e.target.checked)}
              className="rounded accent-[#00e8f8]"
            />
            <span>Dry-Run Mode</span>
          </label>

          <button
            onClick={handleExecute}
            disabled={isRunning}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] disabled:opacity-50 cursor-pointer"
          >
            {isRunning ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Executing Playbook...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Execute Playbook</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Script Selector Tabs & Code Box */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Playbook Code Card */}
        <div className="rounded-xl bg-[#090e1c] border border-[#3b82f6]/30 overflow-hidden font-mono text-xs shadow-xl flex flex-col">
          <div className="px-4 py-2.5 bg-[#0e1321] border-b border-[#3b82f6]/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActivePlaybook('bash')}
                className={`px-3 py-1 rounded text-[11px] font-bold ${
                  activePlaybook === 'bash'
                    ? 'bg-[#00e8f8]/20 text-[#00e8f8]'
                    : 'text-[#849495] hover:text-white'
                }`}
              >
                harden.sh (Bash)
              </button>
              <button
                onClick={() => setActivePlaybook('ansible')}
                className={`px-3 py-1 rounded text-[11px] font-bold ${
                  activePlaybook === 'ansible'
                    ? 'bg-[#00e8f8]/20 text-[#00e8f8]'
                    : 'text-[#849495] hover:text-white'
                }`}
              >
                site.yml (Ansible)
              </button>
            </div>

            <button
              onClick={handleCopy}
              className="p-1 rounded hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white"
              title="Copy Script"
            >
              {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <pre className="p-4 text-[#dee2f6] leading-relaxed select-text overflow-x-auto flex-1 max-h-[460px]">
            {activePlaybook === 'bash' ? bashScript : ansiblePlaybook}
          </pre>
        </div>

        {/* Live Runner Terminal Console */}
        <div className="rounded-xl bg-[#090e1c] border border-[#00e8f8]/30 overflow-hidden font-mono text-xs shadow-xl flex flex-col">
          <div className="px-4 py-2.5 bg-[#0e1321] border-b border-[#3b82f6]/20 flex items-center justify-between text-white font-bold">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#00e8f8]" />
              <span>Execution Telemetry Console</span>
            </div>
            <span className="text-[10px] text-[#10b981]">
              {isRunning ? 'RUNNING...' : runLogs.length > 0 ? 'COMPLETED (0 ERRORS)' : 'STANDBY'}
            </span>
          </div>

          <div className="p-5 text-[#dee2f6] space-y-2 select-text overflow-y-auto flex-1 min-h-[400px] max-h-[460px] bg-[#090e1c]">
            {runLogs.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-[#849495] space-y-2 pt-16">
                <PlaySquare className="w-8 h-8 text-[#3b82f6]/40" />
                <p>Click &quot;Execute Playbook&quot; above to run automated hardening sequence.</p>
                <p className="text-[11px] text-[#94a3b8]">
                  Target: <code className="text-[#00e8f8]">192.168.56.10</code>
                </p>
              </div>
            ) : (
              runLogs.map((log, i) => (
                <div
                  key={i}
                  className={`leading-relaxed ${
                    log.includes('[RESULT]')
                      ? 'text-[#10b981] font-bold'
                      : log.includes('[LYNIS]')
                      ? 'text-[#00e8f8] font-bold'
                      : 'text-[#dee2f6]'
                  }`}
                >
                  {log}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
