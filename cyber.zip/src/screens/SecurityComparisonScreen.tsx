import React from 'react';
import {
  GitCompare,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  Terminal,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Layers,
} from 'lucide-react';
import { PortScanItem, RiskItem } from '../types/labguard';

interface SecurityComparisonScreenProps {
  lynisScore: { baseline: number; current: number };
  ports: PortScanItem[];
  risks: RiskItem[];
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
}

export const SecurityComparisonScreen: React.FC<SecurityComparisonScreenProps> = ({
  lynisScore,
  ports,
  risks,
  onTriggerAiAnalysis,
}) => {
  const delta = lynisScore.current - lynisScore.baseline;
  const initialOpenPorts = ports.filter((p) => p.statusBefore === 'open');
  const finalOpenPorts = ports.filter((p) => p.statusAfter === 'open');

  const comparisonData = {
    baselineLynis: lynisScore.baseline,
    hardenedLynis: lynisScore.current,
    delta,
    initialOpenPorts: initialOpenPorts.map((p) => `${p.port}/${p.service}`),
    finalOpenPorts: finalOpenPorts.map((p) => `${p.port}/${p.service}`),
    resolvedRisksCount: risks.filter((r) => r.treatmentStatus === 'Mitigated').length,
    totalRisksCount: risks.length,
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Before-and-After Hardening Comparison</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              +{delta} POINTS POSTURE GAIN
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Comparative analysis of baseline vulnerabilities versus verified hardened state
          </p>
        </div>

        <button
          onClick={() => onTriggerAiAnalysis('compareSecurityPosture', comparisonData)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>Generate AI Comparison Report</span>
        </button>
      </div>

      {/* Main KPI Comparison Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Lynis Score Delta */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#00e8f8]/30 space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Lynis Hardening Index</span>
            <TrendingUp className="w-4 h-4 text-[#10b981]" />
          </div>

          <div className="flex items-baseline gap-4 font-mono">
            <div>
              <span className="text-xs text-[#849495] block">Baseline</span>
              <span className="text-2xl font-bold text-[#ef4444]">{lynisScore.baseline}/100</span>
            </div>
            <ArrowRight className="w-5 h-5 text-[#3b82f6]" />
            <div>
              <span className="text-xs text-[#849495] block">Hardened</span>
              <span className="text-3xl font-bold text-[#00e8f8]">{lynisScore.current}/100</span>
            </div>
          </div>

          <div className="p-2.5 rounded bg-[#090e1c] border border-[#10b981]/30 font-mono text-xs text-[#10b981] font-semibold">
            &check; +{delta} Points Improvement (Requirement &ge;10 Pts Met)
          </div>
        </div>

        {/* Exposed Network Ports Reduction */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Exposed Attack Surface</span>
            <Terminal className="w-4 h-4 text-[#38bdf8]" />
          </div>

          <div className="flex items-baseline gap-4 font-mono">
            <div>
              <span className="text-xs text-[#849495] block">Initial Ports</span>
              <span className="text-2xl font-bold text-[#ef4444]">{initialOpenPorts.length} Open</span>
            </div>
            <ArrowRight className="w-5 h-5 text-[#3b82f6]" />
            <div>
              <span className="text-xs text-[#849495] block">Hardened Ports</span>
              <span className="text-3xl font-bold text-[#10b981]">{finalOpenPorts.length} Open</span>
            </div>
          </div>

          <div className="p-2.5 rounded bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs text-[#dee2f6]">
            5 Insecure Ports Closed: 21 (FTP), 23 (Telnet), 111 (rpcbind), 3306 (MySQL local), 80 (Redirected)
          </div>
        </div>

        {/* Risk Mitigation Ratio */}
        <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
            <span>Risk Register Resolution</span>
            <ShieldCheck className="w-4 h-4 text-[#10b981]" />
          </div>

          <div className="flex items-baseline gap-4 font-mono">
            <div>
              <span className="text-xs text-[#849495] block">Initial Vulnerabilities</span>
              <span className="text-2xl font-bold text-[#ef4444]">{risks.length} Unmitigated</span>
            </div>
            <ArrowRight className="w-5 h-5 text-[#3b82f6]" />
            <div>
              <span className="text-xs text-[#849495] block">Resolved</span>
              <span className="text-3xl font-bold text-[#10b981]">{comparisonData.resolvedRisksCount} Mitigated</span>
            </div>
          </div>

          <div className="p-2.5 rounded bg-[#090e1c] border border-[#10b981]/30 font-mono text-xs text-[#10b981] font-semibold">
            &check; Residual Risk: Confined to Minimum Operational Needs
          </div>
        </div>
      </div>

      {/* Side-by-Side Port & Service Diff Matrix */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden font-mono text-xs">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between text-white font-bold">
          <div className="flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-[#00e8f8]" />
            <span>Side-by-Side Network Daemon Exposure Diff</span>
          </div>
          <span className="text-xs text-[#94a3b8]">Target: 192.168.56.10</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-[#3b82f6]/20">
          {/* Baseline State (Pre-Hardening) */}
          <div className="p-6 space-y-3 bg-[#0e1321]/50">
            <div className="flex items-center justify-between pb-2 border-b border-[#ef4444]/30">
              <span className="font-bold text-[#ef4444]">BEFORE HARDENING (BASELINE)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#ef4444]/15 text-[#ef4444] border border-[#ef4444]/30 font-bold">
                HIGH EXPOSURE
              </span>
            </div>

            <div className="space-y-2">
              {ports.map((p) => (
                <div
                  key={p.port}
                  className="flex items-center justify-between p-2 rounded bg-[#131c31] border border-[#3b82f6]/15"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{p.port}/tcp</span>
                    <span className="text-[#94a3b8]">({p.service})</span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      p.statusBefore === 'open'
                        ? 'bg-[#ef4444]/20 text-[#ef4444]'
                        : 'bg-[#10b981]/20 text-[#10b981]'
                    }`}
                  >
                    {p.statusBefore.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Hardened State (Post-Hardening) */}
          <div className="p-6 space-y-3 bg-[#090e1c]">
            <div className="flex items-center justify-between pb-2 border-b border-[#10b981]/30">
              <span className="font-bold text-[#10b981]">AFTER HARDENING (CURRENT)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
                CIS CONVERGED
              </span>
            </div>

            <div className="space-y-2">
              {ports.map((p) => (
                <div
                  key={p.port}
                  className="flex items-center justify-between p-2 rounded bg-[#131c31] border border-[#3b82f6]/15"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{p.port}/tcp</span>
                    <span className="text-[#00e8f8]">({p.service})</span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      p.statusAfter === 'open'
                        ? 'bg-[#00e8f8]/20 text-[#00e8f8]'
                        : 'bg-[#10b981]/20 text-[#10b981]'
                    }`}
                  >
                    {p.statusAfter === 'open' ? 'AUTHORIZED OPEN' : 'CLOSED / FILTERED'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
