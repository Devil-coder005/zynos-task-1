import React, { useState } from 'react';
import {
  CheckSquare,
  Sparkles,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Terminal,
  Bot,
  Filter,
  FileCode,
} from 'lucide-react';
import { SecurityTest } from '../types/labguard';

interface SecurityTestingScreenProps {
  tests: SecurityTest[];
  onRunTest: (testId: string) => void;
  onRunAllTests: () => void;
  onExplainFailure: (test: SecurityTest) => void;
}

export const SecurityTestingScreen: React.FC<SecurityTestingScreenProps> = ({
  tests,
  onRunTest,
  onRunAllTests,
  onExplainFailure,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = [
    'ALL',
    'SSH',
    'Firewall',
    'TLS',
    'auditd',
    'AppArmor',
    'Lynis',
    'Services',
    'Reproducibility',
  ];

  const filteredTests =
    selectedCategory === 'ALL'
      ? tests
      : tests.filter((t) => t.category === selectedCategory);

  const passedCount = tests.filter((t) => t.status === 'passed').length;
  const failedCount = tests.filter((t) => t.status === 'failed').length;

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">AI-Assisted Security Testing Center</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              {passedCount}/{tests.length} TESTS PASSED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Automated compliance verification suites across 8 cybersecurity operational domains
          </p>
        </div>

        <button
          onClick={onRunAllTests}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>Execute All Security Tests</span>
        </button>
      </div>

      {/* Categories Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              selectedCategory === cat
                ? 'bg-[#00e8f8] text-[#00363b] font-bold shadow-[0_0_12px_rgba(0,232,248,0.25)]'
                : 'bg-[#131c31] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Tests Grid */}
      <div className="space-y-4">
        {filteredTests.map((test) => (
          <div
            key={test.id}
            className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 hover:border-[#00e8f8]/40 transition-all space-y-4"
          >
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#3b82f6]/15">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs font-bold text-[#00e8f8]">{test.id}</span>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#1a1f2e] text-[#bac9cb] border border-[#3b82f6]/20">
                  {test.category}
                </span>
                <h3 className="font-mono text-sm font-bold text-white">{test.name}</h3>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`text-[10px] font-mono uppercase px-2.5 py-1 rounded font-bold flex items-center gap-1.5 border ${
                    test.status === 'passed'
                      ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                      : test.status === 'failed'
                      ? 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
                      : 'bg-[#00e8f8]/15 text-[#00e8f8] border-[#00e8f8]/30'
                  }`}
                >
                  {test.status === 'passed' ? (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  ) : test.status === 'failed' ? (
                    <XCircle className="w-3.5 h-3.5" />
                  ) : (
                    <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                  )}
                  <span>{test.status.toUpperCase()}</span>
                </span>

                <button
                  onClick={() => onRunTest(test.id)}
                  disabled={test.status === 'running'}
                  className="px-3 py-1 rounded bg-[#1a1f2e] hover:bg-[#252a39] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 text-xs font-mono transition-colors"
                >
                  Re-test
                </button>
              </div>
            </div>

            {/* Verification Command */}
            <div className="p-2.5 rounded bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-[#00e8f8] shrink-0" />
              <code className="text-[#dee2f6] break-all">{test.command}</code>
            </div>

            {/* Expected vs Actual Diff */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
              <div className="p-3 rounded-lg bg-[#0e1321] border border-[#3b82f6]/20 space-y-1">
                <span className="text-[11px] text-[#849495] uppercase font-bold">Expected Output:</span>
                <pre className="text-[#dee2f6] whitespace-pre-wrap">{test.expectedResult}</pre>
              </div>

              <div
                className={`p-3 rounded-lg bg-[#0e1321] border space-y-1 ${
                  test.status === 'passed' ? 'border-[#10b981]/30' : 'border-[#ef4444]/30'
                }`}
              >
                <span
                  className={`text-[11px] uppercase font-bold ${
                    test.status === 'passed' ? 'text-[#10b981]' : 'text-[#ef4444]'
                  }`}
                >
                  Actual Captured Telemetry:
                </span>
                <pre
                  className={`whitespace-pre-wrap ${
                    test.status === 'passed' ? 'text-[#10b981]' : 'text-[#ef4444]'
                  }`}
                >
                  {test.actualResult}
                </pre>
              </div>
            </div>

            {/* Footer with Timestamp, Evidence Ref, and AI Explanation Trigger if Failed */}
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono text-[#849495]">
              <div className="flex items-center gap-3">
                <span>Timestamp: {test.timestamp}</span>
                <span>&bull;</span>
                <span className="text-[#00e8f8] flex items-center gap-1">
                  <FileCode className="w-3.5 h-3.5" />
                  {test.evidenceRef}
                </span>
              </div>

              {test.status === 'failed' && (
                <button
                  onClick={() => onExplainFailure(test)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#ef4444]/15 hover:bg-[#ef4444]/25 text-[#ef4444] border border-[#ef4444]/40 font-bold transition-all"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>Explain Failure & Fix with AI</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
