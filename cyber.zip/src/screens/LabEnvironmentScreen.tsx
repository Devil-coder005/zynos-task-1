import React, { useState } from 'react';
import {
  Network,
  Monitor,
  Server,
  Shield,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Radio,
  Edit2,
  Save,
  Activity,
  RotateCcw,
  AlertOctagon,
  Lock,
} from 'lucide-react';
import { validateLabIp } from '../utils/security-rules';

export const LabEnvironmentScreen: React.FC = () => {
  const [targetIp, setTargetIp] = useState('192.168.56.10');
  const [targetHostname, setTargetHostname] = useState('ubuntu-target-vm');
  const [assessorIp, setAssessorIp] = useState('192.168.56.20');
  const [assessorHostname, setAssessorHostname] = useState('kali-assessor-vm');
  const [subnet, setSubnet] = useState('192.168.56.0/24');
  const [hypervisor, setHypervisor] = useState('Oracle VirtualBox 7.0 (Host-Only vboxnet0)');
  const [isEditing, setIsEditing] = useState(false);
  const [isPinging, setIsPinging] = useState(false);
  const [pingResult, setPingResult] = useState<string | null>(null);

  const targetIpValidation = validateLabIp(targetIp);
  const assessorIpValidation = validateLabIp(assessorIp);

  const handleTestConnectivity = () => {
    setIsPinging(true);
    setPingResult(null);

    setTimeout(() => {
      setIsPinging(false);
      if (!targetIpValidation.isValid || !targetIpValidation.isRfc1918) {
        setPingResult(
          `[ACCESS DENIED - RULES OF ENGAGEMENT ENFORCEMENT]\nTarget IP: ${targetIp}\nStatus: BLOCKED\nReason: ${targetIpValidation.error}\nStrict compliance failure: Traffic generation to public or out-of-scope IP addresses is disabled by the LABGUARD security supervisor.`
        );
      } else {
        setPingResult(
          `PING ${targetIp} (${targetIp}) 56(84) bytes of data.\n64 bytes from ${targetIp}: icmp_seq=1 ttl=64 time=0.384 ms\n64 bytes from ${targetIp}: icmp_seq=2 ttl=64 time=0.412 ms\n64 bytes from ${targetIp}: icmp_seq=3 ttl=64 time=0.395 ms\n--- ${targetIp} ping statistics ---\n3 packets transmitted, 3 received, 0% packet loss, rtt min/avg/max = 0.384/0.397/0.412 ms\n[SCOPE VALIDATED: Host-Only Subnet Confined - RFC1918 Verified]`
        );
      }
    }, 900);
  };

  const handleRestoreDefaults = () => {
    setTargetIp('192.168.56.10');
    setTargetHostname('ubuntu-target-vm');
    setAssessorIp('192.168.56.20');
    setAssessorHostname('kali-assessor-vm');
    setSubnet('192.168.56.0/24');
    setHypervisor('Oracle VirtualBox 7.0 (Host-Only vboxnet0)');
    setPingResult(null);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Lab Environment Architecture</h1>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${
                targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                  ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                  : 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
              }`}
            >
              {targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                ? 'ISOLATED LAB SUBNET'
                : 'SCOPE BOUNDARY WARNING'}
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Visual topology, boundary authorization, and RFC1918 network isolation verification
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRestoreDefaults}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white border border-[#3b82f6]/20 font-mono text-xs transition-colors cursor-pointer"
            title="Reset to default 192.168.56.10/24 topology"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/20 font-mono text-xs transition-colors cursor-pointer"
          >
            {isEditing ? <Save className="w-4 h-4 text-[#10b981]" /> : <Edit2 className="w-4 h-4" />}
            <span>{isEditing ? 'Save Parameters' : 'Edit Lab Parameters'}</span>
          </button>

          <button
            onClick={handleTestConnectivity}
            disabled={isPinging}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-md bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_15px_rgba(0,232,248,0.25)] cursor-pointer"
          >
            <Activity className="w-4 h-4 text-[#00363b]" />
            <span>{isPinging ? 'Pinging Subnet...' : 'Verify Connectivity'}</span>
          </button>
        </div>
      </div>

      {/* Scope Validation Alert Banner */}
      {targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet ? (
        <div className="p-4 rounded-xl bg-[#090e1c] border border-[#10b981]/30 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-[#10b981] shrink-0" />
            <div>
              <span className="text-white font-bold">Scope Boundary Validation: PASS</span>
              <p className="text-[#94a3b8] text-[11px] mt-0.5">
                Target ({targetIp}) is strictly restricted to host-only adapter ({subnet}). No packets route to external Internet or physical LAN.
              </p>
            </div>
          </div>
          <span className="text-[10px] uppercase font-bold text-[#10b981] bg-[#10b981]/10 px-2 py-1 rounded border border-[#10b981]/25">
            ENGAGEMENT APPROVED
          </span>
        </div>
      ) : (
        <div className="p-4 rounded-xl bg-[#2a0e13] border border-[#ef4444]/40 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-3">
            <AlertOctagon className="w-5 h-5 text-[#ef4444] shrink-0 animate-pulse" />
            <div>
              <span className="text-[#ef4444] font-bold">Scope Boundary Validation: FAILED / OUT OF SCOPE</span>
              <p className="text-[#fca5a5] text-[11px] mt-0.5">
                {targetIpValidation.error || 'The entered IP violates the authorized RFC1918 private lab parameters.'}
              </p>
            </div>
          </div>
          <button
            onClick={handleRestoreDefaults}
            className="text-[10px] uppercase font-bold text-[#ef4444] bg-[#ef4444]/15 px-3 py-1 rounded border border-[#ef4444]/40 hover:bg-[#ef4444]/25 cursor-pointer"
          >
            Revert to Safe Lab
          </button>
        </div>
      )}

      {/* Interactive Topology Diagram */}
      <div className="p-6 rounded-xl bg-[#131c31] border border-[#3b82f6]/25 shadow-xl space-y-6">
        <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
          <span className="flex items-center gap-2 text-white font-bold">
            <Network className="w-4 h-4 text-[#00e8f8]" />
            Interactive Network Hierarchy
          </span>
          <span>Click any parameter to review or customize node configuration</span>
        </div>

        {/* Visual Architecture Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
          {/* Node 1: Physical Host & Hypervisor */}
          <div className="p-5 rounded-lg bg-[#0e1321] border border-[#3b82f6]/30 space-y-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-[#3b82f6]/15 border border-[#3b82f6]/30 text-[#38bdf8]">
                <Monitor className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-mono uppercase bg-[#1a1f2e] text-[#bac9cb] px-2 py-0.5 rounded">
                Hypervisor Host
              </span>
            </div>

            <div className="space-y-1">
              <h3 className="font-mono text-sm font-bold text-white">Physical Workstation</h3>
              <p className="text-xs text-[#94a3b8]">Base OS: macOS / Windows 11 Enterprise</p>
            </div>

            <div className="p-3 rounded bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs space-y-1">
              <div className="text-[#94a3b8]">Hypervisor Engine:</div>
              {isEditing ? (
                <input
                  type="text"
                  value={hypervisor}
                  onChange={(e) => setHypervisor(e.target.value)}
                  className="w-full bg-[#131c31] border border-[#3b82f6]/40 text-white rounded px-2 py-1 text-xs"
                />
              ) : (
                <div className="text-[#00e8f8] font-bold truncate">{hypervisor}</div>
              )}
              <div className="text-[#849495] text-[10px] pt-1">
                Subnet: <span className="text-white font-bold">{subnet}</span>
              </div>
            </div>
          </div>

          {/* Node 2: Assessor VM (Attacker / Auditor) */}
          <div className="p-5 rounded-lg bg-[#0e1321] border border-[#00e8f8]/40 space-y-4 shadow-[0_0_15px_rgba(0,232,248,0.1)]">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-[#00e8f8]/15 border border-[#00e8f8]/30 text-[#00e8f8]">
                <Server className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-mono uppercase bg-[#00e8f8]/15 text-[#00e8f8] px-2 py-0.5 rounded font-bold">
                Assessor VM
              </span>
            </div>

            <div className="space-y-1">
              {isEditing ? (
                <input
                  type="text"
                  value={assessorHostname}
                  onChange={(e) => setAssessorHostname(e.target.value)}
                  className="w-full bg-[#131c31] border border-[#3b82f6]/40 text-white font-mono text-sm font-bold rounded px-2 py-1"
                />
              ) : (
                <h3 className="font-mono text-sm font-bold text-white">{assessorHostname}</h3>
              )}
              <p className="text-xs text-[#94a3b8]">Role: Auditor / Security Scanner</p>
            </div>

            <div className="p-3 rounded bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs space-y-1">
              <div className="text-[#94a3b8]">Assessor IP Address:</div>
              {isEditing ? (
                <input
                  type="text"
                  value={assessorIp}
                  onChange={(e) => setAssessorIp(e.target.value)}
                  className={`w-full bg-[#131c31] border rounded px-2 py-1 text-xs text-white ${
                    assessorIpValidation.isRfc1918 ? 'border-[#3b82f6]/40' : 'border-[#ef4444]'
                  }`}
                />
              ) : (
                <div className="text-[#00e8f8] font-bold">{assessorIp}</div>
              )}
              <div className="text-[#849495] text-[10px] pt-1">
                Tools: Nmap, OpenSSL, ss, curl, Netcat
              </div>
            </div>
          </div>

          {/* Node 3: Target VM (Hardening System) */}
          <div
            className={`p-5 rounded-lg bg-[#0e1321] border space-y-4 shadow-lg ${
              targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                ? 'border-[#10b981]/40 shadow-[0_0_15px_rgba(16,185,129,0.1)]'
                : 'border-[#ef4444]/60 shadow-[0_0_15px_rgba(239,68,68,0.2)]'
            }`}
          >
            <div className="flex items-center justify-between">
              <div
                className={`p-2 rounded-lg border ${
                  targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                    ? 'bg-[#10b981]/15 border-[#10b981]/30 text-[#10b981]'
                    : 'bg-[#ef4444]/15 border-[#ef4444]/30 text-[#ef4444]'
                }`}
              >
                <Shield className="w-6 h-6" />
              </div>
              <span
                className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                  targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                    ? 'bg-[#10b981]/15 text-[#10b981]'
                    : 'bg-[#ef4444]/15 text-[#ef4444]'
                }`}
              >
                Target VM (Target of Evaluation)
              </span>
            </div>

            <div className="space-y-1">
              {isEditing ? (
                <input
                  type="text"
                  value={targetHostname}
                  onChange={(e) => setTargetHostname(e.target.value)}
                  className="w-full bg-[#131c31] border border-[#3b82f6]/40 text-white font-mono text-sm font-bold rounded px-2 py-1"
                />
              ) : (
                <h3 className="font-mono text-sm font-bold text-white">{targetHostname}</h3>
              )}
              <p className="text-xs text-[#94a3b8]">OS: Ubuntu 22.04 LTS (Jammy Jellyfish)</p>
            </div>

            <div className="p-3 rounded bg-[#090e1c] border border-[#3b82f6]/20 font-mono text-xs space-y-1">
              <div className="text-[#94a3b8]">Target IP Address:</div>
              {isEditing ? (
                <div className="space-y-1">
                  <input
                    type="text"
                    value={targetIp}
                    onChange={(e) => setTargetIp(e.target.value)}
                    className={`w-full bg-[#131c31] border rounded px-2 py-1 text-xs text-white ${
                      targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                        ? 'border-[#3b82f6]/40'
                        : 'border-[#ef4444] text-[#ef4444]'
                    }`}
                  />
                  {targetIpValidation.error && (
                    <p className="text-[10px] text-[#ef4444] leading-tight">{targetIpValidation.error}</p>
                  )}
                </div>
              ) : (
                <div
                  className={`font-bold ${
                    targetIpValidation.isRfc1918 && targetIpValidation.inTargetSubnet
                      ? 'text-[#10b981]'
                      : 'text-[#ef4444]'
                  }`}
                >
                  {targetIp}
                </div>
              )}
              <div className="text-[#849495] text-[10px] pt-1">
                Hardened Services: OpenSSH (22), Nginx HTTPS (443)
              </div>
            </div>
          </div>
        </div>

        {/* Live Connectivity Test Output */}
        {pingResult && (
          <div className="p-4 rounded-lg bg-[#090e1c] border border-[#00e8f8]/30 space-y-2 animate-in fade-in">
            <div className="flex items-center justify-between text-xs font-mono text-[#00e8f8]">
              <span className="font-bold">Assessor-to-Target Connectivity Verification</span>
              <span className={targetIpValidation.isRfc1918 ? 'text-[#10b981]' : 'text-[#ef4444]'}>
                {targetIpValidation.isRfc1918 ? 'RTT: < 0.5ms (Low Latency Host-Only)' : 'Execution Refused: Out of Scope'}
              </span>
            </div>
            <pre className="text-xs font-mono text-[#dee2f6] bg-[#0e1321] p-3 rounded overflow-x-auto whitespace-pre-wrap">
              {pingResult}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
