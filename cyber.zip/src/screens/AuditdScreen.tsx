import React, { useState } from 'react';
import {
  Radio,
  Sparkles,
  Terminal,
  ShieldCheck,
  FileCode,
  CheckCircle,
  Copy,
  Check,
  Activity,
  AlertTriangle,
} from 'lucide-react';
import { EvidenceRecord } from '../types/labguard';

interface AuditdScreenProps {
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
  evidenceList: EvidenceRecord[];
}

export const AuditdScreen: React.FC<AuditdScreenProps> = ({
  onTriggerAiAnalysis,
  evidenceList,
}) => {
  const [copied, setCopied] = useState(false);
  const auditdEvidence = evidenceList.find((e) => e.id === 'EVD-AUD-006')?.content || '';

  const activeRules = [
    {
      target: '/etc/passwd',
      permissions: 'wa (write/append)',
      key: 'identity',
      rationale: 'Tracks unauthorized addition or modification of local user accounts.',
    },
    {
      target: '/etc/shadow',
      permissions: 'wa (write/append)',
      key: 'identity',
      rationale: 'Logs any attempt to tamper with encrypted password hashes.',
    },
    {
      target: '/etc/sudoers',
      permissions: 'wa (write/append)',
      key: 'actions',
      rationale: 'Audits privilege escalation policy changes.',
    },
    {
      target: 'syscall: execve',
      permissions: 'x (execution)',
      key: 'exec_log',
      rationale: 'Forensic telemetry recording command execution by unprivileged accounts.',
    },
  ];

  const recentEvents = [
    {
      id: 'AUD-8801',
      time: '2026-11-07 02:07:15',
      type: 'SYSCALL (openat)',
      file: '/etc/passwd',
      key: 'identity',
      user: 'root (auid=1000)',
      result: 'SUCCESS',
    },
    {
      id: 'AUD-8802',
      time: '2026-11-07 02:04:12',
      type: 'USER_LOGIN',
      file: '/var/log/btmp',
      key: 'logins',
      user: 'root (remote: 192.168.56.20)',
      result: 'FAILED_REJECTED',
    },
    {
      id: 'AUD-8803',
      time: '2026-11-07 01:50:33',
      type: 'NETFILTER_CFG',
      file: 'UFW ruleset',
      key: 'firewall_mod',
      user: 'root (auid=1000)',
      result: 'APPLIED',
    },
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(auditdEvidence);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">Linux Audit Daemon (auditd) Monitoring</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              KERNEL AUDIT ENABLED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            Forensic syscall tracing, identity file access tracking, and immutable audit logging
          </p>
        </div>

        <button
          onClick={() => onTriggerAiAnalysis('analyzeAuditLogs', { rules: activeRules, events: recentEvents, auditdEvidence })}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>Interpret Auditd Events with AI</span>
        </button>
      </div>

      {/* Rules Table */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs text-white font-bold">
            <Radio className="w-4 h-4 text-[#00e8f8]" />
            <span>Active Kernel Audit Rules (/etc/audit/rules.d/99-labguard.rules)</span>
          </div>
          <span className="text-xs font-mono text-[#10b981]">Status: Immutable (-e 2 loaded)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Monitored Target</th>
                <th className="py-3 px-4">Watch Filter</th>
                <th className="py-3 px-4">Key Identifier</th>
                <th className="py-3 px-4">Forensic Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {activeRules.map((r) => (
                <tr key={r.target} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-white">{r.target}</td>
                  <td className="py-3 px-4 text-[#38bdf8]">{r.permissions}</td>
                  <td className="py-3 px-4">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30">
                      key={r.key}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#bac9cb] text-[11px]">{r.rationale}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Audited Events Feed */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between font-mono text-xs">
          <div className="flex items-center gap-2 text-white font-bold">
            <Activity className="w-4 h-4 text-[#00e8f8]" />
            <span>Recent Forensic Audit Trail (ausearch -k identity --recent)</span>
          </div>
          <span className="text-[#94a3b8]">Buffer: 8192 entries</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Event ID</th>
                <th className="py-3 px-4">Timestamp (UTC)</th>
                <th className="py-3 px-4">Syscall Type</th>
                <th className="py-3 px-4">Target File</th>
                <th className="py-3 px-4">Invoking User / AUID</th>
                <th className="py-3 px-4">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {recentEvents.map((evt) => (
                <tr key={evt.id} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-[#00e8f8]">{evt.id}</td>
                  <td className="py-3 px-4 text-[#849495]">{evt.time}</td>
                  <td className="py-3 px-4 text-white">{evt.type}</td>
                  <td className="py-3 px-4 text-[#38bdf8]">{evt.file}</td>
                  <td className="py-3 px-4 text-[#bac9cb]">{evt.user}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                        evt.result.includes('SUCCESS') || evt.result.includes('APPLIED')
                          ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                          : 'bg-[#ef4444]/15 text-[#ef4444] border-[#ef4444]/30'
                      }`}
                    >
                      {evt.result}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
