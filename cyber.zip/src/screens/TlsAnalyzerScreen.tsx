import React, { useState } from 'react';
import {
  KeyRound,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  Terminal,
  CheckCircle,
  AlertTriangle,
  Lock,
  Calendar,
  ExternalLink,
  Copy,
  Check,
} from 'lucide-react';
import { EvidenceRecord } from '../types/labguard';

interface TlsAnalyzerScreenProps {
  onTriggerAiAnalysis: (action: string, evidenceData: any) => void;
  evidenceList: EvidenceRecord[];
}

export const TlsAnalyzerScreen: React.FC<TlsAnalyzerScreenProps> = ({
  onTriggerAiAnalysis,
  evidenceList,
}) => {
  const [copied, setCopied] = useState(false);
  const tlsConfigEvidence = evidenceList.find((e) => e.id === 'EVD-TLS-004')?.content || '';

  const certData = {
    subject: 'CN = labguard.internal, O = LABGUARD Cyber Operations',
    issuer: 'CN = LabGuard Internal Root CA, O = LABGUARD CA Authority',
    san: ['DNS:labguard.internal', 'IP:192.168.56.10'],
    validFrom: '2026-10-01 00:00:00 UTC',
    validTo: '2027-10-01 00:00:00 UTC',
    daysRemaining: 328,
    keyLength: 'RSA 4096 bits (SHA-256 with RSA)',
    serialNumber: '4F:A1:88:9C:3B:D2:11:09',
    hsts: 'max-age=31536000; includeSubDomains (ENFORCED)',
    httpRedirect: '301 Permanent Redirect on port 80 (ACTIVE)',
  };

  const protocolSupport = [
    {
      protocol: 'TLSv1.0',
      status: 'REJECTED (SECURE)',
      handshake: 'Handshake Failure (SSL routines:no protocols available)',
      compliant: true,
      risk: 'Vulnerable to BEAST, POODLE; prohibited by PCI-DSS and NIST.',
    },
    {
      protocol: 'TLSv1.1',
      status: 'REJECTED (SECURE)',
      handshake: 'Handshake Failure (no shared ciphers)',
      compliant: true,
      risk: 'Deprecated legacy protocol; lacks modern cipher suites.',
    },
    {
      protocol: 'TLSv1.2',
      status: 'SUPPORTED',
      handshake: 'ECDHE-RSA-AES256-GCM-SHA384 (Forward Secrecy Verified)',
      compliant: true,
      risk: 'Cryptographically compliant baseline standard.',
    },
    {
      protocol: 'TLSv1.3',
      status: 'SUPPORTED',
      handshake: 'TLS_AES_256_GCM_SHA384 (0-RTT PFS Verified)',
      compliant: true,
      risk: 'Highest cryptographic strength and lowest latency.',
    },
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(tlsConfigEvidence);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#3b82f6]/20">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">TLS & Certificate Security Analyzer</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 font-bold">
              PORT 443 HTTPS HARDENED
            </span>
          </div>
          <p className="text-xs text-[#94a3b8] mt-1">
            X.509 certificate parameters, SAN validation, protocol deprecation, and HSTS enforcement
          </p>
        </div>

        <button
          onClick={() => onTriggerAiAnalysis('analyzeTLSResults', { certData, protocolSupport, tlsConfigEvidence })}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-mono font-bold text-xs transition-all shadow-[0_0_20px_rgba(0,232,248,0.3)] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#00363b]" />
          <span>Audit TLS with LABGUARD AI</span>
        </button>
      </div>

      {/* Certificate Details Card */}
      <div className="p-6 rounded-xl bg-[#131c31] border border-[#00e8f8]/30 space-y-6">
        <div className="flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2 text-white font-bold">
            <KeyRound className="w-4 h-4 text-[#00e8f8]" />
            <span>X.509 Server Certificate (Internal Lab CA)</span>
          </div>
          <span className="text-[#10b981] font-bold">
            Expires in {certData.daysRemaining} days ({certData.validTo.slice(0, 10)})
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          <div className="p-3.5 rounded-lg bg-[#0e1321] border border-[#3b82f6]/20 space-y-2">
            <div>
              <span className="text-[#849495] block text-[11px]">Subject (Common Name):</span>
              <span className="text-white font-bold">{certData.subject}</span>
            </div>
            <div>
              <span className="text-[#849495] block text-[11px]">Issuer (Authority):</span>
              <span className="text-[#00e8f8] font-bold">{certData.issuer}</span>
            </div>
            <div>
              <span className="text-[#849495] block text-[11px]">Key Specifications:</span>
              <span className="text-[#dee2f6]">{certData.keyLength}</span>
            </div>
          </div>

          <div className="p-3.5 rounded-lg bg-[#0e1321] border border-[#3b82f6]/20 space-y-2">
            <div>
              <span className="text-[#849495] block text-[11px]">Subject Alternative Names (SAN):</span>
              <div className="flex flex-wrap gap-1.5 mt-1">
                {certData.san.map((s) => (
                  <span
                    key={s}
                    className="px-2 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30 font-bold text-[11px]"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <span className="text-[#849495] block text-[11px]">HSTS Header:</span>
              <span className="text-[#10b981] font-bold">{certData.hsts}</span>
            </div>
            <div>
              <span className="text-[#849495] block text-[11px]">Port 80 Redirect:</span>
              <span className="text-[#10b981] font-bold">{certData.httpRedirect}</span>
            </div>
          </div>
        </div>
      </div>

      {/* TLS Protocol Negotiation Matrix */}
      <div className="rounded-xl bg-[#131c31] border border-[#3b82f6]/25 overflow-hidden">
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between font-mono text-xs text-white font-bold">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#00e8f8]" />
            <span>TLS Protocol Negotiation Matrix (Handshake Verification)</span>
          </div>
          <span className="text-[#10b981]">Legacy TLS 1.0/1.1 Prohibited</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#090e1c] text-[#849495] uppercase text-[10px] tracking-wider border-b border-[#3b82f6]/15">
              <tr>
                <th className="py-3 px-4">Protocol Version</th>
                <th className="py-3 px-4">Server Status</th>
                <th className="py-3 px-4">Observed Handshake Result</th>
                <th className="py-3 px-4">Compliance & Security Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#3b82f6]/10 text-[#dee2f6]">
              {protocolSupport.map((proto) => (
                <tr key={proto.protocol} className="hover:bg-[#1a1f2e]/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-white">{proto.protocol}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                        proto.status.includes('REJECTED')
                          ? 'bg-[#10b981]/15 text-[#10b981] border-[#10b981]/30'
                          : 'bg-[#00e8f8]/15 text-[#00e8f8] border-[#00e8f8]/30'
                      }`}
                    >
                      {proto.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#bac9cb]">{proto.handshake}</td>
                  <td className="py-3 px-4 text-[#849495] text-[11px]">{proto.risk}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Nginx SSL Configuration Block Preview */}
      <div className="rounded-xl bg-[#090e1c] border border-[#3b82f6]/30 overflow-hidden font-mono text-xs shadow-xl">
        <div className="px-4 py-2 bg-[#0e1321] border-b border-[#3b82f6]/20 flex items-center justify-between text-white font-bold">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#00e8f8]" />
            <span>/etc/nginx/sites-available/default (Hardened SSL Directives)</span>
          </div>
          <button
            onClick={handleCopy}
            className="p-1 rounded hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white"
            title="Copy Config"
          >
            {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
        <pre className="p-4 text-[#dee2f6] leading-relaxed select-text overflow-x-auto">
          {tlsConfigEvidence}
        </pre>
      </div>
    </div>
  );
};
