import React, { useState } from 'react';
import { ScreenId, PortScanItem, HardeningControl, RiskItem, SecurityTest, EvidenceRecord, ChecklistRequirement } from './types/labguard';
import {
  INITIAL_PORTS,
  INITIAL_HARDENING_CONTROLS,
  INITIAL_RISKS,
  INITIAL_TESTS,
  INITIAL_EVIDENCE,
  CHECKLIST_ITEMS,
} from './data/initial-state';
import { Sidebar } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { ThreatTicker } from './components/ThreatTicker';
import { AiAnalysisModal } from './components/AiAnalysisModal';
import { aiService, AiActionResult } from './services/ai-service';

// Screens
import { OverviewScreen } from './screens/OverviewScreen';
import { AssistantScreen } from './screens/AssistantScreen';
import { LabEnvironmentScreen } from './screens/LabEnvironmentScreen';
import { RulesOfEngagementScreen } from './screens/RulesOfEngagementScreen';
import { BaselineAssessmentScreen } from './screens/BaselineAssessmentScreen';
import { LinuxHardeningScreen } from './screens/LinuxHardeningScreen';
import { SshSecurityScreen } from './screens/SshSecurityScreen';
import { FirewallScreen } from './screens/FirewallScreen';
import { AppArmorScreen } from './screens/AppArmorScreen';
import { AuditdScreen } from './screens/AuditdScreen';
import { TlsAnalyzerScreen } from './screens/TlsAnalyzerScreen';
import { RiskAssessmentScreen } from './screens/RiskAssessmentScreen';
import { SecurityComparisonScreen } from './screens/SecurityComparisonScreen';
import { AutomationCenterScreen } from './screens/AutomationCenterScreen';
import { SecurityTestingScreen } from './screens/SecurityTestingScreen';
import { EvidenceCenterScreen } from './screens/EvidenceCenterScreen';
import { ReportGeneratorScreen } from './screens/ReportGeneratorScreen';
import { SubmissionReadinessScreen } from './screens/SubmissionReadinessScreen';
import { SettingsScreen } from './screens/SettingsScreen';

export default function App() {
  // Sync state with hash routing
  const getInitialScreen = (): ScreenId => {
    const hash = window.location.hash.replace('#', '') as ScreenId;
    const validScreens: ScreenId[] = [
      'overview', 'assistant', 'lab', 'roe', 'baseline', 'hardening',
      'ssh', 'firewall', 'apparmor', 'auditd', 'tls', 'risk',
      'comparison', 'automation', 'testing', 'evidence', 'report',
      'readiness', 'settings',
    ];
    return validScreens.includes(hash) ? hash : 'overview';
  };

  const [currentScreen, setCurrentScreenState] = useState<ScreenId>(getInitialScreen);

  const setCurrentScreen = (screen: ScreenId) => {
    setCurrentScreenState(screen);
    window.location.hash = screen;
  };

  // Listen to popstate / hashchange for browser back/forward buttons
  React.useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as ScreenId;
      if (hash && hash !== currentScreen) {
        setCurrentScreenState(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [currentScreen]);

  // Load persistent state from localStorage with fallback to INITIAL_*
  const [lynisScore, setLynisScore] = useState<{ baseline: number; current: number }>(() => {
    try {
      const saved = localStorage.getItem('labguard_lynis');
      return saved ? JSON.parse(saved) : { baseline: 54, current: 78 };
    } catch {
      return { baseline: 54, current: 78 };
    }
  });

  const [ports, setPorts] = useState<PortScanItem[]>(() => {
    try {
      const saved = localStorage.getItem('labguard_ports');
      return saved ? JSON.parse(saved) : INITIAL_PORTS;
    } catch {
      return INITIAL_PORTS;
    }
  });

  const [controls, setControls] = useState<HardeningControl[]>(() => {
    try {
      const saved = localStorage.getItem('labguard_controls');
      return saved ? JSON.parse(saved) : INITIAL_HARDENING_CONTROLS;
    } catch {
      return INITIAL_HARDENING_CONTROLS;
    }
  });

  const [risks, setRisks] = useState<RiskItem[]>(() => {
    try {
      const saved = localStorage.getItem('labguard_risks');
      return saved ? JSON.parse(saved) : INITIAL_RISKS;
    } catch {
      return INITIAL_RISKS;
    }
  });

  const [tests, setTests] = useState<SecurityTest[]>(() => {
    try {
      const saved = localStorage.getItem('labguard_tests');
      return saved ? JSON.parse(saved) : INITIAL_TESTS;
    } catch {
      return INITIAL_TESTS;
    }
  });

  const [evidenceList, setEvidenceList] = useState<EvidenceRecord[]>(() => {
    try {
      const saved = localStorage.getItem('labguard_evidence');
      return saved ? JSON.parse(saved) : INITIAL_EVIDENCE;
    } catch {
      return INITIAL_EVIDENCE;
    }
  });

  const [checklist, setChecklist] = useState<ChecklistRequirement[]>(() => {
    try {
      const saved = localStorage.getItem('labguard_checklist');
      return saved ? JSON.parse(saved) : CHECKLIST_ITEMS;
    } catch {
      return CHECKLIST_ITEMS;
    }
  });

  // Save to localStorage on state change
  React.useEffect(() => {
    try {
      localStorage.setItem('labguard_lynis', JSON.stringify(lynisScore));
      localStorage.setItem('labguard_ports', JSON.stringify(ports));
      localStorage.setItem('labguard_controls', JSON.stringify(controls));
      localStorage.setItem('labguard_risks', JSON.stringify(risks));
      localStorage.setItem('labguard_tests', JSON.stringify(tests));
      localStorage.setItem('labguard_evidence', JSON.stringify(evidenceList));
      localStorage.setItem('labguard_checklist', JSON.stringify(checklist));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [lynisScore, ports, controls, risks, tests, evidenceList, checklist]);

  // AI Modal State
  const [aiModal, setAiModal] = useState<{
    isOpen: boolean;
    result: AiActionResult | null;
    isLoading: boolean;
  }>({
    isOpen: false,
    result: null,
    isLoading: false,
  });

  const [assistantPrompt, setAssistantPrompt] = useState<string>('');

  // Global "Analyze My Server" Action
  const handleAnalyzeServer = async () => {
    setAiModal({ isOpen: true, result: null, isLoading: true });
    try {
      const summaryContext = {
        lynisScore,
        exposedPorts: ports.filter((p) => p.state === 'open'),
        activeRisks: risks.filter((r) => r.treatmentStatus !== 'Mitigated'),
        appliedControlsCount: controls.filter((c) => c.isApplied).length,
      };

      const res = await aiService.callAiAction(
        'analyzeServerPosture',
        summaryContext,
        'Perform a complete executive security analysis of this Ubuntu Linux server. Summarize findings, remaining exposures, and verify whether Lynis target improvement of >= 10 points is achieved.'
      );

      setAiModal({ isOpen: true, result: res, isLoading: false });
    } catch (err: any) {
      setAiModal({
        isOpen: true,
        result: {
          success: false,
          action: 'analyzeServerPosture',
          analysis: 'Analysis failed: ' + (err?.message || 'Server error'),
          source: 'fallback',
          timestamp: new Date().toISOString(),
        },
        isLoading: false,
      });
    }
  };

  // Specific AI analysis action caller
  const handleTriggerAiAnalysis = async (action: string, evidenceData: any) => {
    setAiModal({ isOpen: true, result: null, isLoading: true });
    try {
      const res = await aiService.callAiAction(action, evidenceData);
      setAiModal({ isOpen: true, result: res, isLoading: false });
    } catch (err: any) {
      setAiModal({
        isOpen: true,
        result: {
          success: false,
          action,
          analysis: 'Failed to run analysis: ' + (err?.message || 'Connection error'),
          source: 'fallback',
          timestamp: new Date().toISOString(),
        },
        isLoading: false,
      });
    }
  };

  // Toggle Hardening Control & Recompute Lynis Score
  const handleToggleControl = (controlId: string) => {
    setControls((prev) => {
      const next = prev.map((c) => (c.id === controlId ? { ...c, isApplied: !c.isApplied } : c));
      const appliedCount = next.filter((c) => c.isApplied).length;
      // Recompute score dynamically: base 54 + (applied / total) * 24
      const calculatedCurrent = Math.round(54 + (appliedCount / next.length) * 24);
      setLynisScore((s) => ({ ...s, current: calculatedCurrent }));
      return next;
    });
  };

  // Run a single test
  const handleRunTest = (testId: string) => {
    setTests((prev) =>
      prev.map((t) => (t.id === testId ? { ...t, status: 'running' } : t))
    );

    setTimeout(() => {
      setTests((prev) =>
        prev.map((t) =>
          t.id === testId
            ? {
                ...t,
                status: 'passed',
                timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
              }
            : t
        )
      );
    }, 700);
  };

  // Run all tests sequentially
  const handleRunAllTests = () => {
    setTests((prev) => prev.map((t) => ({ ...t, status: 'running' })));
    setTimeout(() => {
      setTests((prev) =>
        prev.map((t) => ({
          ...t,
          status: 'passed',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
        }))
      );
    }, 1200);
  };

  // Explain failed test
  const handleExplainFailure = (test: SecurityTest) => {
    handleTriggerAiAnalysis('explainTestFailure', test);
  };

  // Open Assistant with specific prompt
  const handleOpenAssistantWithPrompt = (prompt: string) => {
    setAssistantPrompt(prompt);
    setCurrentScreen('assistant');
  };

  // Toggle Checklist status
  const handleToggleChecklistStatus = (
    id: string,
    status: 'completed' | 'failed' | 'untested'
  ) => {
    setChecklist((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status } : item))
    );
  };

  // Update Risk Treatment status
  const handleUpdateRiskStatus = (
    id: string,
    status: 'Mitigated' | 'In Progress' | 'Accepted' | 'Open'
  ) => {
    setRisks((prev) =>
      prev.map((r) => (r.id === id ? { ...r, treatmentStatus: status } : r))
    );
  };

  // Add new evidence
  const handleAddEvidence = (record: EvidenceRecord) => {
    setEvidenceList((prev) => [record, ...prev]);
  };

  // Add new risk finding
  const handleAddRisk = (risk: RiskItem) => {
    setRisks((prev) => [risk, ...prev]);
  };

  // Delete risk finding
  const handleDeleteRisk = (id: string) => {
    setRisks((prev) => prev.filter((r) => r.id !== id));
  };

  // Reset to baseline demo data
  const handleResetData = () => {
    try {
      localStorage.removeItem('labguard_lynis');
      localStorage.removeItem('labguard_ports');
      localStorage.removeItem('labguard_controls');
      localStorage.removeItem('labguard_risks');
      localStorage.removeItem('labguard_tests');
      localStorage.removeItem('labguard_evidence');
      localStorage.removeItem('labguard_checklist');
    } catch {}
    setPorts(INITIAL_PORTS);
    setControls(INITIAL_HARDENING_CONTROLS);
    setRisks(INITIAL_RISKS);
    setTests(INITIAL_TESTS);
    setEvidenceList(INITIAL_EVIDENCE);
    setChecklist(CHECKLIST_ITEMS);
    setLynisScore({ baseline: 54, current: 78 });
    setCurrentScreen('overview');
  };

  // Render current screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'overview':
        return (
          <OverviewScreen
            onAnalyzeServer={handleAnalyzeServer}
            onOpenAssistantWithPrompt={handleOpenAssistantWithPrompt}
            onNavigate={setCurrentScreen}
            lynisScore={lynisScore}
            risks={risks}
            ports={ports}
            controls={controls}
            testsPassedCount={tests.filter((t) => t.status === 'passed').length}
            totalTestsCount={tests.length}
          />
        );
      case 'assistant':
        return (
          <AssistantScreen
            initialPrompt={assistantPrompt}
            evidenceList={evidenceList}
          />
        );
      case 'lab':
        return <LabEnvironmentScreen />;
      case 'roe':
        return <RulesOfEngagementScreen />;
      case 'baseline':
        return (
          <BaselineAssessmentScreen
            ports={ports}
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
            evidenceList={evidenceList}
          />
        );
      case 'hardening':
        return (
          <LinuxHardeningScreen
            controls={controls}
            onToggleControl={handleToggleControl}
            onTriggerAiRecommendation={(cat) =>
              handleTriggerAiAnalysis('analyzeLynisReport', { category: cat, controls })
            }
          />
        );
      case 'ssh':
        return (
          <SshSecurityScreen
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
            evidenceList={evidenceList}
          />
        );
      case 'firewall':
        return (
          <FirewallScreen
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
            evidenceList={evidenceList}
          />
        );
      case 'apparmor':
        return <AppArmorScreen onTriggerAiAnalysis={handleTriggerAiAnalysis} />;
      case 'auditd':
        return (
          <AuditdScreen
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
            evidenceList={evidenceList}
          />
        );
      case 'tls':
        return (
          <TlsAnalyzerScreen
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
            evidenceList={evidenceList}
          />
        );
      case 'risk':
        return (
          <RiskAssessmentScreen
            risks={risks}
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
            onUpdateTreatmentStatus={handleUpdateRiskStatus}
            onAddRisk={handleAddRisk}
            onDeleteRisk={handleDeleteRisk}
          />
        );
      case 'comparison':
        return (
          <SecurityComparisonScreen
            lynisScore={lynisScore}
            ports={ports}
            risks={risks}
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
          />
        );
      case 'automation':
        return <AutomationCenterScreen />;
      case 'testing':
        return (
          <SecurityTestingScreen
            tests={tests}
            onRunTest={handleRunTest}
            onRunAllTests={handleRunAllTests}
            onExplainFailure={handleExplainFailure}
          />
        );
      case 'evidence':
        return (
          <EvidenceCenterScreen
            evidenceList={evidenceList}
            onAddEvidence={handleAddEvidence}
            onTriggerAiAnalysis={handleTriggerAiAnalysis}
          />
        );
      case 'report':
        return (
          <ReportGeneratorScreen
            lynisScore={lynisScore}
            risks={risks}
            ports={ports}
            controls={controls}
            tests={tests}
          />
        );
      case 'readiness':
        return (
          <SubmissionReadinessScreen
            checklist={checklist}
            onToggleStatus={handleToggleChecklistStatus}
          />
        );
      case 'settings':
        return <SettingsScreen onResetData={handleResetData} />;
      default:
        return (
          <OverviewScreen
            onAnalyzeServer={handleAnalyzeServer}
            onOpenAssistantWithPrompt={handleOpenAssistantWithPrompt}
            onNavigate={setCurrentScreen}
            lynisScore={lynisScore}
            risks={risks}
            ports={ports}
            controls={controls}
            testsPassedCount={tests.filter((t) => t.status === 'passed').length}
            totalTestsCount={tests.length}
          />
        );
    }
  };

  return (
    <div className="flex h-screen bg-[#0e1321] text-[#dee2f6] overflow-hidden select-none">
      {/* Sidebar Navigation */}
      <Sidebar
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        lynisScore={lynisScore}
        openAssistantDrawer={() => handleOpenAssistantWithPrompt('What are the top three priority items for this server?')}
      />

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[#0e1321] soc-grid-bg">
        {/* Top Telemetry Header */}
        <TopNav
          onAnalyzeServer={handleAnalyzeServer}
          onOpenAssistant={() => handleOpenAssistantWithPrompt('Review active server telemetry and summarize security posture.')}
          isAnalyzing={aiModal.isLoading}
          activeRisksCount={risks.filter((r) => r.treatmentStatus !== 'Mitigated').length}
          completedChecksCount={checklist.filter((c) => c.status === 'completed').length}
          totalChecksCount={checklist.length}
        />

        {/* Real-time Threat Ticker */}
        <ThreatTicker
          onEventClick={(evt) =>
            handleOpenAssistantWithPrompt(`Explain threat event ${evt.id} (${evt.type}): ${evt.message}`)
          }
        />

        {/* Screen Canvas */}
        <main className="flex-1 overflow-y-auto">
          {renderScreen()}
        </main>
      </div>

      {/* Global AI Analysis Modal */}
      <AiAnalysisModal
        isOpen={aiModal.isOpen}
        onClose={() => setAiModal((m) => ({ ...m, isOpen: false }))}
        result={aiModal.result}
        isLoading={aiModal.isLoading}
        onSendToChat={(text) => handleOpenAssistantWithPrompt(`Elaborate on this analysis:\n${text}`)}
      />
    </div>
  );
}
