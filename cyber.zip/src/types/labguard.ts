export type ScreenId =
  | 'overview'
  | 'assistant'
  | 'lab'
  | 'roe'
  | 'baseline'
  | 'hardening'
  | 'ssh'
  | 'firewall'
  | 'apparmor'
  | 'auditd'
  | 'tls'
  | 'risk'
  | 'comparison'
  | 'automation'
  | 'testing'
  | 'evidence'
  | 'report'
  | 'readiness'
  | 'settings';

export interface PortScanItem {
  port: number;
  protocol: 'tcp' | 'udp';
  service: string;
  version: string;
  state: 'open' | 'closed' | 'filtered';
  riskLevel: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'SAFE';
  statusBefore: 'open' | 'closed';
  statusAfter: 'open' | 'closed';
  description: string;
}

export interface HardeningControl {
  id: string;
  category: 'SSH' | 'UFW' | 'AppArmor' | 'auditd' | 'Updates' | 'Services';
  title: string;
  currentConfig: string;
  recommendedConfig: string;
  securityRationale: string;
  riskIfNotImplemented: string;
  verificationProcedure: string;
  rollbackCommand: string;
  isApplied: boolean;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
}

export interface RiskItem {
  id: string;
  finding: string;
  affectedService: string;
  likelihood: number; // 1 to 5
  impact: number;     // 1 to 5
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  mitigation: string;
  treatmentStatus: 'Mitigated' | 'In Progress' | 'Accepted' | 'Open';
  residualRisk: 'LOW' | 'VERY LOW' | 'MEDIUM';
  evidenceRef: string;
  isConfirmed: boolean;
}

export interface SecurityTest {
  id: string;
  category: 'SSH' | 'Firewall' | 'TLS' | 'auditd' | 'AppArmor' | 'Lynis' | 'Services' | 'Reproducibility';
  name: string;
  command: string;
  expectedResult: string;
  actualResult: string;
  status: 'passed' | 'failed' | 'running';
  evidenceRef: string;
  timestamp: string;
  failureExplanation?: string;
  correctiveFix?: string;
}

export interface EvidenceRecord {
  id: string;
  title: string;
  category: 'Nmap' | 'Lynis' | 'SSH' | 'Firewall' | 'TLS' | 'auditd' | 'Screenshot' | 'Automation';
  type: 'Uploaded' | 'Automatically Collected' | 'Generated Template' | 'Verified Result';
  filename: string;
  timestamp: string;
  sha256: string;
  content: string;
  notes: string;
}

export interface ChecklistRequirement {
  id: string;
  title: string;
  category: string;
  description: string;
  status: 'completed' | 'failed' | 'untested';
  evidenceId?: string;
  verificationCmd?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  source?: 'gemini' | 'fallback' | 'system';
  evidenceAttached?: {
    id: string;
    title: string;
  };
}

export interface ThreatEvent {
  id: string;
  timestamp: string;
  type: string;
  severity: 'CRITICAL' | 'WARNING' | 'INFORMATIONAL' | 'LOW';
  source: string;
  target: string;
  message: string;
  status: string;
}
