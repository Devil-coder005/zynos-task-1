import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateRiskScore,
  calculateLynisDelta,
  evaluateExposedPorts,
  evaluateTlsCompliance,
  calculateReadinessProgress,
  validateLabIp,
  sanitizeFilename,
  validateEvidencePayload,
} from './security-rules';

test('calculateRiskScore returns correct level and score', () => {
  const critical = calculateRiskScore(5, 5);
  assert.equal(critical.score, 25);
  assert.equal(critical.level, 'CRITICAL');

  const high = calculateRiskScore(3, 4);
  assert.equal(high.score, 12);
  assert.equal(high.level, 'HIGH');

  const medium = calculateRiskScore(2, 4);
  assert.equal(medium.score, 8);
  assert.equal(medium.level, 'MEDIUM');

  const low = calculateRiskScore(1, 3);
  assert.equal(low.score, 3);
  assert.equal(low.level, 'LOW');

  const informational = calculateRiskScore(1, 1);
  assert.equal(informational.score, 1);
  assert.equal(informational.level, 'INFORMATIONAL');
});

test('calculateLynisDelta correctly assesses the 10-point academic requirement', () => {
  const baseline = 54;
  const targetPassed = 78;
  const resultPassed = calculateLynisDelta(baseline, targetPassed);

  assert.equal(resultPassed.delta, 24);
  assert.equal(resultPassed.meetsRequirement, true);
  assert.match(resultPassed.message, /Target achieved/);

  const targetFailed = 58;
  const resultFailed = calculateLynisDelta(baseline, targetFailed);
  assert.equal(resultFailed.delta, 4);
  assert.equal(resultFailed.meetsRequirement, false);
});

test('evaluateExposedPorts detects insecure services like Telnet and FTP', () => {
  const scan = [
    { port: 22, service: 'ssh', state: 'open' },
    { port: 23, service: 'telnet', state: 'open' },
    { port: 80, service: 'http', state: 'open' },
  ];
  const evalResult = evaluateExposedPorts(scan);
  assert.deepEqual(evalResult.dangerousPorts, [23]);
  assert.equal(evalResult.isHardened, false);

  const hardenedScan = [
    { port: 22, service: 'ssh', state: 'open' },
    { port: 443, service: 'https', state: 'open' },
  ];
  const hardenedEval = evaluateExposedPorts(hardenedScan);
  assert.deepEqual(hardenedEval.dangerousPorts, []);
  assert.equal(hardenedEval.isHardened, true);
});

test('evaluateTlsCompliance verifies HSTS and rejects TLS 1.0/1.1', () => {
  const vulnerableTls = {
    protocols: ['TLSv1.0', 'TLSv1.2'],
    hstsEnabled: false,
    sanMatches: true,
    cipherGrade: 'B' as const,
    certDaysRemaining: 45,
  };
  const vulResult = evaluateTlsCompliance(vulnerableTls);
  assert.equal(vulResult.isCompliant, false);
  assert.ok(vulResult.failures.some((f) => f.includes('Legacy protocols')));
  assert.ok(vulResult.failures.some((f) => f.includes('HSTS')));

  const secureTls = {
    protocols: ['TLSv1.2', 'TLSv1.3'],
    hstsEnabled: true,
    sanMatches: true,
    cipherGrade: 'A+' as const,
    certDaysRemaining: 90,
  };
  const secResult = evaluateTlsCompliance(secureTls);
  assert.equal(secResult.isCompliant, true);
  assert.equal(secResult.failures.length, 0);
});

test('calculateReadinessProgress calculates completion metrics', () => {
  const items = [
    { id: '1', status: 'completed' as const },
    { id: '2', status: 'completed' as const },
    { id: '3', status: 'failed' as const },
    { id: '4', status: 'untested' as const },
  ];
  const progress = calculateReadinessProgress(items);
  assert.equal(progress.total, 4);
  assert.equal(progress.completed, 2);
  assert.equal(progress.failed, 1);
  assert.equal(progress.untested, 1);
  assert.equal(progress.percentage, 50);
  assert.equal(progress.isReady, false);
});

test('validateLabIp accepts RFC1918 private lab addresses and rejects public IPs', () => {
  const validTarget = validateLabIp('192.168.56.10');
  assert.equal(validTarget.isValid, true);
  assert.equal(validTarget.isRfc1918, true);
  assert.equal(validTarget.inTargetSubnet, true);
  assert.equal(validTarget.error, undefined);

  const publicIp = validateLabIp('8.8.8.8');
  assert.equal(publicIp.isValid, true);
  assert.equal(publicIp.isRfc1918, false);
  assert.equal(publicIp.inTargetSubnet, false);
  assert.match(publicIp.error || '', /OUT OF SCOPE/);

  const invalidFormat = validateLabIp('192.168.56.999');
  assert.equal(invalidFormat.isValid, false);
});

test('sanitizeFilename removes directory traversal and illegal characters', () => {
  const unsafe = '../../etc/passwd.txt';
  const clean = sanitizeFilename(unsafe);
  assert.ok(!clean.includes('..'));
  assert.ok(!clean.includes('/'));

  const specialChars = 'nmap*scan:result?.log';
  const clean2 = sanitizeFilename(specialChars);
  assert.ok(!clean2.includes('*'));
  assert.ok(!clean2.includes(':'));
  assert.ok(!clean2.includes('?'));
});

test('validateEvidencePayload enforces content presence and maximum size limits', () => {
  const empty = validateEvidencePayload('');
  assert.equal(empty.isValid, false);

  const valid = validateEvidencePayload('Nmap scan report for 192.168.56.10\nHost is up.');
  assert.equal(valid.isValid, true);

  const hugePayload = 'A'.repeat(600 * 1024);
  const oversized = validateEvidencePayload(hugePayload, 512);
  assert.equal(oversized.isValid, false);
  assert.match(oversized.error || '', /exceeds maximum allowed upload size/);
});

