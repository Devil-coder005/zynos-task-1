/**
 * LABGUARD - Decoupled Security Rules and Mathematical Assessment Logic
 */

export interface RiskEvaluation {
  score: number;
  level: 'INFORMATIONAL' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  color: string;
}

export function calculateRiskScore(likelihood: number, impact: number): RiskEvaluation {
  const clampedL = Math.max(1, Math.min(5, Math.round(likelihood)));
  const clampedI = Math.max(1, Math.min(5, Math.round(impact)));
  const score = clampedL * clampedI;

  if (score >= 20) {
    return { score, level: 'CRITICAL', color: '#EF4444' };
  } else if (score >= 12) {
    return { score, level: 'HIGH', color: '#F87171' };
  } else if (score >= 6) {
    return { score, level: 'MEDIUM', color: '#F59E0B' };
  } else if (score >= 3) {
    return { score, level: 'LOW', color: '#38BDF8' };
  }
  return { score, level: 'INFORMATIONAL', color: '#10B981' };
}

export function calculateLynisDelta(initial: number, current: number): {
  delta: number;
  percentageChange: number;
  meetsRequirement: boolean;
  message: string;
} {
  const delta = current - initial;
  const percentageChange = initial > 0 ? Math.round((delta / initial) * 100) : 0;
  const meetsRequirement = delta >= 10;
  const message = meetsRequirement
    ? `Target achieved! Lynis hardening index improved by +${delta} points (Required: >=10 pts).`
    : `Target not met yet: improved by +${delta} points. Minimum +10 point improvement required for submission.`;

  return { delta, percentageChange, meetsRequirement, message };
}

const INSECURE_PORTS = new Set([21, 23, 25, 69, 110, 111, 135, 139, 445, 513, 514, 1433, 3306, 6379]);

export function evaluateExposedPorts(
  ports: Array<{ port: number; service: string; state: string }>
): {
  dangerousPorts: number[];
  openCount: number;
  isHardened: boolean;
  recommendations: string[];
} {
  const openPorts = ports.filter((p) => p.state.toLowerCase() === 'open');
  const dangerousPorts = openPorts
    .map((p) => p.port)
    .filter((port) => INSECURE_PORTS.has(port));

  const recommendations: string[] = [];
  if (dangerousPorts.includes(23)) {
    recommendations.push('Disable unencrypted Telnet (port 23); enforce SSH key authentication only.');
  }
  if (dangerousPorts.includes(21)) {
    recommendations.push('Disable FTP (port 21); migrate file transfers to SFTP over port 22.');
  }
  if (dangerousPorts.includes(111)) {
    recommendations.push('Disable rpcbind (port 111) if NFS is not required on the target server.');
  }
  if (openPorts.some((p) => p.port === 80)) {
    recommendations.push('Ensure HTTP (port 80) redirects permanently (301) to HTTPS (port 443).');
  }

  const isHardened = dangerousPorts.length === 0 && openPorts.length <= 3;

  return {
    dangerousPorts,
    openCount: openPorts.length,
    isHardened,
    recommendations,
  };
}

export interface TlsCheckConfig {
  protocols: string[];
  hstsEnabled: boolean;
  sanMatches: boolean;
  cipherGrade: 'A+' | 'A' | 'B' | 'C' | 'F';
  certDaysRemaining: number;
}

export function evaluateTlsCompliance(config: TlsCheckConfig): {
  isCompliant: boolean;
  failures: string[];
  recommendations: string[];
} {
  const failures: string[] = [];
  const recommendations: string[] = [];

  const legacyProtocols = config.protocols.filter((p) =>
    ['SSLv2', 'SSLv3', 'TLSv1', 'TLSv1.0', 'TLSv1.1'].includes(p)
  );

  if (legacyProtocols.length > 0) {
    failures.push(`Legacy protocols allowed: ${legacyProtocols.join(', ')}`);
    recommendations.push('Enforce ssl_protocols TLSv1.2 TLSv1.3 in nginx config; reject TLS 1.0 and 1.1.');
  }

  const hasModern = config.protocols.some((p) => ['TLSv1.2', 'TLSv1.3'].includes(p));
  if (!hasModern) {
    failures.push('Modern TLS (1.2 or 1.3) is not enabled.');
    recommendations.push('Enable TLSv1.2 and TLSv1.3 for strong cryptographic forward secrecy.');
  }

  if (!config.hstsEnabled) {
    failures.push('HTTP Strict Transport Security (HSTS) header is missing.');
    recommendations.push('Add header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;');
  }

  if (!config.sanMatches) {
    failures.push('Subject Alternative Name (SAN) does not match the server hostname/FQDN.');
    recommendations.push('Reissue certificate with SAN extension matching both IP and DNS hostnames.');
  }

  if (config.certDaysRemaining <= 0) {
    failures.push('TLS certificate is expired.');
    recommendations.push('Renew certificate via internal Lab CA immediately.');
  } else if (config.certDaysRemaining < 30) {
    recommendations.push(`Certificate expires in ${config.certDaysRemaining} days; schedule renewal.`);
  }

  return {
    isCompliant: failures.length === 0,
    failures,
    recommendations,
  };
}

export interface ChecklistItem {
  id: string;
  status: 'completed' | 'failed' | 'untested';
}

export function calculateReadinessProgress(items: ChecklistItem[]): {
  total: number;
  completed: number;
  failed: number;
  untested: number;
  percentage: number;
  isReady: boolean;
} {
  const total = items.length;
  if (total === 0) {
    return { total: 0, completed: 0, failed: 0, untested: 0, percentage: 0, isReady: false };
  }

  const completed = items.filter((i) => i.status === 'completed').length;
  const failed = items.filter((i) => i.status === 'failed').length;
  const untested = items.filter((i) => i.status === 'untested').length;

  const percentage = Math.round((completed / total) * 100);
  const isReady = completed === total && failed === 0;

  return {
    total,
    completed,
    failed,
    untested,
    percentage,
    isReady,
  };
}

export function validateLabIp(ip: string): {
  isValid: boolean;
  isRfc1918: boolean;
  inTargetSubnet: boolean;
  error?: string;
} {
  const trimmed = ip.trim();
  const parts = trimmed.split('.');
  if (parts.length !== 4) {
    return { isValid: false, isRfc1918: false, inTargetSubnet: false, error: 'Invalid IPv4 address format (requires 4 octets).' };
  }

  const octets = parts.map((p) => Number(p));
  for (let i = 0; i < 4; i++) {
    const oct = octets[i];
    if (isNaN(oct) || oct < 0 || oct > 255 || parts[i] !== String(oct)) {
      return { isValid: false, isRfc1918: false, inTargetSubnet: false, error: `Invalid octet ${parts[i]}. Must be integer between 0 and 255.` };
    }
  }

  // RFC1918 check:
  // 10.0.0.0 - 10.255.255.255 (10.0.0.0/8)
  // 172.16.0.0 - 172.31.255.255 (172.16.0.0/12)
  // 192.168.0.0 - 192.168.255.255 (192.168.0.0/16)
  const is10 = octets[0] === 10;
  const is172 = octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31;
  const is192 = octets[0] === 192 && octets[1] === 168;
  const isRfc1918 = is10 || is172 || is192;

  if (!isRfc1918) {
    return {
      isValid: true,
      isRfc1918: false,
      inTargetSubnet: false,
      error: `OUT OF SCOPE: ${trimmed} is a public Internet IP address. Assessment is strictly restricted to isolated RFC1918 private lab networks.`,
    };
  }

  // Target lab subnet check: 192.168.56.0/24 (VirtualBox host-only vboxnet0)
  const inTargetSubnet = octets[0] === 192 && octets[1] === 168 && octets[2] === 56;

  return {
    isValid: true,
    isRfc1918: true,
    inTargetSubnet,
    error: inTargetSubnet
      ? undefined
      : `NOTICE: IP is RFC1918 private but outside standard lab host-only subnet (192.168.56.0/24). Confirm routing bridge.`,
  };
}

export function sanitizeFilename(filename: string): string {
  // Strip directory traversal patterns
  let clean = filename.replace(/(\.\.[\/\\])+/g, '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_');
  // Trim spaces and dots
  clean = clean.trim().replace(/^\.+/, '');
  if (!clean) clean = 'evidence_artifact.txt';
  if (clean.length > 80) {
    const extIdx = clean.lastIndexOf('.');
    const ext = extIdx !== -1 ? clean.slice(extIdx) : '';
    clean = clean.slice(0, 80 - ext.length) + ext;
  }
  return clean;
}

export function validateEvidencePayload(
  content: string,
  maxSizeKb = 512
): { isValid: boolean; error?: string; length: number } {
  if (!content || content.trim().length === 0) {
    return { isValid: false, error: 'Evidence artifact content cannot be empty.', length: 0 };
  }

  const length = content.length;
  const maxBytes = maxSizeKb * 1024;
  if (length > maxBytes) {
    return {
      isValid: false,
      error: `Artifact exceeds maximum allowed upload size (${maxSizeKb} KB). Received ${Math.round(length / 1024)} KB.`,
      length,
    };
  }

  return { isValid: true, length };
}

