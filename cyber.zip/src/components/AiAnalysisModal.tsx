import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Copy,
  Check,
  Download,
  Bot,
  ShieldCheck,
  Terminal,
  ExternalLink,
} from 'lucide-react';
import { AiActionResult } from '../services/ai-service';

interface AiAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: AiActionResult | null;
  isLoading: boolean;
  onSendToChat?: (text: string) => void;
}

export const AiAnalysisModal: React.FC<AiAnalysisModalProps> = ({
  isOpen,
  onClose,
  result,
  isLoading,
  onSendToChat,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    if (result?.analysis) {
      navigator.clipboard.writeText(result.analysis);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    if (!result?.analysis) return;
    const blob = new Blob([result.analysis], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LABGUARD_AI_Analysis_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-4xl max-h-[88vh] bg-[#131c31] border border-[#00e8f8]/40 rounded-xl shadow-[0_0_40px_rgba(0,232,248,0.2)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#00e8f8]/15 border border-[#00e8f8]/30">
              <Sparkles className="w-5 h-5 text-[#00e8f8] animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base font-mono">
                  LABGUARD AI Security Analysis
                </h3>
                {result?.source && (
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#00e8f8]/20 text-[#00e8f8] border border-[#00e8f8]/30 font-semibold">
                    Engine: {result.source === 'gemini' ? 'Gemini 3.8 Flash' : 'Verified SOC Rules'}
                  </span>
                )}
              </div>
              <p className="text-xs text-[#94a3b8]">
                Evidence-backed Linux security assessment and verified mitigation procedure
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {result?.analysis && (
              <>
                <button
                  onClick={handleCopy}
                  className="p-2 rounded-md hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white transition-colors"
                  title="Copy analysis"
                >
                  {copied ? <Check className="w-4 h-4 text-[#10b981]" /> : <Copy className="w-4 h-4" />}
                </button>
                <button
                  onClick={handleDownload}
                  className="p-2 rounded-md hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white transition-colors"
                  title="Export Markdown"
                >
                  <Download className="w-4 h-4" />
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-md hover:bg-[#1a1f2e] text-[#bac9cb] hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 font-mono text-xs space-y-4">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative">
                <div className="w-14 h-14 rounded-full border-2 border-[#00e8f8]/30 border-t-[#00e8f8] animate-spin" />
                <Sparkles className="w-6 h-6 text-[#00e8f8] absolute inset-0 m-auto animate-pulse" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Inspecting Server Telemetry & Evidence...</p>
                <p className="text-xs text-[#94a3b8] mt-1">
                  Correlating Nmap sockets, sshd_config, UFW rules, and Lynis metrics
                </p>
              </div>
            </div>
          ) : result?.analysis ? (
            <div className="space-y-4">
              {/* Evidence banner */}
              <div className="p-3 rounded-lg bg-[#090e1c] border border-[#3b82f6]/20 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-[#00e8f8]">
                  <ShieldCheck className="w-4 h-4 text-[#10b981]" />
                  <span>Target: ubuntu-target-vm (192.168.56.10)</span>
                </div>
                <span className="text-[#94a3b8] text-[11px]">
                  Generated: {new Date(result.timestamp).toLocaleTimeString()}
                </span>
              </div>

              {/* Rendered content */}
              <div className="p-5 rounded-lg bg-[#090e1c] border border-[#3b82f6]/25 text-[#dee2f6] leading-relaxed whitespace-pre-wrap font-mono text-xs select-text">
                {result.analysis}
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-[#94a3b8]">
              No analysis data available. Run an assessment to generate insights.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#3b82f6]/20 bg-[#0e1321] flex items-center justify-between">
          <span className="text-[11px] text-[#849495] font-mono">
            Verified evidence mode active. Findings matched against CIS Ubuntu Benchmark.
          </span>
          <div className="flex items-center gap-3">
            {onSendToChat && result?.analysis && (
              <button
                onClick={() => {
                  onSendToChat(result.analysis);
                  onClose();
                }}
                className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#00e8f8] border border-[#00e8f8]/30 font-mono text-xs font-semibold"
              >
                <Bot className="w-4 h-4" />
                <span>Discuss with Assistant</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-md bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-bold font-mono text-xs transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
