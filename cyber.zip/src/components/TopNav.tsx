import React from 'react';
import {
  Sparkles,
  Bot,
  ShieldAlert,
  Terminal,
  Activity,
  Layers,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

interface TopNavProps {
  onAnalyzeServer: () => void;
  onOpenAssistant: () => void;
  isAnalyzing: boolean;
  activeRisksCount: number;
  completedChecksCount: number;
  totalChecksCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  onAnalyzeServer,
  onOpenAssistant,
  isAnalyzing,
  activeRisksCount,
  completedChecksCount,
  totalChecksCount,
}) => {
  return (
    <header className="h-14 border-b border-[#3b82f6]/20 bg-[#0e1321]/95 backdrop-blur-md px-6 flex items-center justify-between z-20 shrink-0">
      {/* Left: SOC Telemetry Metrics */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 font-mono text-xs text-[#dee2f6]">
          <Activity className="w-4 h-4 text-[#00e8f8] animate-pulse" />
          <span className="text-[#94a3b8]">Target:</span>
          <span className="font-semibold text-white bg-[#131c31] px-2 py-0.5 rounded border border-[#3b82f6]/20">
            ubuntu-target-vm (192.168.56.10)
          </span>
          <span className="text-[10px] text-[#10b981] bg-[#10b981]/15 px-1.5 py-0.5 rounded border border-[#10b981]/30 font-bold">
            ISOLATED
          </span>
        </div>

        <div className="hidden lg:flex items-center gap-4 text-xs font-mono text-[#bac9cb]">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-[#f59e0b]" />
            <span>Open Risks:</span>
            <span className="text-white font-bold">{activeRisksCount}</span>
          </div>

          <div className="h-3 w-px bg-[#3b82f6]/20" />

          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
            <span>Readiness:</span>
            <span className="text-white font-bold">
              {completedChecksCount}/{totalChecksCount}
            </span>
          </div>
        </div>
      </div>

      {/* Right: Primary AI Triggers & Controls */}
      <div className="flex items-center gap-3">
        {/* Ask LABGUARD AI Button */}
        <button
          onClick={onOpenAssistant}
          className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#131c31] hover:bg-[#1a1f2e] text-[#dee2f6] hover:text-[#00e8f8] border border-[#3b82f6]/30 text-xs font-mono font-medium transition-all"
        >
          <Bot className="w-4 h-4 text-[#00e8f8]" />
          <span className="hidden sm:inline">Ask LABGUARD AI</span>
        </button>

        {/* Analyze My Server Prominent Action */}
        <button
          onClick={onAnalyzeServer}
          disabled={isAnalyzing}
          className="flex items-center gap-2 px-4 py-1.5 rounded-md bg-[#00e8f8] hover:bg-[#82f3ff] text-[#00363b] font-bold text-xs font-mono transition-all duration-150 shadow-[0_0_15px_rgba(0,232,248,0.35)] disabled:opacity-60 cursor-pointer"
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-[#00363b]" />
              <span>Analyzing Server...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-[#00363b]" />
              <span>Analyze My Server</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
