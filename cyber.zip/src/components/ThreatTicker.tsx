import React, { useState, useEffect } from 'react';
import { ShieldAlert, Radio, AlertTriangle, CheckCircle, ChevronRight } from 'lucide-react';
import { ThreatEvent } from '../types/labguard';

interface ThreatTickerProps {
  onEventClick?: (event: ThreatEvent) => void;
}

export const ThreatTicker: React.FC<ThreatTickerProps> = ({ onEventClick }) => {
  const [events, setEvents] = useState<ThreatEvent[]>([
    {
      id: 'EVT-9041',
      timestamp: 'Just now',
      type: 'PORT_SCAN_PROBE',
      severity: 'WARNING',
      source: '192.168.56.20',
      target: '192.168.56.10:23',
      message: 'TCP SYN probe to decommissioned Telnet (port 23) dropped by UFW Default Deny rule.',
      status: 'BLOCKED_BY_UFW',
    },
    {
      id: 'EVT-9042',
      timestamp: '2m ago',
      type: 'SSH_AUTH_FAIL',
      severity: 'CRITICAL',
      source: '192.168.56.20',
      target: '192.168.56.10:22',
      message: 'Root password login attempt rejected: PermitRootLogin=no policy enforced in sshd_config.',
      status: 'AUTH_REJECTED',
    },
    {
      id: 'EVT-9043',
      timestamp: '4m ago',
      type: 'TLS_HANDSHAKE',
      severity: 'INFORMATIONAL',
      source: '192.168.56.20',
      target: '192.168.56.10:443',
      message: 'Modern TLS 1.3 handshake verified: Cipher TLS_AES_256_GCM_SHA384 forward secrecy confirmed.',
      status: 'VERIFIED_OK',
    },
    {
      id: 'EVT-9044',
      timestamp: '6m ago',
      type: 'AUDITD_SYSCALL',
      severity: 'LOW',
      source: 'local',
      target: '/etc/shadow',
      message: 'Auditd intercepted read access to /etc/shadow by pam_unix [AUID=1000]. Event logged.',
      status: 'AUDIT_RECORDED',
    },
  ]);

  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % events.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [events.length]);

  const currentEvent = events[currentIndex];

  const severityColor = (sev: string) => {
    switch (sev) {
      case 'CRITICAL':
        return 'text-[#ef4444] border-[#ef4444]/40 bg-[#ef4444]/15';
      case 'WARNING':
        return 'text-[#f59e0b] border-[#f59e0b]/40 bg-[#f59e0b]/15';
      case 'INFORMATIONAL':
        return 'text-[#00e8f8] border-[#00e8f8]/40 bg-[#00e8f8]/15';
      default:
        return 'text-[#10b981] border-[#10b981]/40 bg-[#10b981]/15';
    }
  };

  return (
    <div className="bg-[#090e1c] border-b border-[#3b82f6]/20 px-6 py-2 flex items-center justify-between text-xs font-mono shrink-0 select-none">
      <div className="flex items-center gap-3 min-w-0">
        <div className="flex items-center gap-1.5 text-[#00e8f8] shrink-0 font-bold tracking-wider">
          <Radio className="w-3.5 h-3.5 text-[#ef4444] animate-ping" />
          <span className="text-[11px] uppercase tracking-wide">SOC REAL-TIME THREAT FEED:</span>
        </div>

        {currentEvent && (
          <div
            onClick={() => onEventClick && onEventClick(currentEvent)}
            className="flex items-center gap-2 truncate cursor-pointer hover:opacity-90 transition-opacity"
          >
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded border font-bold uppercase shrink-0 ${severityColor(
                currentEvent.severity
              )}`}
            >
              {currentEvent.severity}
            </span>
            <span className="text-[#dee2f6] font-semibold shrink-0">[{currentEvent.type}]</span>
            <span className="text-[#bac9cb] truncate">{currentEvent.message}</span>
            <span className="text-[#849495] text-[10px] shrink-0 hidden md:inline">
              ({currentEvent.timestamp})
            </span>
          </div>
        )}
      </div>

      <div className="hidden sm:flex items-center gap-2 shrink-0 text-[#849495] text-[11px]">
        <span>
          Event {currentIndex + 1} of {events.length}
        </span>
        <button
          onClick={() => setCurrentIndex((prev) => (prev + 1) % events.length)}
          className="p-1 hover:text-[#00e8f8] transition-colors"
          title="Next Alert"
        >
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
