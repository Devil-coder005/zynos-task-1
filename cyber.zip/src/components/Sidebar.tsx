import React from 'react';
import {
  Shield,
  Bot,
  Network,
  FileCheck2,
  Terminal,
  Cpu,
  Lock,
  Flame,
  KeyRound,
  FileText,
  CheckSquare,
  Settings,
  Scale,
  Sparkles,
  GitCompare,
  PlaySquare,
  AlertOctagon,
  FileCode,
  Radio,
} from 'lucide-react';
import { ScreenId } from '../types/labguard';

interface SidebarProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  lynisScore: { baseline: number; current: number };
  openAssistantDrawer: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onNavigate,
  lynisScore,
  openAssistantDrawer,
}) => {
  const navSections = [
    {
      label: 'COMMAND & AI',
      items: [
        { id: 'overview' as ScreenId, label: 'AI Overview', icon: Sparkles, badge: 'SOC' },
        { id: 'assistant' as ScreenId, label: 'AI Security Assistant', icon: Bot, badge: 'AI' },
      ],
    },
    {
      label: 'LAB & SCOPE',
      items: [
        { id: 'lab' as ScreenId, label: 'Lab Environment', icon: Network },
        { id: 'roe' as ScreenId, label: 'Rules of Engagement', icon: FileCheck2 },
      ],
    },
    {
      label: 'ASSESSMENT & AUDIT',
      items: [
        { id: 'baseline' as ScreenId, label: 'Baseline Assessment', icon: Terminal },
        { id: 'comparison' as ScreenId, label: 'Security Comparison', icon: GitCompare, badge: '+24' },
        { id: 'risk' as ScreenId, label: 'AI Risk Assessment', icon: AlertOctagon },
      ],
    },
    {
      label: 'LINUX HARDENING',
      items: [
        { id: 'hardening' as ScreenId, label: 'Linux Hardening', icon: Cpu },
        { id: 'ssh' as ScreenId, label: 'SSH Security', icon: Lock },
        { id: 'firewall' as ScreenId, label: 'Firewall Management', icon: Flame },
        { id: 'apparmor' as ScreenId, label: 'AppArmor MAC', icon: Shield },
        { id: 'auditd' as ScreenId, label: 'Auditd Monitoring', icon: Radio },
        { id: 'tls' as ScreenId, label: 'TLS & Certificates', icon: KeyRound },
      ],
    },
    {
      label: 'TESTING & EVIDENCE',
      items: [
        { id: 'testing' as ScreenId, label: 'Security Testing', icon: CheckSquare, badge: '12/12' },
        { id: 'automation' as ScreenId, label: 'Automation Center', icon: PlaySquare },
        { id: 'evidence' as ScreenId, label: 'Evidence Center', icon: FileCode },
      ],
    },
    {
      label: 'REPORT & SUBMISSION',
      items: [
        { id: 'report' as ScreenId, label: 'AI Report Generator', icon: FileText, badge: '5-Page' },
        { id: 'readiness' as ScreenId, label: 'Submission Readiness', icon: Scale, badge: '22/22' },
        { id: 'settings' as ScreenId, label: 'Settings', icon: Settings },
      ],
    },
  ];

  return (
    <aside className="w-68 bg-[#090e1c] border-r border-[#3b82f6]/20 flex flex-col h-screen shrink-0 select-none z-30">
      {/* Brand Header */}
      <div className="p-4 border-b border-[#3b82f6]/15 bg-[#0e1321]/90">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-[#00e8f8]/20 to-[#3b82f6]/30 border border-[#00e8f8]/50 shadow-[0_0_15px_rgba(0,232,248,0.2)]">
            <Shield className="w-5 h-5 text-[#00e8f8]" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#10b981] rounded-full ring-2 ring-[#090e1c] animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-wider text-white text-base font-mono">LABGUARD</span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/30 font-semibold">
                AI SOC
              </span>
            </div>
            <p className="text-[11px] text-[#94a3b8] tracking-tight">Secure. Assess. Verify. Improve.</p>
          </div>
        </div>

        {/* Target telemetry strip */}
        <div className="mt-3 p-2 rounded-md bg-[#131c31] border border-[#3b82f6]/15 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#10b981]" />
            <span className="text-[#dee2f6]">192.168.56.10</span>
          </div>
          <span className="text-[10px] text-[#00e8f8] bg-[#00e8f8]/10 px-1.5 py-0.5 rounded font-medium">
            UBUNTU 22.04
          </span>
        </div>

        {/* Lynis Hardening Progress Meter */}
        <div className="mt-2.5 pt-2 border-t border-[#3b82f6]/10 flex items-center justify-between text-[11px] font-mono">
          <span className="text-[#94a3b8]">Lynis Hardening:</span>
          <span className="font-bold text-[#10b981]">
            {lynisScore.baseline} &rarr; {lynisScore.current}{' '}
            <span className="text-[#00e8f8] text-[10px] font-normal">(+{lynisScore.current - lynisScore.baseline} pts)</span>
          </span>
        </div>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4">
        {navSections.map((sec) => (
          <div key={sec.label}>
            <div className="px-2 mb-1.5 text-[10px] font-mono font-semibold tracking-wider text-[#94a3b8]/70 uppercase">
              {sec.label}
            </div>
            <div className="space-y-0.5">
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-md text-xs font-medium transition-all duration-150 group ${
                      isActive
                        ? 'bg-[#00e8f8]/15 text-[#00e8f8] border border-[#00e8f8]/40 shadow-[0_0_12px_rgba(0,232,248,0.15)] font-semibold'
                        : 'text-[#bac9cb] hover:text-white hover:bg-[#131c31] border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          isActive ? 'text-[#00e8f8]' : 'text-[#849495] group-hover:text-[#00e8f8]'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.2 rounded shrink-0 ${
                          isActive
                            ? 'bg-[#00e8f8] text-[#00363b] font-bold'
                            : 'bg-[#1a1f2e] text-[#849495] border border-[#3b82f6]/20'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* AI Assistant Quick Launcher Footer */}
      <div className="p-3 border-t border-[#3b82f6]/20 bg-[#0e1321] space-y-2">
        <button
          onClick={openAssistantDrawer}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-md bg-gradient-to-r from-[#00e8f8]/20 via-[#0566d9]/30 to-[#00e8f8]/20 border border-[#00e8f8]/40 text-[#00e8f8] hover:text-white hover:border-[#00e8f8] hover:shadow-[0_0_15px_rgba(0,232,248,0.25)] text-xs font-mono font-semibold transition-all"
        >
          <Bot className="w-4 h-4" />
          <span>Ask LABGUARD AI</span>
        </button>

        <div className="flex items-center justify-between text-[10px] font-mono text-[#849495] px-1">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00e8f8] animate-ping" />
            Gemini 3.8 Flash
          </span>
          <span className="text-[#10b981]">ONLINE</span>
        </div>
      </div>
    </aside>
  );
};
