import {
  PortScanItem,
  HardeningControl,
  RiskItem,
  SecurityTest,
  EvidenceRecord,
  ChecklistRequirement,
  ThreatEvent,
} from '../types/labguard';

export const INITIAL_PORTS: PortScanItem[] = [
  {
    port: 21,
    protocol: 'tcp',
    service: 'ftp',
    version: 'vsftpd 3.0.3',
    state: 'closed', // after hardening
    statusBefore: 'open',
    statusAfter: 'closed',
    riskLevel: 'HIGH',
    description: 'Unencrypted File Transfer Protocol; transmits passwords in cleartext.',
  },
  {
    port: 22,
    protocol: 'tcp',
    service: 'ssh',
    version: 'OpenSSH 8.9p1 Ubuntu-3ubuntu0.6',
    state: 'open',
    statusBefore: 'open',
    statusAfter: 'open',
    riskLevel: 'LOW',
    description: 'Secure Shell remote administration; hardened to key-only authentication.',
  },
  {
    port: 23,
    protocol: 'tcp',
    service: 'telnet',
    version: 'Linux telnetd',
    state: 'closed', // after hardening
    statusBefore: 'open',
    statusAfter: 'closed',
    riskLevel: 'CRITICAL',
    description: 'Cleartext terminal protocol; severe vulnerability to network packet sniffing.',
  },
  {
    port: 80,
    protocol: 'tcp',
    service: 'http',
    version: 'nginx 1.18.0 (Ubuntu)',
    state: 'open',
    statusBefore: 'open',
    statusAfter: 'open',
    riskLevel: 'MEDIUM',
    description: 'Standard HTTP web server; configured with 301 Permanent Redirect to HTTPS 443.',
  },
  {
    port: 111,
    protocol: 'tcp',
    service: 'rpcbind',
    version: '2-4 (RPC #100000)',
    state: 'closed',
    statusBefore: 'open',
    statusAfter: 'closed',
    riskLevel: 'MEDIUM',
    description: 'Remote Procedure Call mapper; unnecessary legacy service expanding attack surface.',
  },
  {
    port: 443,
    protocol: 'tcp',
    service: 'https',
    version: 'nginx 1.18.0 (TLSv1.2/1.3)',
    state: 'open',
    statusBefore: 'closed',
    statusAfter: 'open',
    riskLevel: 'SAFE',
    description: 'Encrypted web portal with internal Lab CA TLS certificate and HSTS enabled.',
  },
  {
    port: 3306,
    protocol: 'tcp',
    service: 'mysql',
    version: 'MySQL 8.0.35',
    state: 'closed',
    statusBefore: 'open',
    statusAfter: 'closed',
    riskLevel: 'HIGH',
    description: 'Database daemon; bound to 127.0.0.1 localhost only, not exposed to subnet.',
  },
];

export const INITIAL_HARDENING_CONTROLS: HardeningControl[] = [
  {
    id: 'CTRL-SSH-01',
    category: 'SSH',
    title: 'Disable Root Login over SSH',
    currentConfig: 'PermitRootLogin no',
    recommendedConfig: 'PermitRootLogin no',
    securityRationale: 'Direct root login enables attackers to conduct automated brute-force attacks against the highest-privileged account.',
    riskIfNotImplemented: 'Compromise of the root account grants instant complete control of the Linux operating system.',
    verificationProcedure: 'sshd -T | grep -i permitrootlogin',
    rollbackCommand: "sudo sed -i 's/^PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config && sudo systemctl restart ssh",
    isApplied: true,
    severity: 'CRITICAL',
  },
  {
    id: 'CTRL-SSH-02',
    category: 'SSH',
    title: 'Enforce Key-Based Authentication (Disable Passwords)',
    currentConfig: 'PasswordAuthentication no',
    recommendedConfig: 'PasswordAuthentication no',
    securityRationale: 'Passwords are vulnerable to credential stuffing, dictionary attacks, and interception.',
    riskIfNotImplemented: 'Weak user passwords can be cracked via Hydra or Medusa within seconds on isolated subnets.',
    verificationProcedure: 'sshd -T | grep -i passwordauthentication',
    rollbackCommand: "sudo sed -i 's/^PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config && sudo systemctl restart ssh",
    isApplied: true,
    severity: 'CRITICAL',
  },
  {
    id: 'CTRL-SSH-03',
    category: 'SSH',
    title: 'Limit Maximum Authentication Tries',
    currentConfig: 'MaxAuthTries 3',
    recommendedConfig: 'MaxAuthTries 3',
    securityRationale: 'Restricting failed authentication attempts per connection forces attackers to reconnect and triggers Fail2ban.',
    riskIfNotImplemented: 'Attackers can attempt hundreds of passwords within a single TCP session.',
    verificationProcedure: 'sshd -T | grep -i maxauthtries',
    rollbackCommand: "sudo sed -i 's/^MaxAuthTries.*/MaxAuthTries 6/' /etc/ssh/sshd_config && sudo systemctl restart ssh",
    isApplied: true,
    severity: 'MEDIUM',
  },
  {
    id: 'CTRL-UFW-01',
    category: 'UFW',
    title: 'Default Deny Inbound Firewall Policy',
    currentConfig: 'Status: active | Default: deny (incoming), allow (outgoing)',
    recommendedConfig: 'Status: active | Default: deny (incoming), allow (outgoing)',
    securityRationale: 'Principle of Least Privilege at the network layer: drop all packets unless explicitly authorized.',
    riskIfNotImplemented: 'Any newly bound network service becomes automatically accessible to any host on the network.',
    verificationProcedure: 'sudo ufw status verbose',
    rollbackCommand: 'sudo ufw default allow incoming && sudo ufw reload',
    isApplied: true,
    severity: 'CRITICAL',
  },
  {
    id: 'CTRL-UFW-02',
    category: 'UFW',
    title: 'Rate-Limit SSH Connections',
    currentConfig: '22/tcp LIMIT in from any',
    recommendedConfig: '22/tcp LIMIT in from any',
    securityRationale: 'UFW rate limiting denies connections from an IP that attempts to initiate 6 or more connections in 30 seconds.',
    riskIfNotImplemented: 'Network saturation and SSH daemon connection exhaustion attacks.',
    verificationProcedure: 'sudo ufw status | grep 22/tcp',
    rollbackCommand: 'sudo ufw delete limit 22/tcp && sudo ufw allow 22/tcp',
    isApplied: true,
    severity: 'MEDIUM',
  },
  {
    id: 'CTRL-SRV-01',
    category: 'Services',
    title: 'Decommission Telnet and FTP Services',
    currentConfig: 'telnet.socket (masked/stopped), vsftpd (disabled/stopped)',
    recommendedConfig: 'Purge telnetd and vsftpd packages entirely',
    securityRationale: 'Cleartext protocols have no place on modern infrastructure. SFTP replaces FTP; SSH replaces Telnet.',
    riskIfNotImplemented: 'Plaintext sniffable credentials captured by Wireshark/tcpdump on shared hypervisor virtual switches.',
    verificationProcedure: 'systemctl is-active telnet vsftpd || true',
    rollbackCommand: 'sudo systemctl unmask telnet.socket && sudo systemctl start vsftpd',
    isApplied: true,
    severity: 'CRITICAL',
  },
  {
    id: 'CTRL-AA-01',
    category: 'AppArmor',
    title: 'Enforce Confinement for Nginx and Network Daemons',
    currentConfig: '18 profiles in enforce mode, 0 in complain mode',
    recommendedConfig: 'All active internet-facing daemons confined in enforce mode',
    securityRationale: 'Mandatory Access Control (MAC) limits kernel damage and file access if a web application vulnerability is exploited.',
    riskIfNotImplemented: 'Remote Code Execution (RCE) in web service allows full lateral traversal into OS file system.',
    verificationProcedure: 'sudo apparmor_status',
    rollbackCommand: 'sudo aa-complain /usr/sbin/nginx',
    isApplied: true,
    severity: 'HIGH',
  },
  {
    id: 'CTRL-AUD-01',
    category: 'auditd',
    title: 'Install Kernel Audit Rules for Sensitive Files',
    currentConfig: '-w /etc/passwd -p wa -k identity\n-w /etc/shadow -p wa -k identity',
    recommendedConfig: 'Comprehensive ruleset auditing identity files, sudoers, and execve syscalls',
    securityRationale: 'Auditd records kernel events that bypass application logs, creating forensic evidence admissible in investigations.',
    riskIfNotImplemented: 'Privilege escalation and stealth credential modification go undetected.',
    verificationProcedure: 'sudo auditctl -l',
    rollbackCommand: 'sudo rm -f /etc/audit/rules.d/99-labguard.rules && sudo augenrules --load',
    isApplied: true,
    severity: 'HIGH',
  },
  {
    id: 'CTRL-UPD-01',
    category: 'Updates',
    title: 'Configure Unattended Automatic Security Updates',
    currentConfig: 'APT::Periodic::Update-Package-Lists "1";\nAPT::Periodic::Unattended-Upgrade "1";',
    recommendedConfig: 'Daily security patch retrieval and automated installation for Ubuntu security repo',
    securityRationale: 'Zero-day window reduction: ensures critical CVE kernel and glibc patches are applied without manual intervention.',
    riskIfNotImplemented: 'System remains exposed to public exploit code days after vulnerability disclosure.',
    verificationProcedure: 'unattended-upgrades --dry-run',
    rollbackCommand: "sudo dpkg-reconfigure -plow unattended-upgrades",
    isApplied: true,
    severity: 'HIGH',
  },
];

export const INITIAL_RISKS: RiskItem[] = [
  {
    id: 'RSK-01',
    finding: 'Plaintext Telnet service exposed on TCP port 23',
    affectedService: 'telnetd (Port 23)',
    likelihood: 5,
    impact: 5,
    severity: 'CRITICAL',
    mitigation: 'Masked systemd socket and purged telnetd package. Blocked in UFW.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'VERY LOW',
    evidenceRef: 'EVD-NMAP-001 / EVD-SRV-003',
    isConfirmed: true,
  },
  {
    id: 'RSK-02',
    finding: 'SSH daemon permits direct password login and root login',
    affectedService: 'OpenSSH (Port 22)',
    likelihood: 5,
    impact: 4,
    severity: 'CRITICAL',
    mitigation: 'Configured PermitRootLogin no and PasswordAuthentication no in sshd_config.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'LOW',
    evidenceRef: 'EVD-SSH-002',
    isConfirmed: true,
  },
  {
    id: 'RSK-03',
    finding: 'Insecure vsftpd 3.0.3 active with anonymous login enabled',
    affectedService: 'vsftpd (Port 21)',
    likelihood: 4,
    impact: 4,
    severity: 'HIGH',
    mitigation: 'Service disabled and uninstalled; file transfer centralized over SFTP.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'VERY LOW',
    evidenceRef: 'EVD-NMAP-001',
    isConfirmed: true,
  },
  {
    id: 'RSK-04',
    finding: 'Cleartext HTTP (Port 80) lacks forced redirect to HTTPS (Port 443)',
    affectedService: 'nginx (Port 80)',
    likelihood: 4,
    impact: 3,
    severity: 'MEDIUM',
    mitigation: 'Configured return 301 https://$host$request_uri; block in nginx default site.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'VERY LOW',
    evidenceRef: 'EVD-TLS-004',
    isConfirmed: true,
  },
  {
    id: 'RSK-05',
    finding: 'Host Firewall (UFW) inactive prior to baseline remediation',
    affectedService: 'Linux Netfilter / UFW',
    likelihood: 4,
    impact: 5,
    severity: 'CRITICAL',
    mitigation: 'Enabled UFW with default deny incoming policy and explicit rate limits on port 22.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'LOW',
    evidenceRef: 'EVD-FW-005',
    isConfirmed: true,
  },
  {
    id: 'RSK-06',
    finding: 'Legacy SSL/TLS protocols (TLS 1.0 & TLS 1.1) permitted on web portal',
    affectedService: 'nginx SSL (Port 443)',
    likelihood: 3,
    impact: 4,
    severity: 'HIGH',
    mitigation: 'Enforced ssl_protocols TLSv1.2 TLSv1.3 only; disabled CBC ciphers.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'VERY LOW',
    evidenceRef: 'EVD-TLS-004',
    isConfirmed: true,
  },
  {
    id: 'RSK-07',
    finding: 'Absence of kernel audit logging for authentication database modifications',
    affectedService: 'auditd / systemd',
    likelihood: 3,
    impact: 4,
    severity: 'MEDIUM',
    mitigation: 'Installed CIS-compliant auditd rules watching /etc/passwd and /etc/shadow.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'LOW',
    evidenceRef: 'EVD-AUD-006',
    isConfirmed: true,
  },
  {
    id: 'RSK-08',
    finding: 'Kernel core dump protection disabled (fs.suid_dumpable = 2)',
    affectedService: 'Linux Kernel / sysctl',
    likelihood: 2,
    impact: 4,
    severity: 'MEDIUM',
    mitigation: 'Added fs.suid_dumpable = 0 to /etc/sysctl.d/99-security.conf.',
    treatmentStatus: 'Mitigated',
    residualRisk: 'LOW',
    evidenceRef: 'EVD-LYNIS-002',
    isConfirmed: true,
  },
];

export const INITIAL_TESTS: SecurityTest[] = [
  {
    id: 'TEST-SSH-01',
    category: 'SSH',
    name: 'Root Password Login Rejection',
    command: 'ssh -o BatchMode=yes -o StrictHostKeyChecking=no root@192.168.56.10',
    expectedResult: 'Permission denied (publickey)',
    actualResult: 'Permission denied (publickey)',
    status: 'passed',
    evidenceRef: 'EVD-TEST-SSH-01',
    timestamp: '2026-11-07 02:04:12 UTC',
  },
  {
    id: 'TEST-SSH-02',
    category: 'SSH',
    name: 'Authorized Ed25519 Key Login',
    command: 'ssh -i ~/.ssh/labguard_ed25519 -o BatchMode=yes student@192.168.56.10 whoami',
    expectedResult: 'student',
    actualResult: 'student',
    status: 'passed',
    evidenceRef: 'EVD-TEST-SSH-02',
    timestamp: '2026-11-07 02:04:45 UTC',
  },
  {
    id: 'TEST-FW-01',
    category: 'Firewall',
    name: 'Unauthorized Port 23 (Telnet) Inbound Block',
    command: 'nc -zv -w 2 192.168.56.10 23',
    expectedResult: 'Connection timed out / Filtered',
    actualResult: 'nc: connect to 192.168.56.10 port 23 (tcp) timed out: Operation now in progress',
    status: 'passed',
    evidenceRef: 'EVD-TEST-FW-01',
    timestamp: '2026-11-07 02:05:10 UTC',
  },
  {
    id: 'TEST-FW-02',
    category: 'Firewall',
    name: 'Authorized Port 443 (HTTPS) Inbound Access',
    command: 'nc -zv -w 2 192.168.56.10 443',
    expectedResult: 'Connection to 192.168.56.10 443 port [tcp/https] succeeded!',
    actualResult: 'Connection to 192.168.56.10 443 port [tcp/https] succeeded!',
    status: 'passed',
    evidenceRef: 'EVD-TEST-FW-02',
    timestamp: '2026-11-07 02:05:32 UTC',
  },
  {
    id: 'TEST-TLS-01',
    category: 'TLS',
    name: 'Legacy TLS 1.0 Handshake Rejection',
    command: 'openssl s_client -connect 192.168.56.10:443 -tls1',
    expectedResult: 'handshake failure / protocol version not supported',
    actualResult: 'CONNECTED(00000003)\n807B4F937E7F0000:error:0A0000BF:SSL routines:tls_setup_handshake:no protocols available:../ssl/statem/statem_lib.c:104:',
    status: 'passed',
    evidenceRef: 'EVD-TEST-TLS-01',
    timestamp: '2026-11-07 02:06:01 UTC',
  },
  {
    id: 'TEST-TLS-02',
    category: 'TLS',
    name: 'Modern TLS 1.3 Handshake Verification',
    command: 'openssl s_client -connect 192.168.56.10:443 -tls1_3',
    expectedResult: 'New, TLSv1.3, Cipher is TLS_AES_256_GCM_SHA384',
    actualResult: 'New, TLSv1.3, Cipher is TLS_AES_256_GCM_SHA384\nVerify return code: 0 (ok)',
    status: 'passed',
    evidenceRef: 'EVD-TEST-TLS-02',
    timestamp: '2026-11-07 02:06:25 UTC',
  },
  {
    id: 'TEST-TLS-03',
    category: 'TLS',
    name: 'HSTS Strict-Transport-Security Header Enforcement',
    command: 'curl -sI https://192.168.56.10/ -k | grep -i strict-transport',
    expectedResult: 'strict-transport-security: max-age=31536000; includeSubDomains',
    actualResult: 'strict-transport-security: max-age=31536000; includeSubDomains',
    status: 'passed',
    evidenceRef: 'EVD-TEST-TLS-03',
    timestamp: '2026-11-07 02:06:50 UTC',
  },
  {
    id: 'TEST-AUD-01',
    category: 'auditd',
    name: 'Auditd Sensitive File Modification Trigger',
    command: 'sudo touch /etc/passwd && sudo ausearch -k identity --recent',
    expectedResult: 'type=SYSCALL ... key="identity" ... name="/etc/passwd"',
    actualResult: 'type=SYSCALL msg=audit(1762495620.102:412): arch=c000003e syscall=257 success=yes exit=3 a0=ffffff9c a1=7ffd20a7b450 a2=941 a3=1b6 items=2 ppid=1420 pid=2105 auid=1000 uid=0 gid=0 euid=0 key="identity"',
    status: 'passed',
    evidenceRef: 'EVD-TEST-AUD-01',
    timestamp: '2026-11-07 02:07:15 UTC',
  },
  {
    id: 'TEST-AA-01',
    category: 'AppArmor',
    name: 'AppArmor Confinement Enforce Mode Status',
    command: 'sudo aa-status | grep "profiles are in enforce mode"',
    expectedResult: '>= 15 profiles are in enforce mode, 0 in complain mode',
    actualResult: '18 profiles are in enforce mode.\n0 profiles are in complain mode.',
    status: 'passed',
    evidenceRef: 'EVD-TEST-AA-01',
    timestamp: '2026-11-07 02:07:40 UTC',
  },
  {
    id: 'TEST-LYN-01',
    category: 'Lynis',
    name: 'Lynis Hardening Index Delta Target (+10 Points)',
    command: 'lynis audit system --quick | grep "Hardening index"',
    expectedResult: 'Hardening index : [78] (Improvement: +24 from 54 baseline)',
    actualResult: 'Hardening index : [78]',
    status: 'passed',
    evidenceRef: 'EVD-TEST-LYN-01',
    timestamp: '2026-11-07 02:08:12 UTC',
  },
  {
    id: 'TEST-REP-01',
    category: 'Reproducibility',
    name: 'Secondary VM Playbook Automated Idempotence',
    command: 'ansible-playbook -i 192.168.56.11, site.yml --check',
    expectedResult: 'changed=0, unreachable=0, failed=0',
    actualResult: 'PLAY RECAP *************************************************************\n192.168.56.11 : ok=26   changed=0    unreachable=0    failed=0',
    status: 'passed',
    evidenceRef: 'EVD-TEST-REP-01',
    timestamp: '2026-11-07 02:08:44 UTC',
  },
  {
    id: 'TEST-SRV-01',
    category: 'Services',
    name: 'Verify Unnecessary Listening Sockets Closed',
    command: 'ss -tulpn | grep -E ":21|:23|:111"',
    expectedResult: '<empty> (No sockets bound on ports 21, 23, 111)',
    actualResult: '',
    status: 'passed',
    evidenceRef: 'EVD-TEST-SRV-01',
    timestamp: '2026-11-07 02:09:05 UTC',
  },
];

export const INITIAL_EVIDENCE: EvidenceRecord[] = [
  {
    id: 'EVD-NMAP-001',
    title: 'Baseline Nmap Port & Service Scan',
    category: 'Nmap',
    type: 'Automatically Collected',
    filename: 'baseline_nmap_192.168.56.10.txt',
    timestamp: '2026-11-07 01:15:20 UTC',
    sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    content: `Starting Nmap 7.94 ( https://nmap.org ) at 2026-11-07 01:15 UTC
Nmap scan report for 192.168.56.10
Host is up (0.00042s latency).
Not shown: 993 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
21/tcp   open  ftp     vsftpd 3.0.3
22/tcp   open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.6
23/tcp   open  telnet  Linux telnetd
80/tcp   open  http    nginx 1.18.0 (Ubuntu)
111/tcp  open  rpcbind 2-4 (RPC #100000)
443/tcp  closed https
3306/tcp open  mysql   MySQL 8.0.35
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel`,
    notes: 'Baseline scan performed from Assessor VM (192.168.56.20). Confirms Telnet and FTP exposure.',
  },
  {
    id: 'EVD-LYNIS-002',
    title: 'Baseline Lynis System Audit Log',
    category: 'Lynis',
    type: 'Automatically Collected',
    filename: 'lynis_baseline_audit_54.log',
    timestamp: '2026-11-07 01:22:40 UTC',
    sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
    content: `[+] Audit Results
---------------------------------------------------
  Hardening index : 54
  Tests performed : 248
  Plugins enabled : 1

  Warnings (18):
  - [SSH-7408] Root login allowed in OpenSSH configuration
  - [SSH-7408] Password authentication allowed in OpenSSH configuration
  - [FIRE-4512] Host-based firewall not active
  - [ACCT-9626] Audit daemon not auditing authentication files
  - [KRNL-5830] Memory dump protection disabled (fs.suid_dumpable = 2)
  - [BANN-7126] Missing legal warning banner in /etc/issue.net
  - [NAME-4016] BindToInterface missing for unneeded daemon sockets

  Suggestions (42):
  - Consider installing fail2ban to mitigate brute force
  - Restrict compiler binaries (chmod 700 /usr/bin/gcc)`,
    notes: 'Initial Lynis hardening index benchmark established at 54/100.',
  },
  {
    id: 'EVD-SSH-002',
    title: 'Hardened /etc/ssh/sshd_config File',
    category: 'SSH',
    type: 'Verified Result',
    filename: 'sshd_config_hardened.conf',
    timestamp: '2026-11-07 01:42:10 UTC',
    sha256: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
    content: `Port 22
Protocol 2
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
ClientAliveInterval 300
ClientAliveCountMax 2
X11Forwarding no
AllowAgentForwarding no
Banner /etc/issue.net
KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group16-sha512
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com
MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com`,
    notes: 'Verified via sshd -t syntax validation prior to reload.',
  },
  {
    id: 'EVD-FW-005',
    title: 'Active UFW Firewall Status Verbose',
    category: 'Firewall',
    type: 'Verified Result',
    filename: 'ufw_status_verbose.txt',
    timestamp: '2026-11-07 01:50:33 UTC',
    sha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    content: `Status: active
Logging: on (low)
Default: deny (incoming), allow (outgoing), disabled (routed)
New profiles: skip

To                         Action      From
--                         ------      ----
22/tcp                     LIMIT IN    Anywhere                  # SSH Rate-Limited
443/tcp                    ALLOW IN    Anywhere                  # HTTPS Portal
80/tcp                     ALLOW IN    Anywhere                  # HTTP 301 Redirect
22/tcp (v6)                LIMIT IN    Anywhere (v6)             # SSH Rate-Limited
443/tcp (v6)               ALLOW IN    Anywhere (v6)             # HTTPS Portal
80/tcp (v6)                ALLOW IN    Anywhere (v6)             # HTTP 301 Redirect`,
    notes: 'Inbound attack surface strictly reduced to SSH, HTTPS, and HTTP 301 redirect.',
  },
  {
    id: 'EVD-TLS-004',
    title: 'Nginx TLS & Certificate Configuration',
    category: 'TLS',
    type: 'Verified Result',
    filename: 'nginx_tls_labguard.conf',
    timestamp: '2026-11-07 01:58:19 UTC',
    sha256: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
    content: `server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name labguard.internal 192.168.56.10;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name labguard.internal 192.168.56.10;

    ssl_certificate /etc/ssl/certs/labguard.crt;
    ssl_certificate_key /etc/ssl/private/labguard.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    ssl_prefer_server_ciphers off;
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:10m;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header X-XSS-Protection "1; mode=block" always;
}`,
    notes: 'Configured with Lab Internal CA certificate, SAN verification, and modern TLS protocols.',
  },
  {
    id: 'EVD-AUD-006',
    title: 'Auditd Configuration & Rule Audit Trail',
    category: 'auditd',
    type: 'Verified Result',
    filename: 'auditd_rules_99_labguard.rules',
    timestamp: '2026-11-07 02:02:11 UTC',
    sha256: '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae',
    content: `## First rule - delete all existing rules
-D

## Increase buffer size
-b 8192

## Failure mode: 1 = syslog message
-f 1

## Identity file changes
-w /etc/group -p wa -k identity
-w /etc/passwd -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/security/opasswd -p wa -k identity

## Sudoers changes
-w /etc/sudoers -p wa -k actions
-w /etc/sudoers.d/ -p wa -k actions

## Make rules immutable
-e 2`,
    notes: 'CIS Linux benchmark requirement for auditing authentication database modifications.',
  },
];

export const CHECKLIST_ITEMS: ChecklistRequirement[] = [
  {
    id: 'REQ-01',
    category: 'Scope & Authorization',
    title: 'Signed Rules of Engagement & Scope Document',
    description: 'Formal authorization document defining isolated subnet 192.168.56.0/24 and off-limits host systems.',
    status: 'completed',
    evidenceId: 'EVD-ROE-001',
    verificationCmd: 'cat /docs/rules_of_engagement_signed.pdf',
  },
  {
    id: 'REQ-02',
    category: 'Baseline Discovery',
    title: 'Baseline Nmap Port & Service Scan',
    description: 'Initial port assessment showing baseline open ports (21, 22, 23, 80, 111, 3306).',
    status: 'completed',
    evidenceId: 'EVD-NMAP-001',
    verificationCmd: 'nmap -sV -sC -p- 192.168.56.10 -oN baseline_nmap.txt',
  },
  {
    id: 'REQ-03',
    category: 'Baseline Discovery',
    title: 'Baseline Socket & Listening Services (ss -tulpn)',
    description: 'Kernel socket dump documenting active daemons, listening ports, and PIDs.',
    status: 'completed',
    evidenceId: 'EVD-SS-001',
    verificationCmd: 'ss -tulpn > baseline_ss_tulpn.txt',
  },
  {
    id: 'REQ-04',
    category: 'Baseline Discovery',
    title: 'Baseline Lynis System Audit',
    description: 'Un-hardened system benchmark establishing baseline hardening score of 54/100.',
    status: 'completed',
    evidenceId: 'EVD-LYNIS-002',
    verificationCmd: 'lynis audit system --quick',
  },
  {
    id: 'REQ-05',
    category: 'Access Control',
    title: 'SSH Root Login Disabled (PermitRootLogin no)',
    description: 'Enforce direct root prohibition in /etc/ssh/sshd_config.',
    status: 'completed',
    evidenceId: 'EVD-SSH-002',
    verificationCmd: 'sshd -T | grep permitrootlogin',
  },
  {
    id: 'REQ-06',
    category: 'Access Control',
    title: 'SSH Password Authentication Disabled (Key-Only)',
    description: 'Enforce asymmetric public key authentication (Ed25519) and block password login.',
    status: 'completed',
    evidenceId: 'EVD-SSH-002',
    verificationCmd: 'sshd -T | grep passwordauthentication',
  },
  {
    id: 'REQ-07',
    category: 'Network Defense',
    title: 'Host Firewall (UFW) Default Deny Incoming Policy',
    description: 'Drop all inbound packets by default, permitting only explicitly whitelisted services.',
    status: 'completed',
    evidenceId: 'EVD-FW-005',
    verificationCmd: 'sudo ufw status verbose',
  },
  {
    id: 'REQ-08',
    category: 'Attack Surface',
    title: 'Decommission Unnecessary Insecure Services (Telnet & FTP)',
    description: 'Purge telnetd and vsftpd packages, masking systemd sockets.',
    status: 'completed',
    evidenceId: 'EVD-SRV-003',
    verificationCmd: 'systemctl is-active telnet vsftpd',
  },
  {
    id: 'REQ-09',
    category: 'Patch Management',
    title: 'Automated Security Updates (unattended-upgrades)',
    description: 'Configure automated background installation of Ubuntu security repository patches.',
    status: 'completed',
    evidenceId: 'EVD-UPD-001',
    verificationCmd: 'unattended-upgrades --dry-run',
  },
  {
    id: 'REQ-10',
    category: 'Kernel Security',
    title: 'AppArmor Mandatory Access Control Profiles Enforced',
    description: 'Ensure internet-facing daemons (nginx, etc.) are enclosed in Enforce mode.',
    status: 'completed',
    evidenceId: 'EVD-AA-001',
    verificationCmd: 'sudo apparmor_status',
  },
  {
    id: 'REQ-11',
    category: 'Monitoring & Forensics',
    title: 'Linux Audit Daemon (auditd) Rules Active',
    description: 'Kernel auditing of /etc/passwd, /etc/shadow, and privilege escalation syscalls.',
    status: 'completed',
    evidenceId: 'EVD-AUD-006',
    verificationCmd: 'sudo auditctl -l',
  },
  {
    id: 'REQ-12',
    category: 'Cryptography & TLS',
    title: 'Internal Lab CA Certificate Generation & Trust',
    description: 'Generate internal Root CA and sign server certificate with valid SAN extensions.',
    status: 'completed',
    evidenceId: 'EVD-TLS-004',
    verificationCmd: 'openssl x509 -in /etc/ssl/certs/labguard.crt -text -noout',
  },
  {
    id: 'REQ-13',
    category: 'Cryptography & TLS',
    title: 'Nginx HTTPS Portal on Port 443',
    description: 'Deploy web server with HTTP/2 and modern SSL cipher configurations.',
    status: 'completed',
    evidenceId: 'EVD-TLS-004',
    verificationCmd: 'curl -vk https://192.168.56.10',
  },
  {
    id: 'REQ-14',
    category: 'Cryptography & TLS',
    title: 'Enforce Modern TLS 1.2 and TLS 1.3',
    description: 'Ensure OpenSSL handshake succeeds with TLSv1.2 and TLSv1.3.',
    status: 'completed',
    evidenceId: 'EVD-TEST-TLS-02',
    verificationCmd: 'openssl s_client -connect 192.168.56.10:443 -tls1_3',
  },
  {
    id: 'REQ-15',
    category: 'Cryptography & TLS',
    title: 'Explicit Rejection of Insecure TLS 1.0 and TLS 1.1',
    description: 'Legacy protocols must fail connection negotiation.',
    status: 'completed',
    evidenceId: 'EVD-TEST-TLS-01',
    verificationCmd: 'openssl s_client -connect 192.168.56.10:443 -tls1',
  },
  {
    id: 'REQ-16',
    category: 'Cryptography & TLS',
    title: 'HSTS (HTTP Strict Transport Security) Header',
    description: 'Enforce max-age=31536000 and includeSubDomains on all HTTPS responses.',
    status: 'completed',
    evidenceId: 'EVD-TEST-TLS-03',
    verificationCmd: 'curl -sI https://192.168.56.10/ -k | grep -i strict-transport',
  },
  {
    id: 'REQ-17',
    category: 'Cryptography & TLS',
    title: 'HTTP 301 Permanent Redirect to HTTPS',
    description: 'Plaintext HTTP requests on port 80 are redirected to encrypted HTTPS port 443.',
    status: 'completed',
    evidenceId: 'EVD-TLS-004',
    verificationCmd: 'curl -sI http://192.168.56.10/ | grep "301 Moved Permanently"',
  },
  {
    id: 'REQ-18',
    category: 'Risk Management',
    title: 'Evidence-Based Risk Register Generated',
    description: 'Formal risk register with 8 identified vulnerabilities, likelihood/impact ratings, and mitigations.',
    status: 'completed',
    evidenceId: 'EVD-RISK-001',
    verificationCmd: 'cat /docs/risk_register.md',
  },
  {
    id: 'REQ-19',
    category: 'Verification & Retest',
    title: 'Automated Security Retesting Completed',
    description: 'Verification test suite executed across SSH, Firewall, TLS, auditd, and AppArmor.',
    status: 'completed',
    evidenceId: 'EVD-TESTS-ALL',
    verificationCmd: 'labguard-test-suite --run-all',
  },
  {
    id: 'REQ-20',
    category: 'Verification & Retest',
    title: 'Lynis Hardening Score Improvement >= 10 Points',
    description: 'Final audit must demonstrate at least +10 point improvement (Baseline 54 -> Target 78 = +24 pts!).',
    status: 'completed',
    evidenceId: 'EVD-TEST-LYN-01',
    verificationCmd: 'lynis audit system --quick | grep "Hardening index"',
  },
  {
    id: 'REQ-21',
    category: 'Reproducibility',
    title: 'Second VM Automated Reproducibility Playbook',
    description: 'Ansible playbook or idempotent bash script verified on clean secondary Ubuntu VM (192.168.56.11).',
    status: 'completed',
    evidenceId: 'EVD-TEST-REP-01',
    verificationCmd: 'ansible-playbook -i 192.168.56.11, site.yml --check',
  },
  {
    id: 'REQ-22',
    category: 'Academic Deliverables',
    title: 'Project Final Report, GitHub Repo & Video Evidence',
    description: 'Professional 5-page report generated, git repository tagged, and terminal recording archived.',
    status: 'completed',
    evidenceId: 'EVD-REPORT-FINAL',
    verificationCmd: 'git status && ls -lh final_security_report.pdf',
  },
];
