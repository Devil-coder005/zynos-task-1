---
name: Cybersecurity Operations Command
colors:
  surface: '#0e1321'
  surface-dim: '#0e1321'
  surface-bright: '#343948'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#161b2a'
  surface-container: '#1a1f2e'
  surface-container-high: '#252a39'
  surface-container-highest: '#303444'
  on-surface: '#dee2f6'
  on-surface-variant: '#bac9cb'
  inverse-surface: '#dee2f6'
  inverse-on-surface: '#2b303f'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbea'
  primary: '#bff9ff'
  on-primary: '#00363b'
  primary-container: '#00e8f8'
  on-primary-container: '#00646c'
  inverse-primary: '#006971'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#ffecc7'
  on-tertiary: '#3e2e00'
  tertiary-container: '#ffcb3a'
  on-tertiary-container: '#715600'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#82f3ff'
  primary-fixed-dim: '#00dbea'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f55'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffdf96'
  tertiary-fixed-dim: '#f2c02e'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#0e1321'
  on-background: '#dee2f6'
  surface-variant: '#303444'
  surface-charcoal: '#131C31'
  status-success: '#10B981'
  status-warning: '#F59E0B'
  status-critical: '#EF4444'
  text-primary: '#FFFFFF'
  text-muted: '#94A3B8'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers an elite, high-performance security operations center (SOC) interface. The brand personality is authoritative, analytical, and relentlessly precise. It evokes absolute operational control and situational awareness under high-stress conditions. 

The aesthetic marries **Minimalism** with subtle **Glassmorphism**, prioritizing extreme information density without visual fatigue. Surfaces are built from dark, receding tonal layers that allow critical threat indicators, telemetry, and status accents to pierce through with absolute clarity.

## Colors

The color architecture is optimized for 24/7 monitoring environments, utilizing deep navy and charcoal foundations to eliminate glare. Chromatic accents are reserved strictly for data hierarchy, interactive elements, and security telemetry states.

- **Primary (`#00E8F8`):** Vibrant cyan used for active selections, primary actions, and key focal points.
- **Secondary (`#3B82F6`):** Electric blue for structural UI framing, secondary data points, and active navigation states.
- **Neutral (`#0A0F1D` to `#131C31`):** Deep navy base paired with charcoal surface cards to create precise elevation steps.
- **Status Indicators:** Emerald green (`#10B981`) for verified controls, amber (`#F59E0B`) for warnings, and crimson red (`#EF4444`) for critical breaches.

## Typography

Typography is treated as a high-density telemetry instrument. **Inter** is deployed for all standard UI chrome, data tables, and operational headings due to its exceptional legibility at small scales. **JetBrains Mono** is strictly reserved for live logs, hashes, IP addresses, terminal outputs, and numerical metrics where monospaced alignment is critical for rapid scanning. 

Ensure line heights remain tight to maximize data density on standard 1080p and 4K SOC workstation monitors.

## Layout & Spacing

The interface employs a **fluid grid** system designed for high-density dashboard layouts. A strict 1rem (16px) baseline grid dictates canvas margins and gutters, ensuring modular widget alignment across multi-monitor command center setups.

- **Breakpoints:** Optimized for desktop-first workflows (`lg: 1024px`, `xl: 1280px`, `2xl: 1536px`), with responsive stacking rules for tablet viewports.
- **Density Management:** Component padding utilizes tight spacing tokens (`space-xs` to `space-md`) to prevent wasted screen real estate, ensuring analysts can ingest maximum log output without excessive scrolling.

## Elevation & Depth

Depth is communicated primarily through subtle **low-contrast outlines** and **glassmorphic surfaces** rather than heavy drop shadows. 

- **Surfaces:** Cards and panels utilize the charcoal background (`#131C31`) with a low-opacity white or electric blue border (`rgba(59, 130, 246, 0.15)`) to delineate boundaries.
- **Glassmorphism:** Floating tooltips, modals, and active panels incorporate subtle backdrop blurs (`blur(12px)`) with semi-transparent dark fills to maintain context over live background charts and telemetry streams.

## Shapes

The design system enforces a **Soft** shape language (`roundedness: 1`). UI elements feature restrained corner radiuses (0.25rem to 0.5rem) to maintain a precise, engineered aesthetic without feeling overly consumer-grade or playful. Pill shapes are strictly reserved for status badges, threat-level indicators, and categorization tags.

## Components

- **Buttons:** Sharp, high-contrast action triggers. Primary buttons feature solid cyan (`#00E8F8`) backgrounds with dark text, while secondary actions use ghost borders with electric blue hover states. Destructive actions (e.g., isolate host) must use crimson red (`#EF4444`).
- **Input Fields:** Built on charcoal surfaces with subtle borders. Focus states transition instantly to vibrant cyan with a 1px glow. All inputs dealing with parameters, queries, or scripts must render in JetBrains Mono.
- **Cards:** Glassmorphic container panels housing telemetry feeds, charts, and metrics. Always feature a subtle 1px border and a distinct header bar.
- **Chips & Badges:** Compact pill elements displaying status levels using the designated semantic colors (emerald for verified, amber for warning, crimson for critical).
- **Lists & Data Tables:** High-density rows with alternating dark tints for scannability. Support inline status indicators and monospaced data columns.
- **Checkboxes & Radios:** Minimalist square and circular controls with high-contrast active states.
- **Telemetry Tickers & Terminal Outputs:** Specialized components utilizing dark monospaced containers with syntax highlighting for logs, packet captures, and command-line inputs.